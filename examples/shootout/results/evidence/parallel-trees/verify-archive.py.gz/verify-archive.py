from pathlib import Path
import csv,gzip,hashlib,json,subprocess,collections,sys,re
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout/results';run=root/'runs/20261031T145604Z'
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((run/'current.json').read_text());assert (root/'current.json').read_bytes()==(run/'current.json').read_bytes()
assert r['samples']==16 and len(r['implementations'])==8 and len(r['summary_benchmarks'])==9 and not r['machine']['repository']['dirty']
assert all(v['idle_percent']>=90 for v in r['machine']['quiet_window']['samples']) and len(r['machine']['quiet_window']['samples'])==6
raw=[json.loads(l) for l in gzip.decompress((run/'raw/calibration-raw.jsonl.gz').read_bytes()).splitlines()];assert len(raw)==1216
counts=collections.Counter((v['benchmark'],v['implementation']) for v in raw);assert len(counts)==76 and set(counts.values())=={16}
assert all(v['exit_code']==0 and v['signal']==0 and v['run_id']==r['run_id'] for v in raw)
checks=json.loads(gzip.decompress((run/'raw/check.json.gz').read_bytes()));assert len(checks['checks'])==76
for name,e in r['benchmarks'].items():
 programs={k:e[k] for k in ('idiomatic','tuned')};programs.update(e['references'])
 for k,v in programs.items():
  source=repo/'examples/shootout'/v['source']['path'];assert sha(source.read_bytes())==v['source']['sha256']
  assert sha(subprocess.check_output(['git','show',r['machine']['repository']['revision']+':'+str(source.relative_to(repo))],cwd=repo))==v['source']['sha256']
assert set(r['benchmarks']['knucleotide']['unavailable'])=={'rust','cpp','go','java'}
pro=json.loads((run/'charts/provenance.json').read_text());assert pro['report_sha256']==sha((run/'current.json').read_bytes())
sys.path.insert(0,str(repo/'examples/shootout/tools'));import shootout
assert shootout.value_sha256(json.loads(gzip.decompress((run/'baseline.json.gz').read_bytes())))==r['baseline_sha256']
rows=list(csv.DictReader((run/'charts/measurements.csv').open()));assert len(rows)==76
for row in rows:
 e=r['benchmarks'][row['problem']];p=e[row['implementation']] if row['implementation'] in ('idiomatic','tuned') else e['references'][row['implementation']]
 # The renderer records raw milliseconds before normalization.
 if 'time_ms' in row:assert abs(float(row['time_ms'])-p['statistics']['median_elapsed_ns']/1e6)<1e-8
side=json.loads(gzip.decompress((root/'evidence/parallel-trees/serial-comparison.json.gz').read_bytes()));assert len(side['raw'])==32 and side['revision']==r['machine']['repository']['revision']
for name,filename in [('serial','serial.x'),('parallel','main.x')]:assert side['source_sha256'][name]==sha((repo/'examples/shootout/benchmarks/binarytrees'/filename).read_bytes())
assert all(v['exit_code']==0 and v['signal']==0 for v in side['raw'])
# Earlier immutable run directories must retain every original byte.
old=subprocess.check_output(['git','show','9d070d9a0:examples/shootout/results/SHA256SUMS'],cwd=repo,text=True)
oldruns=0
for line in old.splitlines():
 digest,path=line.split('  ',1)
 if path.startswith('runs/') and path!='runs/index.json':assert sha((root/path).read_bytes())==digest;oldruns+=1
parsed=0
for p in [*(run.rglob('*')),*(root/'evidence/fann-fasta').rglob('*'),*(root/'evidence/parallel-trees').rglob('*')]:
 if not p.is_file():continue
 if p.suffix=='.gz':
  data=gzip.decompress(p.read_bytes())
  if p.name.endswith('.json.gz'):json.loads(data);parsed+=1
  if p.name.endswith('.jsonl.gz'):
   for line in data.splitlines():json.loads(line)
   parsed+=1
 elif p.suffix=='.json':json.loads(p.read_text());parsed+=1
# Check relative Markdown links in new/current guidance.
for p in [root/'README.md',root/'threading.md',root/'remaining-gaps.md',run/'README.md',run/'charts/README.md',repo/'site/BENCHMARKS.md']:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if not target.startswith(('https:','http:','#')):assert (p.parent/target.split('#')[0]).exists(),(p,target)
paths=sorted([q for parent in (root/'runs',root/'evidence') for q in parent.rglob('*') if q.is_file()]+[root/'requirements-charts.txt'])
(root/'SHA256SUMS').write_text(''.join(sha(q.read_bytes())+'  '+str(q.relative_to(root))+'\n' for q in paths))
print(json.dumps({'official_checks':len(checks['checks']),'programs':len(counts),'samples_per_program':16,'observations':len(raw),'columns':8,'common_problems':9,'serial_parallel_samples':32,'unchanged_prior_run_files':oldruns,'parsed_json_files':parsed,'checksummed_files':len(paths),'visual_review':'All four PNG chart forms inspected; header spacing and tuned profile label corrected; all eight series, common cohort and axes retained.'},indent=2))
