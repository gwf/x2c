from pathlib import Path
import subprocess,json,hashlib,shutil,statistics
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=Path(__file__).resolve().parent
shutil.copyfile(repo/'builds/0/libx2c.a',root/'libx2c.a')
commands=[]
def call(args,**kw):
 commands.append([str(a) for a in args]);return subprocess.run(args,check=True,**kw)
for name in ('serial','parallel'):
 out=root/name;out.mkdir(exist_ok=True)
 call([repo/'builds/0/x2c','translate','--out-dir',out,root/(name+'.x')],stdout=subprocess.DEVNULL)
 call(['/usr/bin/cc','-O2','-DNDEBUG','-I/opt/homebrew/include','-iquote',repo/'include/x2c',out/(name+'.c'),'-L',root,'-lx2c','-lm','-L/opt/homebrew/lib','-o',out/'program'])
checks=[]
for n in (1,6,7,8,10,12,14):
 maximum=max(6,n);lines=[f'stretch tree of depth {maximum+1}\t check: {(1<<(maximum+2))-1}']
 for d in range(4,maximum+1,2):
  iterations=1<<(maximum-d+4);lines.append(f'{iterations}\t trees of depth {d}\t check: {iterations*((1<<(d+1))-1)}')
 lines.append(f'long lived tree of depth {maximum}\t check: {(1<<(maximum+1))-1}')
 expected=('\n'.join(lines)+'\n').encode()
 for name in ('serial','parallel'):
  for repeat in range(3):
   result=subprocess.check_output([root/name/'program',str(n)]);assert result==expected,(n,name)
 checks.append({'n':n,'repeats_per_source':3,'sha256':hashlib.sha256(expected).hexdigest()})
 print('checked',n,flush=True)
measure=repo/'examples/build/shootout/tools/measure';raw=[]
for i in range(6):
 for name in (('serial','parallel') if i%2==0 else ('parallel','serial')):
  r=subprocess.run([measure,root/name/'program','14'],capture_output=True,check=True,text=True)
  # Native measurement suppresses program output and emits JSON on stdout.
  item=json.loads(r.stdout);item.update(implementation=name,sample=i+1);raw.append(item)
summary={name:statistics.median(v['elapsed_ns'] for v in raw if v['implementation']==name)/1e6 for name in ('serial','parallel')}
r={'checks':checks,'raw':raw,'summary_ms':summary,'commands':commands,'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'runtime_sha256':hashlib.sha256((root/'libx2c.a').read_bytes()).hexdigest(),'source_sha256':{n:hashlib.sha256((root/(n+'.x')).read_bytes()).hexdigest() for n in ('serial','parallel')},'limit':'Active-desktop probe only; quiet serial/parallel timings still required.'}
(root/'results.json').write_text(json.dumps(r,indent=2)+'\n');print(summary,flush=True)
