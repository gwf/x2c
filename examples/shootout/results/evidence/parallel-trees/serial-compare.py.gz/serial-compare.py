"""Same-source serial/parallel comparison after the recorded quiet window."""
from pathlib import Path
import hashlib,json,statistics,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c')
measure=repo/'examples/build/shootout/tools/measure'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'serial.x')==sha(repo/'examples/shootout/benchmarks/binarytrees/serial.x')
assert sha(root/'parallel.x')==sha(repo/'examples/shootout/benchmarks/binarytrees/main.x')
assert sha(root/'libx2c.a')==sha(repo/'builds/0/libx2c.a')
expected=subprocess.check_output([root/'serial/program','14'])
for name in ('serial','parallel'):
 assert subprocess.check_output([root/name/'program','14'])==expected
raw=[]
for sample in range(16):
 for name in (('serial','parallel') if sample%2==0 else ('parallel','serial')):
  result=json.loads(subprocess.check_output([measure,root/name/'program','14']))
  assert result['exit_code']==0 and result['signal']==0
  result.update(implementation=name,sample=sample+1);raw.append(result)
summary={name:{'median_elapsed_ms':statistics.median(v['elapsed_ns'] for v in raw if v['implementation']==name)/1e6,'median_cpu_ms':statistics.median(v['user_ns']+v['system_ns'] for v in raw if v['implementation']==name)/1e6} for name in ('serial','parallel')}
r={'schema':1,'problem':'binarytrees','n':14,'samples':16,'warmups_per_program':1,'ordering':'alternating serial/parallel and parallel/serial pairs','workers':{'serial':0,'parallel':6},'raw':raw,'summary':summary,'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_sha256':{n:sha(root/(n+'.x')) for n in ('serial','parallel')},'program_sha256':{n:sha(root/n/'program') for n in ('serial','parallel')},'runtime_sha256':sha(root/'libx2c.a'),'compiler_sha256':sha(repo/'builds/0/x2c'),'output_sha256':hashlib.sha256(expected).hexdigest(),'quiet_window_observations':json.loads('['+','.join((repo/'debug/parallel-trees-quiet-window.jsonl').read_text().splitlines())+']')[-6:],'limit':'Quiet window precedes measurement; zero background activity throughout measurement is not established.'}
(root/'serial-comparison.json').write_text(json.dumps(r,indent=2)+'\n')
print('Serial/parallel comparison:',json.dumps(summary),flush=True)
