"""Preserve the completed one-off run using the repository archive format."""
from pathlib import Path
import csv,gzip,hashlib,json,shutil,subprocess,sys
from datetime import datetime
from zoneinfo import ZoneInfo
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout/results';scratch=Path(__file__).resolve().parent
publication=subprocess.check_output(['git','rev-parse',sys.argv[1]],cwd=repo).decode().strip()
r=json.loads((root/'current.json').read_text());run=r['run_id'];oldrun='20261031T035446Z'
assert run!=oldrun and r['samples']==16 and len(r['implementations'])==8 and len(r['summary_benchmarks'])==9
assert not r['machine']['repository']['dirty'] and r['machine']['quiet_window']
assert subprocess.check_output(['git','show',publication+':examples/shootout/results/current.json'],cwd=repo)==(root/'current.json').read_bytes()
build=repo/'examples/build/shootout';receipt=json.loads((build/'latest/receipt.json').read_text());assert receipt['run_id']==run
raw=(build/'calibration-raw.jsonl').read_bytes();assert len(raw.splitlines())==1216
for name,e in r['benchmarks'].items():
 programs={k:e[k] for k in ('idiomatic','tuned')};programs.update(e['references'])
 for key,p in programs.items():
  source=repo/'examples/shootout'/p['source']['path'];assert hashlib.sha256(source.read_bytes()).hexdigest()==p['source']['sha256']
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def zipped(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0))
p=root/'runs'/run;p.mkdir(exist_ok=False)
for name in ('current.json','current.md'):(p/name).write_bytes((root/name).read_bytes())
zipped(p/'baseline.json.gz',(repo/'examples/shootout/baseline.json').read_bytes());shutil.copyfile(repo/'examples/shootout/benchmarks.json',p/'benchmarks.json')
charts=p/'charts';charts.mkdir();shutil.copyfile(root/'runs'/oldrun/'charts/render.py',charts/'render.py')
subprocess.run(['/Users/gary/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3',str(charts/'render.py'),str(p/'current.json'),str(charts)],check=True)
for f in [build/'calibration-raw.jsonl',*(build/'latest'/name for name in ('build.json','check.json','receipt.json','summary.json','summary.md')),repo/'debug/shootout-node-buffer-quiet-window.jsonl',scratch/'quiet-run.py']:
 zipped(p/'raw'/(f.name+'.gz'),f.read_bytes())
o=json.loads((root/'runs'/oldrun/'current.json').read_text());comp=[]
for name in r['benchmark_order']:
 for variant in ('idiomatic','tuned'):
  before=o['benchmarks'][name];after=r['benchmarks'][name]
  comp.append({'problem':name,'implementation':variant,'before_ms':before[variant]['statistics']['median_elapsed_ns']/1e6,'after_ms':after[variant]['statistics']['median_elapsed_ns']/1e6,'before_over_C':before['factors']['time_'+variant+'_over_c'],'after_over_C':after['factors']['time_'+variant+'_over_c']})
with (charts/'comparison.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=comp[0]);w.writeheader();w.writerows(comp)
web={'schema':1,'run_id':run,'publication_revision':publication,'measured_revision':r['machine']['repository']['revision'],'measured_tree_dirty':False,'profile':r['profile'],'cpu_model':r['machine'].get('cpu_model'),'samples':16,'process_warmups':r['warmups'],'implementations':r['implementations'],'summary_benchmarks':r['summary_benchmarks'],'java_process_model':'fresh JVM per sample; startup and JIT included','historical_source_metric_issue':False,'measurements':list(csv.DictReader((charts/'measurements.csv').open()))};dump(p/'website.json',web)
text=f'''# Run {run}

Published report revision: `{publication}`.
Measured source revision: `{r['machine']['repository']['revision']}`.

This local-profile run measures the ordinary Node binary-trees entry and fused
Buffer reverse-complement entry. All 76 official fixture and local-output checks
pass. Sixteen fresh-process samples per program yield 1,216 observations. The
summary cohort is the same nine problems across all eight columns.

`current.json` is the exact chart input; its hash matches chart provenance.
`baseline.json.gz`, `benchmarks.json`, and `raw/` retain the original baseline,
inputs, source hashes, full samples, build/check receipts, and quiet observations.
Timing began after six consecutive ten-second CPU samples were at least 90
percent idle. This records the pre-run window, not zero background activity
throughout measurement. Native binaries and external caches are not archived.
Recover exact sources from the publication revision and follow the parent
[recovery guide](../../README.md).

`charts/` contains PNG/SVG/PDF, CSVs, renderer, comparison, and provenance.
`website.json` is the curated public export; machine-path receipts are audit
records rather than website assets. Java includes JVM startup and JIT in every
sample. Canonical-size timing remains unrun.

## Changed idiomatic entries: separate-run comparison

Compare with run `{oldrun}`. Values are median elapsed milliseconds; these
full runs are not an alternating causal experiment. C reference drift is shown.

| Problem | Before ms | After ms | C before ms | C after ms | Before/C | After/C |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for name in ('binarytrees','revcomp'):
 a=o['benchmarks'][name];b=r['benchmarks'][name]
 text+=f"| {name} | {a['idiomatic']['statistics']['median_elapsed_ns']/1e6:.3f} | {b['idiomatic']['statistics']['median_elapsed_ns']/1e6:.3f} | {a['references']['c']['statistics']['median_elapsed_ns']/1e6:.3f} | {b['references']['c']['statistics']['median_elapsed_ns']/1e6:.3f} | {a['factors']['time_idiomatic_over_c']:.2f} | {b['factors']['time_idiomatic_over_c']:.2f} |\n"
text+='''
Binary-trees now uses the existing ordinary heap Node implementation, including
allocation of every leaf and the same Scope lifetimes. No typed containers,
SubStrings, raw collection storage, or custom allocator was introduced.
Reverse-complement traverses backward once, folds ASCII case, applies the IUPAC
complement switch, and emits reusable 60-character Buffer lines. It also skips
empty stripped fragments, fixing the previous blank-sequence-line bad-arg.
47 reverse-complement cases pass an independent oracle, with old-source parity
except the two cases reproducing that old blank-line failure. Eight positive
tree depths match an independent node-count oracle and the tuned/C programs.

The source diff, oracle, inputs/expected outputs, and correctness receipts are
preserved in `../../evidence/node-buffer/`. Raw native C timings still include
its parallel tree workers; the Node representation does not add parallelism.
'''
(p/'README.md').write_text(text);(charts/'README.md').write_text(text.replace('[recovery guide](../../README.md)','[recovery guide](../../../README.md)').replace('`../../evidence/node-buffer/`','`../../../evidence/node-buffer/`'))
e=root/'evidence/node-buffer';e.mkdir(exist_ok=False)
for f in [scratch/'check.py',scratch/'results.json',scratch/'revcomp-before.x',scratch/'quiet-run.py',scratch/'preserve.py',repo/'debug/shootout-node-buffer-extra-checks.log',repo/'debug/shootout-node-buffer-check.log']:
 zipped(e/(f.name+'.gz'),f.read_bytes())
for name in ('binarytrees','revcomp'):zipped(e/(name+'-after.x.gz'),(repo/f'examples/shootout/benchmarks/{name}/main.x').read_bytes())
diff=subprocess.check_output(['git','diff','522caabf4',r['machine']['repository']['revision'],'--','examples/shootout/benchmarks/binarytrees/main.x','examples/shootout/benchmarks/revcomp/main.x'],cwd=repo);zipped(e/'changes.diff.gz',diff)
idx=json.loads((root/'runs/index.json').read_text());idx['current_run']=run;idx['runs'].append({'run_id':run,'path':run,'publication_revision':publication,'measured_revision':web['measured_revision'],'implementations':r['implementations'],'summary_problem_count':9,'sample_recovery':'original full calibration JSONL and receipts, compressed without changing bytes','historical_source_metric_issue':False});dump(root/'runs/index.json',idx)
# Update the mutable guide's current candidate and append the immutable row.
f=root/'README.md';s=f.read_text();start=s.index('The current public candidate');end=s.index('## Saved runs')
when=datetime.fromisoformat(r['machine']['captured_at_utc'].replace('Z','+00:00'));local=when.astimezone(ZoneInfo('America/Los_Angeles'))
s=s[:start]+f'''The current public candidate is [run {run}](runs/{run}/README.md),
measured from clean source revision `{web['measured_revision']}` and first
published with results in `{publication}`. Run identifiers use UTC.
Observation time: {local.strftime('%Y-%m-%d %H:%M %Z')} / {when.strftime('%Y-%m-%d %H:%M UTC')}.

It covers 76 programs, eight columns, and sixteen fresh-process samples per
program (1,216 observations). All official fixtures and local-profile output
checks passed. Summary charts use the nine problems shared by all columns.
The four available k-nucleotide programs remain in per-problem tables.

'''+s[end:]
s=s.replace('Latest quiet-window calibration after idiomatic source changes','Quiet-window calibration after the first idiomatic changes')
anchor='\n[runs/index.json]';s=s.replace(anchor,f'| [{run}](runs/{run}/README.md) | 8 | 9 | Latest: ordinary Node and Buffer rewrites |\n'+anchor)
f.write_text(s)
f=repo/'site/BENCHMARKS.md';s=f.read_text().replace(oldrun,run)
s=s.replace('the latest\n  run started October 30, 2026 at 20:54 PDT / October 31 at 03:54 UTC.',f"the latest\n  observation was {local.strftime('%Y-%m-%d %H:%M %Z')} / {when.strftime('%Y-%m-%d %H:%M UTC')}.")
f.write_text(s)
# Refresh current gap notes; retain the rejected Map experiment.
rows=[]
for name,v in r['benchmarks'].items():
 a=v['idiomatic']['statistics']['median_elapsed_ns']/1e6;c=v['references']['c']['statistics']['median_elapsed_ns']/1e6;t=v['tuned']['statistics']['median_elapsed_ns']/1e6;rows.append((a-c,name,a,c,t,a/c))
s=f'''# Remaining idiomatic x2c performance gaps

Current run `{run}`, local profile, measured source
`{web['measured_revision']}` on Apple M4 Max. Values are sixteen-sample median
elapsed milliseconds. These selected-program differences do not isolate
language, allocation, or threading overhead. Rows rank absolute excess over C.

| Workload | Idiomatic ms | C ms | Tuned ms | Idiomatic/C | Excess over C ms |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
for gap,name,a,c,t,ratio in sorted(rows,reverse=True):s+=f'| {name} | {a:.3f} | {c:.3f} | {t:.3f} | {ratio:.2f} | {gap:.3f} |\n'
s+=f'''
## Completed source changes

The ordinary Node class and fused Buffer reverse-complement rewrite are now
implemented and validated. The Node class uses ordinary child fields and
allocates every leaf. The Buffer rewrite removes full-string reverse/upper/map
passes and generic per-byte callback dispatch, preserves IUPAC complements and
60-column wrapping, and handles blank sequence lines.

[This run's comparison](runs/{run}/README.md) records before/after medians
alongside C drift. Full runs are separate observations, not alternating pairs.
The earlier n-body pair precomputation, FASTA Buffer reuse, and regex JIT remain
applied. No typed containers, SubStrings, raw storage, custom allocators, or
compiler/runtime changes were introduced by these two rewrites.

## Remaining candidates and limits

- **K-nucleotide:** short String keys, Map reads/writes, and numeric conversions
  need attribution. The obvious-looking `counts[key] += 1` substitution already
  regressed 20-21 percent and lost all twelve pairs at both tested sizes. Keep
  the existing counting loop. Generic dispatch is a hypothesis, not profiled
  attribution; the failed source substitution does not reject all Map work.
- **Spectral-norm and fannkuch-redux:** generic Array access and Var numeric
  conversion remain plausible costs. Typed containers are excluded from the
  idiomatic column. Profile ordinary operations before proposing shared-runtime
  or compiler specialization; no further compliant source fix is demonstrated.
- **Binary-trees:** C uses pthread workers, while the x2c entries remain serial.
  The ordinary Node representation gap to tuned x2c is addressed. Do not call
  the remaining C ratio pure allocation or language overhead. C++ supplies a
  useful serial comparison in the per-problem tables.
- **FASTA and reverse-complement:** ordinary per-line String/output and input
  handling remain candidates for profiling. The Buffer rewrite is not an
  in-place typed-storage implementation. Further gains are unmeasured.

The [paired-probe evidence](evidence/README.md) and older run archives retain
the original hypotheses, results, and rejected Map experiment. Current source
claims follow this latest run rather than silently rewriting older reports.
Java includes startup/JIT. Canonical-size timing remains unrun.
''';(root/'remaining-gaps.md').write_text(s)
f=root/'evidence/README.md';s=f.read_text()+f'''\n## Ordinary Node and Buffer rewrite\n\n`node-buffer/` retains the source diff, old/new source copies, independent\noracle, all 55 extra correctness cases, and focused fixture/quick-profile logs.\nThe original reverse-complement failed on blank sequence lines; the two\nreproduced failure cases are explicit in results. Timing is the full quiet\ncalibration in [run {run}](../runs/{run}/README.md), not these oracle tests.\n''';f.write_text(s)
paths=sorted([q for parent in (root/'runs',root/'evidence') for q in parent.rglob('*') if q.is_file()]+[root/'requirements-charts.txt'])
(root/'SHA256SUMS').write_text(''.join(hashlib.sha256(q.read_bytes()).hexdigest()+'  '+str(q.relative_to(root))+'\n' for q in paths))
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,path=line.split('  ',1);assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest
print('Preserved run',run,'checksummed files',len(paths))
