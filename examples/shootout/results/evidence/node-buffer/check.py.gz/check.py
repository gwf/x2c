from pathlib import Path
import base64,hashlib,json,random,subprocess
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=Path(__file__).resolve().parent
new=repo/'examples/build/shootout/revcomp/idiomatic/program';old=root/'revcomp-before'
alphabet=b'ACGTUMRWSYKVHDBN';pairs=b'TGCAAKYWSRMBDHVN'
complement=dict(zip(alphabet,pairs))
def expected(data):
 out=bytearray();seq=bytearray()
 def flush():
  reverse=bytes(complement.get(c,c) for c in bytes(seq).upper()[::-1])
  for i in range(0,len(reverse),60):out.extend(reverse[i:i+60]+b'\n')
  seq.clear()
 for line in data.splitlines(keepends=True):
  if line.startswith(b'>'):flush();out.extend(line)
  else:seq.extend(line.strip())
 flush();return bytes(out)
cases=[('empty',b''),('empty-records',b'>ONE\n>TWO\n>THREE'),('iupac',b'>THREE\n'+alphabet+alphabet.lower()+b'\n'),('crlf',b'>ONE\r\nacgt\r\n>TWO\r\n'+alphabet.lower()+b'\r\n'),('last-line',b'>THREE\nacgt'),('fallback-ascii',b'>THREE\nxyzXYZ\n')]
for n in (0,1,2,59,60,61,119,120,121,1000):
 s=(alphabet+alphabet.lower())*(n//32+1);s=s[:n]
 cases.append(('length-'+str(n),b'>THREE\n'+s+b'\n'))
cases.append(('blank-lines',b'\n>ONE\nacgt\n\n>TWO\r\n\r\nacgt\r\n'))
rng=random.Random(20261031)
for i in range(30):
 data=bytearray()
 for j in range(1+i%4):
  data.extend(f'>RECORD{j} test\n'.encode());n=rng.randrange(0,800)
  seq=bytes(rng.choice(alphabet+alphabet.lower()) for _ in range(n));width=rng.randrange(1,100)
  for k in range(0,n,width):data.extend(seq[k:k+width]+b'\n')
 cases.append(('random-'+str(i),bytes(data)))
results=[]
for name,data in cases:
 want=expected(data)
 for program in (old,new):
  got=subprocess.run([str(program)],input=data,capture_output=True)
  if program==old and any(not line.strip() for line in data.splitlines()):
   assert got.returncode!=0 and b'<bad-arg>' in got.stderr
   continue
  assert got.returncode==0,(name,program,got.stderr)
  assert not got.stderr and got.stdout==want,(name,program,got.stdout,want)
 results.append({'name':name,'input_base64':base64.b64encode(data).decode(),'expected_base64':base64.b64encode(want).decode(),'input_sha256':hashlib.sha256(data).hexdigest(),'output_sha256':hashlib.sha256(want).hexdigest(),'new_matches_oracle':True,'old_matches_oracle':not any(not line.strip() for line in data.splitlines()),'old_blank_line_bad_arg':any(not line.strip() for line in data.splitlines())})
for depth in (1,4,5,6,7,10,12,14):
 maximum=max(depth,6);nodes=lambda d:(1<<(d+1))-1
 lines=[f'stretch tree of depth {maximum+1}\t check: {nodes(maximum+1)}']
 for d in range(4,maximum+1,2):
  count=1<<(maximum-d+4);lines.append(f'{count}\t trees of depth {d}\t check: {count*nodes(d)}')
 lines.append(f'long lived tree of depth {maximum}\t check: {nodes(maximum)}');want=('\n'.join(lines)+'\n').encode()
 for variant in ('idiomatic','tuned','c'):
  got=subprocess.run([str(repo/f'examples/build/shootout/binarytrees/{variant}/program'),str(depth)],capture_output=True,check=True)
  assert not got.stderr and got.stdout==want,(depth,variant)
 results.append({'name':'binarytrees-'+str(depth),'output_sha256':hashlib.sha256(want).hexdigest(),'idiomatic_tuned_C_match_oracle':True})
(root/'results.json').write_text(json.dumps({'schema':1,'cases':results,'case_count':len(results),'revcomp_case_count':len(cases),'binarytrees_case_count':8},indent=2)+'\n')
print(len(cases),'reverse-complement cases match oracle (old comparison except its reproduced blank-line failure);8 tree depths match idiomatic/tuned/C and oracle')
