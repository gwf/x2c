"""Describe the completed run and retain existing historical archives."""
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
import json,textwrap
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout/results';scratch=Path(__file__).resolve().parent;r=json.loads((root/'current.json').read_text());run=r['run_id'];p=root/'runs'/run;old='20261031T181939Z';d=json.loads((scratch/'decisions.json').read_text());web=json.loads((p/'website.json').read_text());date=datetime.strptime(run,'%Y%m%dT%H%M%SZ').replace(tzinfo=timezone.utc);when=date.strftime('%Y-%m-%d %H:%M UTC');local=date.astimezone(ZoneInfo('America/Los_Angeles')).strftime('%Y-%m-%d %H:%M %Z');source=r['machine']['repository']['revision'];checkpoint=web['report_revision']
assert run != old and r['samples']==56 and len(r['summary_benchmarks'])==8
def local_result(name):return next(v for v in d['comparisons'] if v['problem']==name and v['n']==(512 if name=='mandelbrot' else 100000) and v['candidate']==('buffer' if name=='revcomp' else 'parallel') and v['before']=='before')
table='| Experiment | Input N | Before elapsed ms | Candidate elapsed ms | Before CPU ms | Candidate CPU ms | Paired wins / 12 |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: |\n'
for name in ['regexredux','revcomp','mandelbrot']:
 v=local_result(name);table+=f"| {name} | {v['n']} | {v['before_median_ms']:.3f} | {v['candidate_median_ms']:.3f} | {v['before_cpu_ms']:.3f} | {v['candidate_cpu_ms']:.3f} | {v['paired_wins']} |\n"
notes='''Regex-redux uses nine ordinary Threads for independent counts at cleaned
sequence lengths of at least 65,536 bytes. Each worker owns its Regexp and
retains only a scalar count. The main thread runs the ordered substitution
chain concurrently, joins workers, and prints counts in specification order.
Smaller inputs use the serial path. No Regexp or match-data block is shared.

Reverse-complement keeps the existing input Buffer through `_write`, instead
of converting each complete record into a canonical String. A native
`ptrdiff_t` cursor and the ordinary Buffer.get API avoid narrowing the Buffer
length to int. Complement rules, output lines and record order are unchanged.
The output-line Buffer still uses the existing ordinary String conversion.

Mandelbrot uses at most six ordinary Threads on 16-row chunks per wave at
N>=256. Caller-owned Arrays are filled before startup; each worker replaces
only existing byte-valued slots in its own Array. Joins precede ordered output.
The next wave releases the previous wave's storage, bounding retained output
to 96 rows. Pixel arithmetic and PBM padding are unchanged. Smaller inputs run
serially. A same-batching serial control separates threading from buffering.

The tuned sources and all 55 foreign reference programs remain unchanged.
No compiler/runtime/package code, typed container, borrowed substring, raw
collection access, custom allocator, or literal-C implementation was added.
'''
readme=f'''# Three idiomatic source improvements

Run `{run}`, observed {local} / {when}, measures clean source
`{source}`. Valid results first appear in report checkpoint
`{checkpoint}`; later archive/documentation commits preserve those bytes.
These are configured local measurements, not official published timings or
canonical-size timing.

## Full calibration

All 75 admitted programs pass official fixtures and local output checks.
56 fresh-process samples per program give 4,200 observations. Complete Latin
rotations balance coverage groups of 8, 7 and 4 programs. The same eight
problems are shared by all eight columns; per-problem tables retain all
available k-nucleotide and binary-trees entries. No missing cell is zero.

Measurement follows six consecutive ten-second aggregate-idle samples at
least 90 percent, after all builds and fixtures. Exact observations and process
receipts are preserved in `raw/` and `current.json`. Java includes fresh-JVM
startup and JIT; a separate warmup process does not warm measured JVMs.
The pre-run window does not establish zero background activity throughout.

## Controlled source experiments

Seven timed variants were compiled against the same compiler/runtime: the three
previous sources, three requested candidates, and a batched-serial Mandelbrot
control. All 142 official/edge/oracle checks pass. Padding/wave/cutoff dimensions
and the 47 saved reverse-complement oracle cases are included. Additional
per-workload parity checks precede timing. The 12-round quiet experiment has
372 observations and complete rotating orders for both two- and three-variant
groups. It is separate from this 56-sample full calibration. The earlier
int-index Buffer draft is retained as a review artifact; the tested Buffer
source uses ptrdiff_t/get and avoids the narrowing identified in review.

'''+table+'''
CPU is total user plus system time, including workers. Parallel elapsed-time
wins consume more total CPU in these probes; the Buffer change reduces both.
All three local candidates win all 12 paired rounds. The larger workloads also
show gains. Small regex N=1000 increases about 0.090 ms; its serial N=6500 path
is unchanged within variation, while N=6600 benefits from the parallel path.

'''+notes+'''
## Docker and rejected timing attempts

Gary explicitly authorized temporarily pausing Docker, then restoring it.
The first full attempt passed output checks but late Contacts/Spotlight work
and another validation job overlapped timings. It is retained under the
experiment's `interfered-attempts/`, and supplies none of the final figures.
Docker was restored before waiting again. The guarded retry waits for other
work to settle while Docker runs, then bounds the actual pause-window wait.
Its finally block restores Docker immediately after measurement or an error,
before rendering and publication checks. Pause/resume and container-state
receipts are retained. The preliminary recent-ps readiness estimate is distinct
from the final aggregate-idle criterion. No other apps or jobs were paused.

## Recovery and website integration

- `current.json`, `current.md`, `baseline.json.gz`, `benchmarks.json`: exact run.
- `raw/`: original 4,200 observations, build/check/machine/summary receipts,
  quiet and process observations, log, and the exact one-off wrapper.
- `charts/`: three standard forms and `three-idiomatic-probes`, each in
  PNG/SVG/PDF, plus CSV data, renderers and provenance.
- `website.json`: curated metadata/measurements without host process listings.
- `../../evidence/three-idiomatic/`: before/candidate/control sources, generated
  C, inputs, build/check/oracle receipts, initial and quiet raw samples,
  decisions, Docker evidence, rejected timings and scripts.

To rerender focused probes, decompress `raw-quiet.jsonl.gz`, `build.json.gz`,
`decisions.json.gz` and `quiet-receipt.json.gz` from that evidence directory
into one temporary directory, then run `charts/render-probes.py INPUT_DIR OUT`.
Renderers read saved data only; they do not execute archived binary paths.
Use `../../requirements-charts.txt` for an isolated plotting environment.
The Docker-control wrapper is one-off host-specific evidence, not a recurring
benchmark requirement or an instruction to pause another computer's services.
Follow the normal suite instructions for collecting new data.

All earlier immutable runs remain unchanged. Verify `../../SHA256SUMS`;
see [recovery](../../README.md) and [website notes](../../../../../site/BENCHMARKS.md).
Canonical-size timing remains unrun. No website page or deployment was added.
'''
(p/'README.md').write_text(readme)
(p/'charts/README.md').write_text('''# Saved chart forms

The summary scatter, per-implementation star profiles and runtime/LOC box plots
use the same eight shared problems and all eight series. There are 64 shared
marks and 75 rows in measurements.csv. The scatter uses geometric means;
star centres use arithmetic means. Boxes show variation across problems,
not confidence intervals over timing samples. LOC and compressed bytes differ.

The separate three-idiomatic-probes figure plots elapsed and total CPU medians
with interquartile bands across tested input sizes. Each source/input has 12
fresh-process observations. Its CPU metric sums worker user/system time.
Both Thread cutoffs and the batched-serial control remain visible. This is
separate from the full calibration's 56 samples per program.

```sh
python render.py ../current.json /tmp/shootout-figures
python render-probes.py /tmp/recovered-three-probes /tmp/shootout-figures
```

Use ../../../requirements-charts.txt in an isolated environment. All PNG/SVG/PDF,
CSV and provenance originals are checksum-covered. See [run notes](../README.md).
''')
f=root/'README.md';s=f.read_text();a=s.index('The current public candidate');z=s.index('## Saved runs',a);s=s[:a]+f'''The current public candidate is [run {run}](runs/{run}/README.md),
measured from clean source `{source}` and retained in report checkpoint
`{checkpoint}`. Observation: {local} / {when}. Run identifiers use UTC.

It covers 75 programs, eight columns and 56 fresh-process samples each
(4,200 observations). All official fixtures and local output checks pass.
Summary charts use eight shared problems; complete tables retain all admitted
k-nucleotide and binary-trees cells. Earlier cohorts remain explicitly historical.

'''+s[z:];s=s.replace('Latest: reference audit and parallel k-nucleotide','Reference audit and parallel k-nucleotide');s=s.replace('\n[runs/index.json]',f'| [{run}](runs/{run}/README.md) | 8 | 8 | Latest: parallel regex/Mandelbrot and reverse-complement Buffer |\n\n[runs/index.json]');s=s.replace('gzip -dc runs/'+old,'gzip -dc runs/'+run).replace('results/runs/'+old+'/charts/render.py examples/shootout/results/runs/'+old+'/current.json','results/runs/'+run+'/charts/render.py examples/shootout/results/runs/'+run+'/current.json');s=s.replace('git worktree add --detach /tmp/x2c-shootout-source 246938ba6','git worktree add --detach /tmp/x2c-shootout-source '+checkpoint)
# Replace exact prior checkpoint regardless of abbreviation length.
import re
s=re.sub(r'git worktree add --detach /tmp/x2c-shootout-source [0-9a-f]+','git worktree add --detach /tmp/x2c-shootout-source '+checkpoint,s)
s+=f'''\n## Three idiomatic source probes\n\n`evidence/three-idiomatic/` preserves all seven sources, generated C, command\nreceipts, 142 correctness cases, 372 quiet observations, active-machine initial\nscreen, inputs and Docker restoration evidence, including rejected attempts.\nDecompress the four focused-probe inputs described in\n[run {run}](runs/{run}/README.md) to render without executing benchmarks.\n''';f.write_text(s)
f=root/'threading.md';s=f.read_text()+'''\n## Parallel regex-redux and Mandelbrot\n\n'''+notes;f.write_text(s)
f=repo/'examples/shootout/README.md';s=f.read_text();anchor='Parallelism follows published Benchmarks Game precedent for each problem.';s=s.replace(anchor,notes+'\n'+anchor,1);f.write_text(s)
f=root/'evidence/README.md';f.write_text(f.read_text()+f'''\n## Three idiomatic source experiments\n\n`three-idiomatic/` retains before/candidate/control sources, generated C, inputs,\n142 correctness cases, 93 initial and 372 quiet probe observations, source and\nbinary hashes, decisions, Docker pause/restore evidence and rejected full runs.\nAccepted full calibration: [run {run}](../runs/{run}/README.md).\n''')
f=repo/'site/BENCHMARKS.md';s=f.read_text().replace(old,run).replace('reference-audit-probes.csv','three-idiomatic-probes.csv').replace('2026-10-31 11:19 PDT / 2026-10-31 18:19 UTC',local+' / '+when);a=s.index('The latest run preserves');s=s[:a]+'''The latest run includes `three-idiomatic-probes` in PNG/SVG/PDF/CSV, with\nrenderer and provenance. It compares elapsed and total user/system CPU time\nfor the separate 12-round controlled source experiment. The full report uses\n56 samples per program. State the regex cleaned-byte cutoff, bounded\nMandelbrot row batches, Buffer-preserving reverse-complement boundary, and\nunchanged tuned/reference sources. Docker was temporarily paused with explicit\nauthorization and restored after measurement; do not turn that one-off host\noperation into a site build step or recurring requirement. Earlier experiments\nremain labeled by their original runs. Canonical-size timing is unrun.\n''';f.write_text(s)
rows=[]
for name,b in r['benchmarks'].items():
 x=b['idiomatic']['statistics']['median_elapsed_ns']/1e6;c=b['references']['c']['statistics']['median_elapsed_ns']/1e6;t=b['tuned']['statistics']['median_elapsed_ns']/1e6;best,best_ms=min([(k,v['statistics']['median_elapsed_ns']/1e6) for k,v in b['references'].items()]+[('tuned',t)],key=lambda kv:kv[1]);rows.append((x/best_ms,name,x,c,t,best,best_ms))
s=f'''# Remaining local performance gaps\n\nRun `{run}`, clean source `{source}`, local profile, 56 samples per program.\nThese are selected-program measurements, not general language overhead.\nCanonical-size timing remains unrun. Eight problems share every column;\nk-nucleotide and binary-trees remain available in per-problem rows.\n\n| Problem | Idiomatic ms | C ms | Tuned ms | Fastest selected ms | Idiomatic / fastest |\n| --- | ---: | ---: | ---: | --- | ---: |\n'''
for ratio,name,x,c,t,best,best_ms in sorted(rows,reverse=True):s+=f'| {name} | {x:.3f} | {c:.3f} | {t:.3f} | {best}: {best_ms:.3f} | {ratio:.2f} |\n'
s+='\nThe controlled local source comparisons are:\n\n'+table+'''\nAll three changes win every paired local round and also benefit larger inputs.\nParallelism spends more total CPU for lower elapsed time; the Buffer change\nreduces both metrics. Full-run differences in unchanged programs are not gains\ncaused by these source changes. All 55 foreign source bytes, workload profiles\nand compiler/runtime source are unchanged from the source-probe baseline unless\na separately recorded upstream integration says otherwise.\n\nK-nucleotide still spends substantial time in canonical String slicing/interning\nand Map work. Counter objects and compound Map updates did not help in earlier\nprobes; ordinary width-level threading did. Binary-trees is close to C, while\nfast library-arena Rust references remain much faster; a specialized allocator\nis outside the idiomatic boundary. The remaining reverse-complement cost needs\nfurther profiling before another rewrite. FASTA Choice-record probes did not\nestablish a gain; that rejects the tested source, not every record-based design.\n\nNo additional compiler/runtime redesign is implied by these benchmark gaps.\nSee [recovery](README.md), [threading](threading.md), and the latest run's\nfocused experiment and raw receipts.\n''';(root/'remaining-gaps.md').write_text(s)
print('updated documentation',run)
