"""Preserve a successful full calibration and the three source experiments."""
import json,gzip,hashlib,shutil,subprocess,csv,zipfile
from pathlib import Path
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout/results';scratch=Path(__file__).resolve().parent;build=repo/'examples/build/shootout';r=json.loads((root/'current.json').read_text());run=r['run_id'];p=root/'runs'/run;e=root/'evidence/three-idiomatic';oldrun='20261031T181939Z';decision=json.loads((scratch/'decisions.json').read_text())
assert run!=oldrun and r['samples']==56 and len(r['summary_benchmarks'])==8 and len(r['implementations'])==8 and not r['machine']['repository']['dirty']
assert len((build/'calibration-raw.jsonl').read_text().splitlines())==4200
assert len(json.loads((build/'latest/check.json').read_text())['checks'])==75
assert json.loads((build/'latest/receipt.json').read_text())['run_id']==run
publication=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert subprocess.check_output(['git','show',publication+':examples/shootout/results/current.json'],cwd=repo)==(root/'current.json').read_bytes()
p.mkdir(exist_ok=False);e.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def zipped(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(gzip.compress(data,mtime=0))
for name in ['current.json','current.md']:shutil.copyfile(root/name,p/name)
zipped(p/'baseline.json.gz',(repo/'examples/shootout/baseline.json').read_bytes());shutil.copyfile(repo/'examples/shootout/benchmarks.json',p/'benchmarks.json')
for f in [build/'calibration-raw.jsonl',*(build/'latest'/n for n in ['build.json','check.json','receipt.json','summary.json','summary.md']),repo/'debug/three-idiomatic-calibration.log',repo/'debug/three-idiomatic-quiet-window.jsonl',repo/'debug/three-idiomatic-non-docker-window.jsonl',repo/'debug/three-idiomatic-measurement-processes.jsonl',scratch/'quiet-run.py']:
 zipped(p/'raw'/(f.name+'.gz'),f.read_bytes())
# Preserve experiment inputs/outputs, exact source and generated C, diagnostics,
# observations and scripts. Native executables are rebuilt from recorded commands.
for f in sorted(scratch.rglob('*')):
 if not f.is_file() or f.name=='program' or f.suffix in ['.o','.so','.dylib','.a','.pyc'] or '__pycache__' in f.parts:continue
 zipped(e/(str(f.relative_to(scratch))+'.gz'),f.read_bytes())
for f in sorted((repo/'debug').glob('three-idiomatic-*.log')):zipped(e/'logs'/(f.name+'.gz'),f.read_bytes())
for d in sorted((repo/'debug').glob('three-idiomatic-interfered-*')):
 for f in sorted(d.rglob('*')):
  if f.is_file():zipped(e/'interfered-attempts'/d.name/(str(f.relative_to(d))+'.gz'),f.read_bytes())
refs=[];manifest=json.loads((p/'benchmarks.json').read_text());archive=root/'evidence/reference-profile/benchmarksgame-sourcecode.zip';assert sha(archive)==manifest['specification']['archive_sha256']
with zipfile.ZipFile(archive) as z:
 names=z.namelist()
 for b in manifest['benchmarks']:
  for filename,entry in b['references'].items():
   local=repo/'examples/shootout/benchmarks'/b['name']/filename;members=[n for n in names if n==entry['path'] or n.endswith('/'+entry['path'])];assert len(members)==1;assert local.read_bytes()==z.read(members[0]);assert sha(local)==entry['sha256'];refs.append({'problem':b['name'],'filename':filename,**entry})
dump(e/'source-provenance.json',{'official_archive':'../reference-profile/benchmarksgame-sourcecode.zip','reference_count':len(refs),'unchanged_references':refs,'selected_idiomatic_sources':{name:sha(repo/'examples/shootout/benchmarks'/name/'main.x') for name in decision['adopted']}})
for name,variant in decision['adopted'].items():assert sha(repo/'examples/shootout/benchmarks'/name/'main.x')==sha(scratch/(variant+'.x'))
charts=p/'charts';charts.mkdir();renderer=(root/'runs'/oldrun/'charts/render.py').read_text();count=4+sum(name in decision['adopted'] for name in ['regexredux','mandelbrot']);word={4:'four',5:'five',6:'six'}[count];renderer=renderer.replace('threads in four workloads',f'threads in {word} workloads');modes=[]
if 'regexredux' in decision['adopted']:modes.append('idiomatic regex-redux parallel at cleaned sequence >=65536 bytes')
if 'mandelbrot' in decision['adopted']:modes.append('idiomatic Mandelbrot parallel at N>=256, at most six 16-row batches')
renderer=renderer.replace('idiomatic k-nucleotide counts widths in seven Threads','idiomatic k-nucleotide counts widths in seven Threads'+(' ; '+ '; '.join(modes) if modes else ''))
(charts/'render.py').write_text(renderer);shutil.copyfile(scratch/'render-probes.py',charts/'render-probes.py')
python='/Users/gary/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
subprocess.run([python,str(charts/'render.py'),str(p/'current.json'),str(charts)],check=True);subprocess.run([python,str(charts/'render-probes.py'),str(scratch),str(charts)],check=True)
web={'schema':1,'run_id':run,'measured_revision':r['machine']['repository']['revision'],'publication_revision':publication,'report_revision':publication,'measured_tree_dirty':False,'profile':r['profile'],'cpu_model':r['machine'].get('cpu_model'),'samples':56,'process_warmups':r['warmups'],'implementations':r['implementations'],'summary_benchmarks':r['summary_benchmarks'],'quiet_window':{k:v for k,v in r['machine']['quiet_window'].items() if k in ['criterion','samples']},'java_process_model':'fresh JVM per sample; startup and JIT included; no in-process warmup','historical_source_metric_issue':False,'execution_modes':'Mixed serial/parallel official contributions; '+ '; '.join(modes),'measurements':list(csv.DictReader((charts/'measurements.csv').open()))};dump(p/'website.json',web)
idx=json.loads((root/'runs/index.json').read_text());idx['current_run']=run;idx['runs'].append({'run_id':run,'path':run,'publication_revision':publication,'report_revision':publication,'measured_revision':web['measured_revision'],'implementations':r['implementations'],'summary_problem_count':8,'sample_recovery':'original full calibration JSONL and receipts compressed without changing bytes','historical_source_metric_issue':False});dump(root/'runs/index.json',idx);(scratch/'archived-run.txt').write_text(run+'\n');print('archived',run)
