"""One-off quiet-window orchestration; use the existing measurement owner."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import os
import threading

repo = Path('/Users/gary/.codex/worktrees/f2bc/x2c')
sys.path.insert(0, str(repo / 'examples/shootout/tools'))
import shootout

measure = shootout.calibration_measurements
evidence = repo / 'debug/three-idiomatic-quiet-window.jsonl'


def after_quiet_window(*args, **kwargs):
    consecutive = []
    with evidence.open('w') as log:
        while len(consecutive) < 6:
            result = subprocess.run(
                ['top', '-l', '2', '-s', '10', '-n', '0'],
                capture_output=True, text=True, check=True,
            )
            idle = float(re.findall(r'([\d.]+)% idle', result.stdout)[-1])
            sample = {'captured_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                      'idle_percent': idle}
            log.write(json.dumps(sample) + '\n')
            log.flush()
            if idle >= 90:
                consecutive.append(sample)
            else:
                consecutive.clear()
            print(f'quiet window: {idle:.2f}% idle; {len(consecutive)}/6 consecutive 10-second samples', flush=True)
    print('quiet window established; starting existing calibration measurements', flush=True)
    stop = threading.Event()
    process_evidence = repo / 'debug/three-idiomatic-measurement-processes.jsonl'
    def observe_processes():
        with process_evidence.open('w') as log:
            while not stop.is_set():
                output = subprocess.check_output(
                    ['ps', '-axo', 'pid=,ppid=,%cpu=,comm='], text=True)
                rows = [line.strip().split(None, 3) for line in output.splitlines()]
                rows = [row for row in rows if len(row) == 4]
                owned = {os.getpid()}
                while True:
                    children = {int(row[0]) for row in rows if int(row[1]) in owned}
                    if children <= owned: break
                    owned |= children
                external = [row for row in rows if int(row[0]) not in owned]
                value = {
                    'captured_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                    'external_ps_cpu_percent_sum': sum(float(row[2]) for row in external),
                    'external_busy_processes': [row for row in external if float(row[2]) >= 20],
                    'metric': 'ps recent process CPU estimates; not aggregate instantaneous CPU idle',
                }
                log.write(json.dumps(value) + '\n'); log.flush()
                stop.wait(10)
    observer = threading.Thread(target=observe_processes, daemon=True)
    observer.start()
    try:
        calibration = measure(*args, **kwargs)
    finally:
        stop.set()
        observer.join()
    calibration['machine']['measurement_process_observations'] = str(process_evidence.relative_to(repo))
    calibration['machine']['quiet_window'] = {
        'criterion': 'at least 90 percent CPU idle in six consecutive 10-second samples after builds and fixture checks',
        'samples': consecutive,
        'evidence': str(evidence.relative_to(repo)),
        'orchestration_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    return calibration


shootout.calibration_measurements = after_quiet_window
raise SystemExit(shootout.main())
