# x2c Benchmarks Game result

- Run: `20261031T205323Z`
- Baseline: `2159d9cbc23b0d76`
- Profile: `local`
- Samples: 56 fresh-process x2c measurements after 1 warmup(s)
- `idiomatic` is `main.x`, using ordinary x2c collections and APIs.
  `tuned` is `tuned.x`, using typed containers and other
  x2c optimizations within the same official specification.
- C, Python, Rust, C++, Go, and Java are unchanged contributed programs.
  These are local measurements, not the official site's timings.
- Java starts a fresh JVM per sample, including startup and JIT compilation.
  The separate process warmup does not warm the measured JVM.
- Time uses C as the implicit 1.00 baseline; SLOC uses Python as the
  implicit 1.00 baseline. Larger values mean more cost.
- N/A means there is no admitted contribution for that problem.
- Summary rows use only the 8 problems shared by every column:
  nbody, spectralnorm, fannkuchredux, mandelbrot, fasta, revcomp, regexredux, pidigits

## Elapsed time / C

| Benchmark | C | idiomatic x2c | tuned x2c | Python | Rust | C++ | Go | Java |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| nbody | 1.00 | 2.04 | 2.12 | 78.32 | 1.29 | 0.91 | 1.01 | 2.20 |
| spectralnorm | 1.00 | 3.65 | 1.64 | 52.48 | 1.18 | 1.51 | 0.86 | 9.79 |
| fannkuchredux | 1.00 | 2.74 | 3.63 | 19.62 | 0.76 | 0.81 | 2.42 | 11.34 |
| mandelbrot | 1.00 | 1.56 | 3.52 | 28.67 | 0.82 | 1.05 | 1.53 | 11.80 |
| fasta | 1.00 | 5.40 | 3.92 | 20.65 | 2.66 | 1.04 | 1.96 | 10.43 |
| knucleotide | 1.00 | 9.61 | 8.12 | 7.69 | N/A | N/A | N/A | N/A |
| revcomp | 1.00 | 6.78 | 7.46 | 8.78 | 1.40 | 11.25 | 1.52 | 16.99 |
| binarytrees | 1.00 | 1.08 | 1.08 | N/A | 0.14 | 0.31 | 0.70 | 1.49 |
| regexredux | 1.00 | 2.14 | 4.55 | 5.64 | 0.95 | 2.10 | 13.46 | 9.50 |
| pidigits | 1.00 | 1.04 | 1.00 | 1.42 | 1.00 | 1.05 | 2.69 | 11.11 |
| **Median** | **1.00** | **2.44** | **3.57** | **20.13** | **1.09** | **1.05** | **1.75** | **10.77** |
| **Arithmetic mean** | **1.00** | **3.17** | **3.48** | **26.95** | **1.26** | **2.46** | **3.18** | **10.39** |

## Source lines / Python

| Benchmark | C | idiomatic x2c | tuned x2c | Python | Rust | C++ | Go | Java |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| nbody | 1.38 | 1.15 | 1.15 | 1.00 | 2.26 | 1.62 | 1.37 | 1.54 |
| spectralnorm | 1.50 | 2.06 | 1.28 | 1.00 | 2.53 | 0.97 | 2.08 | 1.17 |
| fannkuchredux | 1.01 | 1.14 | 0.54 | 1.00 | 1.12 | 1.42 | 1.47 | 0.60 |
| mandelbrot | 2.09 | 1.67 | 0.91 | 1.00 | 4.42 | 2.24 | 2.00 | 1.42 |
| fasta | 2.11 | 1.05 | 1.00 | 1.00 | 0.81 | 1.76 | 2.61 | 2.02 |
| knucleotide | 0.87 | 0.41 | 0.34 | 1.00 | N/A | N/A | N/A | N/A |
| revcomp | 2.32 | 1.38 | 1.03 | 1.00 | 3.68 | 1.41 | 1.74 | 4.32 |
| binarytrees | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A |
| regexredux | 1.02 | 0.52 | 0.42 | 1.00 | 0.46 | 2.54 | 0.62 | 0.43 |
| pidigits | 0.87 | 1.52 | 1.56 | 1.00 | 2.87 | 0.96 | 1.65 | 1.87 |
| **Median** | **1.44** | **1.26** | **1.01** | **1.00** | **2.39** | **1.52** | **1.69** | **1.48** |
| **Arithmetic mean** | **1.54** | **1.31** | **0.98** | **1.00** | **2.27** | **1.62** | **1.69** | **1.67** |


The median and the mean are orientation aids, not composite scores.
Read individual workloads; these summaries are not a language ranking.
