"""Build and compare only three authorized idiomatic source experiments."""
import base64,json,sys,gzip,subprocess,hashlib,datetime as dt,collections,statistics,re
from pathlib import Path
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'examples/shootout/tools'));import shootout as s
manifest=s.load_manifest();bs={b['name']:b for b in manifest['benchmarks']}
prior=json.loads(gzip.decompress((s.ROOT/'results/runs/20261031T181939Z/raw/build.json.gz').read_bytes()))
variants={'regexredux':['before','parallel'],'revcomp':['before','buffer'],'mandelbrot':['before','batched-serial','parallel']}
def save(name,value):(root/name).write_text(json.dumps(value,indent=2)+'\n')
def build():
 receipts=[]
 for problem,kinds in variants.items():
  old=prior['benchmarks'][problem]['idiomatic']
  for kind in kinds:
   name=problem+'-'+kind;source=root/(name+'.x');d=root/'build'/name;gen=d/'generated';gen.mkdir(parents=True,exist_ok=True);binary=d/'program'
   translate=list(old['translate_command']);translate[translate.index('--out-dir')+1]=str(gen);translate[-1]=str(source)
   compile=[str(gen/(name+'.c')) if x.endswith('/idiomatic/generated/main.c') else str(binary) if x.endswith('/idiomatic/program') else x for x in old['compile_command']]
   for step,argv in [('translate',translate),('compile',compile)]:
    p=subprocess.run(argv,cwd=repo,capture_output=True);(d/(step+'.stdout')).write_bytes(p.stdout);(d/(step+'.stderr')).write_bytes(p.stderr)
    if p.returncode:raise RuntimeError(f'{name} {step} failed: {(d/(step+".stderr")).read_text()}')
   receipts.append({'id':name,'problem':problem,'source_sha256':s.sha256(source),'binary_sha256':s.sha256(binary),'translate':translate,'compile':compile})
   print('built',name,flush=True)
 save('build.json',{'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'compiler_sha256':s.sha256(repo/'builds/0/x2c'),'runtime_sha256':s.sha256(repo/'builds/0/libx2c.a'),'variants':receipts})
def binary(name):return root/'build'/name/'program'
def check():
 records=[]
 for problem,kinds in variants.items():
  b=bs[problem];base=s.ROOT/'benchmarks'/problem
  for kind in kinds:
   name=problem+'-'+kind
   for index,c in enumerate(b['checks']):
    out=s.run_captured(binary(name),c['args'],120,base/c['stdin'] if c.get('stdin') else None);s.compare_output(problem,name,c,(base/c['expected']).read_bytes(),out);records.append({'id':name,'official_case':index,'stdout_sha256':hashlib.sha256(out).hexdigest()})
 for n in [1,2,7,8,9,15,16,17,63,64,65,95,96,97,127,128,129,199,200,255,256,257,288,289,511,512,513,1024]:
  want=s.run_captured(binary('mandelbrot-before'),[str(n)],120)
  for kind in variants['mandelbrot'][1:]:
   name='mandelbrot-'+kind;out=s.run_captured(binary(name),[str(n)],120);assert want==out,(name,n);records.append({'id':name,'n':n,'stdout_sha256':hashlib.sha256(out).hexdigest(),'comparison':'exact original scalar PBM including padding'})
 # Retain the established DNA edge/oracle corpus, not a replacement specification.
 for path in sorted((s.ROOT/'results/evidence/counter-spectral/inputs').glob('*.fasta.gz')):
  inp=root/'edge.fasta';inp.write_bytes(gzip.decompress(path.read_bytes()))
  for problem in ['revcomp','regexredux']:
   before=s.run_captured(binary(problem+'-before'),[],120,inp)
   name=problem+'-'+variants[problem][1];out=s.run_captured(binary(name),[],120,inp);assert before==out,(name,path);records.append({'id':name,'input':str(path.relative_to(s.ROOT)),'input_sha256':s.sha256(inp),'stdout_sha256':hashlib.sha256(out).hexdigest(),'comparison':'exact prior idiomatic output'})
 corpus=json.loads(gzip.decompress((s.ROOT/'results/evidence/node-buffer/results.json.gz').read_bytes()))
 for case in corpus['cases']:
  if 'input_base64' not in case:continue
  inp=root/'edge.fasta';inp.write_bytes(base64.b64decode(case['input_base64']));expected=base64.b64decode(case['expected_base64']);out=s.run_captured(binary('revcomp-buffer'),[],120,inp);assert out==expected,case['name'];records.append({'id':'revcomp-buffer','oracle_case':case['name'],'input_sha256':s.sha256(inp),'stdout_sha256':hashlib.sha256(out).hexdigest()})
 save('check.json',{'checks':records});print('checked',len(records),'official, PBM-edge and DNA-oracle cases',flush=True)
def inputs():
 d=root/'inputs';d.mkdir(exist_ok=True)
 for n in [1000,6500,6600,10000,100000,1000000]:
  p=d/(str(n)+'.fasta')
  if not p.exists():
   with p.open('wb') as f:subprocess.run([str(s.BUILD/'tools/fasta-input'),str(n)],stdout=f,check=True)
 save('inputs.json',[{'n':int(p.stem),'bytes':p.stat().st_size,'sha256':s.sha256(p)} for p in d.glob('*.fasta')])
def measure(rounds,quiet):
 if quiet:
  consecutive=[]
  with (root/'quiet-window.jsonl').open('a') as log:
   while len(consecutive)<6:
    p=subprocess.run(['top','-l','2','-s','10','-n','0'],capture_output=True,text=True,check=True);idle=float(re.findall(r'([\d.]+)% idle',p.stdout)[-1]);v={'at':dt.datetime.now(dt.timezone.utc).isoformat(),'idle_percent':idle};log.write(json.dumps(v)+'\n');log.flush()
    if idle>=90:consecutive.append(v)
    else:consecutive=[]
    print('quiet',idle,len(consecutive),flush=True)
  save('quiet-receipt.json',{'samples':consecutive,'rounds':rounds,'script_sha256':s.sha256(Path(__file__))})
 workloads=[('regexredux',n) for n in [1000,6500,6600,100000,1000000]]+ [('revcomp',n) for n in [1000,100000,1000000]]+ [('mandelbrot',n) for n in [64,128,256,512,1024]]
 raw=root/('raw-quiet.jsonl' if quiet else 'raw-initial.jsonl')
 with raw.open('w') as f:
  for problem,n in workloads:
   names=[problem+'-'+kind for kind in variants[problem]];args=[str(n)] if problem=='mandelbrot' else [];inp=None if args else root/'inputs'/(str(n)+'.fasta');want=s.run_captured(binary(names[0]),args,120,inp)
   for name in names:
    out=s.run_captured(binary(name),args,120,inp);assert want==out,(name,n);s.measure_once(s.BUILD/'tools/measure',binary(name),args,120,inp)
   for turn in range(rounds):
    order=names[turn%len(names):]+names[:turn%len(names)]
    for position,name in enumerate(order):
     value=s.measure_once(s.BUILD/'tools/measure',binary(name),args,120,inp);f.write(json.dumps({'problem':problem,'n':n,'id':name,'turn':turn,'position':position,'at':dt.datetime.now(dt.timezone.utc).isoformat(),**value})+'\n');f.flush()
   print('measured',problem,n,rounds,flush=True)
if __name__=='__main__':
 action=sys.argv[1]
 if action=='prepare':build();inputs();check()
 elif action=='check':check()
 elif action=='initial':measure(3,False)
 elif action=='quiet':measure(12,True)
