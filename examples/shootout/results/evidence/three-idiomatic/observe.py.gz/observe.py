"""One-off background-load evidence for a running source probe."""
import os,sys,time,json,datetime as dt,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent;target=int(sys.argv[1])
with (root/'process-observations.jsonl').open('w') as log:
 while True:
  rows=[line.strip().split(None,3) for line in subprocess.check_output(['ps','-axo','pid=,ppid=,%cpu=,comm='],text=True).splitlines()];rows=[r for r in rows if len(r)==4]
  if not any(int(r[0])==target for r in rows):break
  owned={target,os.getpid()}
  while True:
   children={int(r[0]) for r in rows if int(r[1]) in owned}
   if children<=owned:break
   owned|=children
  external=[r for r in rows if int(r[0]) not in owned]
  record={'at':dt.datetime.now(dt.timezone.utc).isoformat(),'phase':'measuring' if (root/'quiet-receipt.json').exists() else 'waiting','external_ps_cpu_percent_sum':sum(float(r[2]) for r in external),'busy_processes':[r for r in external if float(r[2])>=20],'metric':'ps recent CPU estimates, not instantaneous aggregate idle'}
  log.write(json.dumps(record)+'\n');log.flush();time.sleep(10)
