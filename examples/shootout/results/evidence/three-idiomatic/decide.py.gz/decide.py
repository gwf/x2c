"""Decide each requested source experiment from preserved quiet samples."""
import json,collections,statistics,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent;raw=root/'raw-quiet.jsonl';values=[json.loads(l) for l in raw.read_text().splitlines()];assert len(values)==372 and all(v['exit_code']==v['signal']==0 for v in values)
groups=collections.defaultdict(dict)
for v in values:groups[(v['problem'],v['n'],v['id'])][v['turn']]=v
assert set(len(v) for v in groups.values())=={12}
def compare(problem,n,kind,before='before'):
 a=groups[(problem,n,problem+'-'+before)];b=groups[(problem,n,problem+'-'+kind)];old=statistics.median(v['elapsed_ns'] for v in a.values());new=statistics.median(v['elapsed_ns'] for v in b.values());wins=sum(b[k]['elapsed_ns']<a[k]['elapsed_ns'] for k in a)
 return {'problem':problem,'n':n,'before':before,'candidate':kind,'before_median_ms':old/1e6,'candidate_median_ms':new/1e6,'ratio':new/old,'paired_wins':wins,'samples':12,'before_cpu_ms':statistics.median(v['user_ns']+v['system_ns'] for v in a.values())/1e6,'candidate_cpu_ms':statistics.median(v['user_ns']+v['system_ns'] for v in b.values())/1e6}
comparisons=[];adopted={}
for problem,ns,kinds in [('regexredux',[1000,6500,6600,100000,1000000],['parallel']),('revcomp',[1000,100000,1000000],['buffer']),('mandelbrot',[64,128,256,512,1024],['batched-serial','parallel'])]:
 for n in ns:
  for kind in kinds:comparisons.append(compare(problem,n,kind))
local={p:compare(p,512 if p=='mandelbrot' else 100000,'buffer' if p=='revcomp' else 'parallel') for p in ['regexredux','revcomp','mandelbrot']}
large={p:compare(p,1024 if p=='mandelbrot' else 1000000,'buffer' if p=='revcomp' else 'parallel') for p in local}
for p in local:
 a,b=local[p],large[p];clear=any(v['ratio']<=.95 and v['paired_wins']>=9 for v in [a,b]);no_local_regression=a['ratio']<=1.03
 if p=='mandelbrot':
  control=compare(p,512,'parallel','batched-serial');comparisons.append(control);clear=clear and control['ratio']<=.95 and control['paired_wins']>=9
 if clear and no_local_regression:adopted[p]=p+('-buffer' if p=='revcomp' else '-parallel')
result={'criterion':'At least 5 percent median reduction and 9/12 paired wins at local or larger verified workload; local median no more than 3 percent slower. Small serial-path absolute differences are assessed against fresh-process startup variation. Mandelbrot parallel must also beat the batched-serial control at local size.','adopted':adopted,'comparisons':comparisons,'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest()};(root/'decisions.json').write_text(json.dumps(result,indent=2)+'\n')
for p in local:print(p,'ADOPT' if p in adopted else 'retain before','local',local[p],'larger',large[p])
