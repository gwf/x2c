"""One-off quiet calibration with bounded Docker pause and guaranteed resume."""
import datetime as dt
import hashlib,json,os,re,subprocess,sys,threading,time
from pathlib import Path
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');scratch=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'examples/shootout/tools'));import shootout
measure=shootout.calibration_measurements
socket='/Users/gary/Library/Containers/com.docker.docker/Data/backend.sock'
def api(path,post=False):
 argv=['curl','--max-time','10','--silent','--show-error','--fail','--unix-socket',socket]
 if post:argv+=['-X','POST']
 value=subprocess.check_output(argv+['http://localhost'+path],text=True)
 return json.loads(value) if value.strip() else None
def process_rows():
 rows=[r.strip().split(None,3) for r in subprocess.check_output(['ps','-axo','pid=,ppid=,%cpu=,comm='],text=True).splitlines()]
 return [r for r in rows if len(r)==4]
def owned_pids(rows):
 owned={os.getpid()}
 while True:
  children={int(r[0]) for r in rows if int(r[1]) in owned}
  if children<=owned:return owned
  owned|=children
def wait_other_work():
 # The final aggregate-idle criterion still uses top after Docker is paused.
 # This preliminary estimate avoids interrupting services while unrelated work
 # is visibly busy. Exclude only a VM whose open disk proves Docker ownership.
 candidates=[int(r[0]) for r in process_rows() if 'com.apple.Virtualization.VirtualMachine' in r[3]];docker_pids=set()
 for pid in candidates:
  p=subprocess.run(['lsof','-p',str(pid),'-Fn'],capture_output=True,text=True)
  if '/com.docker.docker/Data/vms/' in p.stdout and 'Docker.raw' in p.stdout:docker_pids.add(pid)
 consecutive=[]
 with (repo/'debug/three-idiomatic-non-docker-window.jsonl').open('w') as log:
  while len(consecutive)<6:
   rows=process_rows();exclude=owned_pids(rows)|docker_pids;external=[r for r in rows if int(r[0]) not in exclude]
   cpu=sum(float(r[2]) for r in external);v={'at':dt.datetime.now(dt.timezone.utc).isoformat(),'non_docker_external_ps_cpu_percent':cpu,'excluded_verified_docker_vm_pids':sorted(docker_pids),'busy':[r for r in external if float(r[2])>=20],'metric':'recent ps estimates, not aggregate idle'};log.write(json.dumps(v)+'\n');log.flush()
   if cpu<=80:consecutive.append(v)
   else:consecutive=[]
   print(f'waiting with Docker running: non-Docker recent CPU {cpu:.1f}%; {len(consecutive)}/6',flush=True)
   if len(consecutive)<6:time.sleep(10)
 return consecutive

def after_quiet_window(*args,**kwargs):
 prior=api('/pause/status')
 if prior.get('isPaused'):raise shootout.HarnessError('Docker was already paused before this attempt; inspect ownership before continuing')
 readiness=wait_other_work();stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ');receipt=scratch/f'docker-cycle-{stamp}.json'
 cycle={'before':prior,'pause_requested_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'restore_required':True,'preliminary_readiness_samples':readiness,'method':'existing Docker Desktop dashboard backend API; no stop/restart'}
 def save():receipt.write_text(json.dumps(cycle,indent=2)+'\n')
 save();stop=threading.Event();observer=None
 try:
  api('/pause',True);cycle['paused_status']=api('/pause/status');assert cycle['paused_status']['isPaused'];save()
  consecutive=[];deadline=time.monotonic()+150
  with (repo/'debug/three-idiomatic-quiet-window.jsonl').open('w') as log:
   while len(consecutive)<6:
    if time.monotonic()>deadline:raise shootout.HarnessError('No quiet window within bounded Docker pause; restoring services for a later retry')
    p=subprocess.run(['top','-l','2','-s','10','-n','0'],capture_output=True,text=True,check=True);idle=float(re.findall(r'([\d.]+)% idle',p.stdout)[-1]);v={'captured_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'idle_percent':idle};log.write(json.dumps(v)+'\n');log.flush()
    if idle>=90:consecutive.append(v)
    else:consecutive=[]
    print(f'quiet window: {idle:.2f}% idle; {len(consecutive)}/6',flush=True)
  process_evidence=repo/'debug/three-idiomatic-measurement-processes.jsonl'
  def observe():
   with process_evidence.open('w') as log:
    while not stop.is_set():
     rows=process_rows();owned=owned_pids(rows);external=[r for r in rows if int(r[0]) not in owned];log.write(json.dumps({'captured_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'external_ps_cpu_percent_sum':sum(float(r[2]) for r in external),'external_busy_processes':[r for r in external if float(r[2])>=20],'metric':'ps recent CPU estimates, not instantaneous aggregate idle'})+'\n');log.flush();stop.wait(10)
  observer=threading.Thread(target=observe,daemon=True);observer.start();print('quiet established; existing calibration owner starts timing',flush=True)
  calibration=measure(*args,**kwargs)
  calibration['machine']['quiet_window']={'criterion':'at least90percent CPU idle for six consecutive10-second samples after builds and fixtures','samples':consecutive,'evidence':'debug/three-idiomatic-quiet-window.jsonl','orchestration_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
  calibration['machine']['measurement_process_observations']=str(process_evidence.relative_to(repo));calibration['machine']['docker_pause_receipt']=str(receipt)
  return calibration
 finally:
  stop.set()
  if observer:observer.join()
  # Restore even on failed output checks, interruption or timing errors.
  status=api('/pause/status')
  if status.get('isPaused'):api('/unpause',True)
  cycle['restored_status']=api('/pause/status');cycle['restored_at_utc']=dt.datetime.now(dt.timezone.utc).isoformat();cycle['restore_required']=bool(cycle['restored_status'].get('isPaused'));save()
  if cycle['restore_required']:raise shootout.HarnessError('Docker restore did not finish; inspect pause receipt')
  print('Docker restored after measurement attempt',flush=True)
shootout.calibration_measurements=after_quiet_window
raise SystemExit(shootout.main())
