# Official shootout delivery evidence

Scope: replace the active custom suite with the ten official Benchmarks Game
problems, two x2c variants, and unchanged contributed C/Python references.
The former suite and its measurements are preserved in shootout-unofficial.

Reviewed all 20 x2c sources against the pinned official specifications.
Independent numeric and cross-family reviews found no remaining material issue.
A separate harness review verified 43 official reference/spec/fixture files
byte-for-byte, stdin inheritance, package link precedence, and baseline identity.
Metadata was consolidated into one benchmarks.json rather than duplicated
per-directory fragments. No compiler, runtime, or package source changed.

Validation completed before publication:
- make build-safe (debug/bootstrap.log).
- All four programs match every official fixture (40 checks).
- All four programs match the quick profile for every problem.
- Workers additionally checked alternate inputs and PBM padding.
- Twelve-sample local calibration passed all ten problems, all four programs.
- A one-sample full pinned run passed both x2c variants against that baseline.
- Snapshot collector tests: 20 passed.
- git diff --check passed.

The full canonical performance profile was not executed. It is recorded from
the upstream specifications and can be selected explicitly for calibration/run.
The checked-in results identify the local profile and retain every sample.

Native dependencies: existing pinned PCRE2 package and installed GMP.
The k-nucleotide reference vendors pinned klib khash.h. The unchanged Python
reference uses an explicit fork launcher to preserve its upstream Linux model.

Publication is owned by the parent orchestrator in direct delivery mode.
The existing publication gate runs once for the combined batch; logs remain
under debug/land-dev-latest/. Generated artifacts are reviewed before push.
