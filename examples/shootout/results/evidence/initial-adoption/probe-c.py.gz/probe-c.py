import importlib.util,json,subprocess,sys,shutil,time
from pathlib import Path
from types import SimpleNamespace
root=Path.cwd(); path=root/'examples/shootout/tools/shootout.py'
spec=importlib.util.spec_from_file_location('shootout',path);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
m=h.load_manifest();tc=h.resolve_toolchain(SimpleNamespace(cc='cc',python=sys.executable,action='check',cflags=h.DEFAULT_CFLAGS))
out=Path('/tmp/x2c-c-reference-sanity-20261030');out.mkdir(exist_ok=True)
records=[]
for b in m['benchmarks']:
 name=b['name'];d=out/name;d.mkdir(exist_ok=True);s=h.ROOT/'benchmarks'/name/'main.c';copy=d/'reference.x';shutil.copyfile(s,copy)
 cpp,ld=h.native_flags(b)
 flags=[*cpp,*tc['cppflags'],'-I',str(s.parent)]
 trans=[str(tc['x2c']),'translate','--cpp',*flags,'--out-dir',str(d/'generated'),str(copy)]
 r=subprocess.run(trans,capture_output=True,text=True)
 record={'name':name,'source_sha256':h.sha256(s),'copy_sha256':h.sha256(copy),'translate_command':trans,'translate_status':r.returncode}
 (d/'translate.log').write_text(r.stdout+r.stderr)
 if r.returncode==0:
  cc=[tc['cc'],*tc['cflags'],*flags,str(d/'generated/reference.c'),'-iquote',str(tc['include']),'-L',str(root/'builds/0'),'-lx2c','-lm',*ld,*tc['ldflags'],*b.get('c_flags',[]),*b.get('c_link_flags',[]),'-o',str(d/'program')]
  r=subprocess.run(cc,capture_output=True,text=True);record.update(compile_command=cc,compile_status=r.returncode);(d/'compile.log').write_text(r.stdout+r.stderr)
  if r.returncode==0:
   for case in b['checks']:
    actual=h.run_captured(d/'program',case['args'],120,(s.parent/case['stdin']) if case.get('stdin') else None)
    try:h.compare_output(name,'c-through-x2c',case,(s.parent/case['expected']).read_bytes(),actual);record['official_fixture']='pass'
    except Exception as e:record['official_fixture']=str(e)
 records.append(record);(out/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(name,record.get('translate_status'),record.get('compile_status'),record.get('official_fixture'),flush=True)
