# Go and Java official reference audit

Static read-only audit against the pinned archive and repository specs at c77b6020c.
Archive root: /tmp/x2c-official-benchmarksgame-sources-20261030.
No candidate execution, builds, tests, timing, networking, or repository edits were performed.
Rankings identify plausible probes, not measured improvements. The accompanying JSON lists18 candidate records with absolute archive paths. All shortlisted candidates use standard libraries and contain no explicit ISA-specific intrinsics or assembly. Reference source bytes must remain unchanged.

Java entry class names are the problem names (nbody, spectralnorm, fannkuchredux, mandelbrot, fasta, revcomp, binarytrees, regexredux, pidigits). Compile each candidate in an isolated directory under its canonical Java filename; auxiliary classes remain in the same source file.

## nbody

Current: Go nbody.go-8.go; Java nbody.java-2.java.

Probe Go nbody.go-3.go: separate Position/Momentum arrays (27-32), cached outer-body velocity (62-84). Probe Java nbody.java-4.java first: fixed five-body bound (23), cached outer mass/position (47-72). Java nbody.java-5.java is second: flat primitive double array (23-34,103-141). All are serial. Exact nine-decimal output still requires configured fixture checks.

## spectralnorm

Current: Go spectralnorm.go-8.go; Java spectralnorm.java-8.java, both serial.

Go spectralnorm.go-4.go uses four row goroutines per matrix phase (19,53-63,75). Go spectralnorm.go-2.go uses twice NumCPU workers (19,70-90,106-126), potentially oversubscribing. Both retain matrix-element, matrix-vector, transposed-vector, and composite functions.

Java spectralnorm.java-2.java keeps availableProcessors workers throughout the iterations using CyclicBarrier (38-39,102-107,149-158). Four algorithm roles are eval_A, MultiplyAv, MultiplyAtv, MultiplyAtAv. Prefer this to Java-3, which creates workers afresh for40 phases. Java-2 uses locale-sensitive DecimalFormat (16); validate exact output in the actual harness environment.

## fannkuchredux

Current: Go fannkuchredux.go-8.go; Java fannkuchredux.java-2.java, both serial.

Go base uses approximately720 chunks and GOMAXPROCS4 with channel result reduction (25-26,132-146). Go-2 is similar but hardcodes GOMAXPROCS256, a possible scheduling cost. Configured official/local n values need correctness checks; small unsupported n can fail.

Java base uses150 chunks, atomic task assignment, private primitive arrays, availableProcessors workers (13,43,74,124,158). Java-3 explicitly fixes one worker and is not a parallel candidate. Avoid Go-3: ordinary shared res read mixes with atomic writes (131-132); it also initializes maximum flips1 for tiny n.

## mandelbrot

Current: Go mandelbrot.go-8.go; Java mandelbrot.java-8.java, both serial.

Go-4 uses paired-pixel arithmetic, precomputed coordinates, atomic row assignment, twice NumCPU workers (43,60-61,107,114-145). Go-6 uses four workers and a row queue (26,97). Both allocate n/8 bytes per row, requiring n divisible8. Go-6 starts fewer than four workers for n<4 but waits for four completions.

Java-4 uses parallel IntStream rows and a contiguous bitmap (45-59). Java-6 uses twice availableProcessors threads and atomic row assignment (59-76). Both round up row bytes but do not explicitly zero non-image padding bits. Configured official200, local512, and canonical16000 are divisible8. Exact PBM bytes must pass fixtures.

## fasta

Current: Go fasta.go; Java fasta.java-2.java.

Probe Go-2: naive LCG calculation and unscaled cumulative probabilities (37-41,75-76), linear lookup (93-101), ordered finite buffers of freshly generated random numbers (111-150). There is no reused precomputed RNG sequence or139968-symbol table.

Reject Go-3 under the pinned spec: it multiplies cumulative probabilities by IM. Java-5 and Java-6 preload six61440-character buffers and always drain them even for small requested n, so unchanged sources cannot produce exact n1000 fixture output. Java-4 uses float reciprocal RNG multiplication (205-208), conflicting with a strict naive-arithmetic interpretation. Keep current Java-2. Java-8 is deliberately naive line-at-a-time output and has no clear static advantage.

Pinned spec: examples/shootout/specs/fasta.html forbids optimized cumulative lookup/scaling and optimized naive LCG arithmetic, requires linear/binary search, and forbids caching the random sequence. Archived submission status alone is insufficient.

## revcomp

Current: Go revcomp.go-2.go; Java revcomp.java-5.java.

Probe Go-6 with fixtures: CPU-count transform workers and an output worker, fixed60-column output (16,70-91,131-166). Initial sequence capacity is approximately126MB, plus roughly2MB output buffers per CPU. Memory cost is material. Existing configured inputs use60-column lines.

Go base and Go-5 use i<j reversal loops that can leave an odd central nucleotide uncomplemented; do not prefer them without specific correctness evidence. Java-6 and Java-7 size input with System.in.available(), unsuitable for general piped input. Java-3 stops reading after first short read and uses unsynchronized completion flags. Keep Java-5.

## binarytrees

Current: Go binarytrees.go; Java binarytrees.java-2.java, both serial.

Go-5 uses identical ordinary Node allocations for leaves/interiors (28-32,37,56), four execution threads and per-depth tasks (107,126-145). It checks stretch, creates long-lived, then starts repeated trees. Java-7 uses full identical TreeNode allocations (62-66) and a CPU-count per-depth executor (18,32-38). Neither uses custom allocation pools or GC tuning. Java-7 awaitTermination120seconds (52) requires canonical-size completion confirmation.

Java-4 creates an executor but submits only ONE runBenchmark task; it is not parallel benchmark work. Go-2 overlaps stretch and long-lived creation; Go-3 checks long-lived before repeated work completes. Prefer Go-5/Java-7 for clearer agreement with the pinned work sequence.

Pinned spec requires full per-node work, identical allocations for leaf/interior nodes, default GC where possible, and no custom arena/free-list. These candidates meet those static representation requirements.

## regexredux

Current: Go regexredux.go, already parallel; Java regexredux.java, serial.

Keep current Go base: nine concurrent counts and concurrent substitutions. Go-3 adds concurrent initialization but uses allocating FindAll collections, without a clear static advantage. Go-4/-5 require external PCRE bindings.

Probe Java-6: CompletableFuture substitutions plus parallelStream Matcher.results counts (33-59), ordered output (61), all stdlib. Java-3 splitAsStream().count()-1 can undercount an ending match. Java-2 needs generated jextract_pcre2.pcre2_h, FFM and native PCRE2; not a self-contained replacement.

## pidigits

Current: Go pidigits.go-7.go; Java pidigits.java.

Keep both. Current Go-7 is SERIAL math/big, not threaded. Go-6 is effectively the same arithmetic plus GOMAXPROCS1. Other fast-looking Go variants require cgo/GMP. Java alternatives require JNI/GMP or generated FFM bindings, including jextract_gmp.gmp_h in Java-4. Current Java is the sole self-contained archived BigInteger entry. Preserve documented partial-line output restrictions; configured inputs are multiples10.

## knucleotide

Current: Go and Java N/A.

No new evidence warrants reopening prior rejections. Coverage report records all five Go variants failing ascending lexical tie order (#3/#4/#6 descending keys, #7/#8 count-only comparator with map-order ties). Six Java variants retain tie ordering, tied-key loss, absent-fragment NullPointerException, or uppercase-target count failures. Keep N/A and the nine-problem chart cohort.
