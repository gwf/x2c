import json
from pathlib import Path
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout';m=json.loads((root/'benchmarks.json').read_text());langs=[('C','main.c'),('Python','main.py'),('Rust','main.rs'),('C++','main.cpp'),('Go','main.go'),('Java','main.java')]
table='| Problem | '+' | '.join(k for k,f in langs)+' |\n| --- |'+' --- |'*6+'\n'
for b in m['benchmarks']:table+='| '+b['title']+' | '+' | '.join('`'+b['references'][f]['path']+'`' if f in b['references'] else 'N/A' for k,f in langs)+' |\n'
p=root/'THIRD_PARTY.md';s=p.read_text();a=s.index('| Problem |');z=s.index('\nThe upstream BSD notice',a);s=s[:a]+table+s[z:];s=s.replace('The Python\n  contribution uses its standard `re` engine.','The Python\n  contribution calls the installed PCRE2 through ctypes. Its unchanged source\n  uses `find_library("pcre2-8")`; the audit receipt records the resolved library.');s=s.replace('The adopted Python contribution uses Python integers.','The adopted Python contribution calls the installed GMP through ctypes.\n  Rust pidigits now uses its archived direct GMP FFI entry.');s+='''
The current C k-nucleotide, regex-redux, spectral-norm and fannkuch-redux
builds enable their archived OpenMP directives using the installed native
libomp. C Mandelbrot also uses OpenMP and disables floating-point contraction,
matching the source's no-FMA requirement without an x86-only target flag.
The manifest records the exact source-specific compiler and linker settings.
No reference source has been edited.

Python binary-trees is excluded. The previous entry shares a constant tuple
for leaves; its unchanged bytes and allocation evidence are retained with the
reference audit. The fresh-leaf alternative disables GC, which this comparison
excludes under the pinned default-GC-when-possible guidance. This GC decision
is an interpretation of that guidance, separate from the proven leaf reuse.
''';p.write_text(s)
p=root/'results/reference-coverage.md';s=p.read_text();a=s.index('## Input constraints');s='# Reference coverage\n\nThe current comparison adopts exact contributions from the pinned archive.\nThe reference audit screened 70 candidates across all ten problems and six\nreference languages. Selection requires specification compatibility, official\nfixture and local-output checks, and repeatable local quiet-window gains.\n\n'+table+'\n'+s[a:];s=s.replace('only the nine problems shared by all eight columns','only the eight problems shared by all eight columns');s=s.replace('No missing value is treated as zero, and no nine-problem summary is compared\nwith a ten-problem summary.','No missing value is treated as zero. Earlier nine-problem summaries use a\ndifferent cohort and must not be compared as if their membership were unchanged.');s+='''
## Python binary-trees

The previously adopted #2 returns a constant `(None, None)` tuple at each leaf.
Compiling its unchanged function and checking object identity confirms shared
leaves. Base/#4/#5 have the same source pattern. This fails the pinned work
requirement that leaves receive the same allocation as interior nodes.

The remaining #3 creates fresh list leaves but explicitly calls `gc.disable()`.
It is excluded under the pinned request to use default GC when possible.
This is an interpretation of the GC guidance, distinct from the reproduced
allocation violation. The original source, disassembly, identity evidence,
and rejected-source discussion are preserved with the reference audit.
No patched reference replaces either entry.

There are 75 admitted programs. The eight-column common cohort excludes both
k-nucleotide and binary-trees. Complete Latin rotations for coverage groups of
8, 7 and 4 programs require 56 samples per program, or 4,200 observations.
The harness derives the rotation multiple from manifest availability.
''';p.write_text(s)
