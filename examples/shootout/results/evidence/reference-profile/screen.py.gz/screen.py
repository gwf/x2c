import os,sys,json,shutil,subprocess,time,statistics,hashlib
from pathlib import Path
from types import SimpleNamespace
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c'); root=Path('/tmp/x2c-reference-profile')
sys.path.insert(0,str(repo/'examples/shootout/tools')); import shootout as s
os.environ.update(GO='/tmp/x2c-shootout-go-toolchain/go/bin/go', JAVA='/opt/homebrew/opt/openjdk/bin/java',JAVAC='/opt/homebrew/opt/openjdk/bin/javac')
t=s.resolve_toolchain(SimpleNamespace(action='check',cc='cc',python='python3',cflags=s.DEFAULT_CFLAGS))
m=s.load_manifest(); benchmarks={b['name']:b for b in m['benchmarks']}
def save(v): (root/'screen.json').write_text(json.dumps(v,indent=2,default=str)+'\n')
def run(argv,log,**kw):
 p=subprocess.run([str(x) for x in argv],capture_output=True,timeout=180,**kw); log.write_text(p.stdout.decode(errors='replace')+p.stderr.decode(errors='replace')); 
 if p.returncode: raise RuntimeError(f'command failed {p.returncode}: {log}')
 return p
if sys.argv[1] in ('build','repair'):
 records=[]
 for f in sorted(root.glob('*-candidates.json')): records+=json.loads(f.read_text())
 # Preserve official source bytes for every attempted candidate, whether accepted or rejected.
 for i,r in enumerate(records):
  r['id']=f'{i:02d}-{r["problem"]}-{r["language"]}'; d=root/'candidates'/r['id'];d.mkdir(parents=True,exist_ok=True)
  a=Path(r['archive_path']); a=a if a.is_absolute() else Path('/tmp/x2c-official-benchmarksgame-sources-20261030')/a
  r['archive_path']=str(a);r['sha256']=s.sha256(a);r['directory']=str(d);r['source']=str(d/a.name);shutil.copyfile(a,r['source']);r['binary']=str(d/'program')
 if sys.argv[1]=='repair': records=json.loads((root/'screen.json').read_text())
 save(records)
 rust=root/'rust';rust.mkdir(exist_ok=True)
 cargo=(repo/'examples/shootout/rust/Cargo.toml').read_text().split('[[bin]]')[0]
 for r in records:
  if r['language']=='rust': cargo+=f'\n[[bin]]\nname="{r["id"]}"\npath="{r["source"]}"\n'
 (rust/'Cargo.toml').write_text(cargo);shutil.copyfile(repo/'examples/shootout/rust/Cargo.lock',rust/'Cargo.lock')
 # Build each Rust binary independently, retaining failures without losing other candidates.
 for r in records:
  if r.get('correct'): continue
  d=Path(r['directory']);lang=r['language'];b=benchmarks[r['problem']];src=Path(r['source']);binary=Path(r['binary'])
  try:
   pf,pl=s.native_flags(b)
   if lang in ('c','cpp'):
    argv=[t['cc' if lang=='c' else 'cxx'],*t['cflags'],*t['cppflags'],*pf,*r.get('flags',[]),'-x','c' if lang=='c' else 'c++',str(src),'-lm',*pl,*t['ldflags'],*r.get('link_flags',[]),'-o',str(binary)]
    r['compile_command']=argv;run(argv,d/'build.log')
   elif lang=='go':
    argv=[t['go'],'build','-o',binary,src];r['compile_command']=list(map(str,argv));run(argv,d/'build.log',env={**os.environ,'GOENV':'off','GOTOOLCHAIN':'local','GO111MODULE':'off','CGO_ENABLED':'0'})
   elif lang=='java':
    dest=d/(b['java_main_class']+'.java');(shutil.copyfile(src,dest) if src!=dest else None);argv=[t['javac'],'-d',d,dest];r['compile_command']=list(map(str,argv));run(argv,d/'build.log');binary.write_text(f'#!/bin/sh\nexec {t["java"]} -cp {d} {b["java_main_class"]} "$@"\n');binary.chmod(0o755)
   elif lang=='python':
    binary.write_text(f'#!{t["python"]}\nimport multiprocessing, runpy\nmultiprocessing.set_start_method("fork")\nrunpy.run_path({str(src)!r}, run_name="__main__")\n');binary.chmod(0o755)
   elif lang=='rust':
    argv=[t['cargo'],'build','--locked','--release','--manifest-path',rust/'Cargo.toml','--target-dir',s.RUST_BUILD,'--bin',r['id']];r['compile_command']=list(map(str,argv));run(argv,d/'build.log',env=s.rust_environment(t));shutil.copyfile(s.RUST_BUILD/'release'/r['id'],binary)
   binary.chmod(0o755)
   r.pop('error',None);r['built']=True;r['checks']=[]
   for idx,case in enumerate(b['checks']):
    base=s.ROOT/'benchmarks'/b['name'];out=s.run_captured(binary,case['args'],90,base/case['stdin'] if case.get('stdin') else None);(d/f'fixture-{idx}.out').write_bytes(out);s.compare_output(b['name'],r['id'],case,(base/case['expected']).read_bytes(),out);r['checks'].append({'case':case,'sha256':hashlib.sha256(out).hexdigest()})
   args=m['profiles']['local'][b['name']];inp=s.profile_stdin(b,'local',t)
   want=s.run_captured(s.binary_path(b['name'],'c'),args,90,inp);out=s.run_captured(binary,args,90,inp);(d/'local.out').write_bytes(out);s.compare_output(b['name'],r['id'],{'args':args,'comparison':s.profile_comparison(b)},want,out)
   r['correct']=True;r['binary_sha256']=s.sha256(binary)
  except Exception as e:r['error']=str(e)
  save(records); print(r['id'], 'PASS' if r.get('correct') else r.get('error'),flush=True)
else:
 records=json.loads((root/'screen.json').read_text());rounds=int(sys.argv[2]) if len(sys.argv)>2 else 3
 for b in m['benchmarks']:
  selected=[r for r in records if r['problem']==b['name'] and r.get('correct')]
  if not selected:continue
  items=[{'id':'baseline-'+b['name']+'-'+lang,'binary':str(s.binary_path(b['name'],lang)),'baseline':True,'language':lang,'problem':b['name']} for lang in sorted({r['language'] for r in selected})]+selected
  args=m['profiles']['local'][b['name']];inp=s.profile_stdin(b,'local',t)
  for turn in range(rounds):
   for r in items[turn%len(items):]+items[:turn%len(items)]:
    value=s.measure_once(s.BUILD/'tools/measure',Path(r['binary']),args,120,inp)
    with (root/'screen-raw.jsonl').open('a') as f:f.write(json.dumps({'id':r['id'],'turn':turn,'at':time.time(),**value})+'\n')
  print('screened',b['name'],flush=True)
