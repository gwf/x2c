import json,collections,statistics,hashlib,shutil
from pathlib import Path
root=Path('/tmp/x2c-reference-profile');repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');manifest=repo/'examples/shootout/benchmarks.json';m=json.loads(manifest.read_text());bs={b['name']:b for b in m['benchmarks']};selected=json.loads((root/'confirm-selected.json').read_text());a=collections.defaultdict(dict)
for line in (root/'confirm-raw.jsonl').read_text().splitlines():
 v=json.loads(line);assert v['exit_code']==v['signal']==0;a[v['id']][v['turn']]=v['elapsed_ns']
groups=collections.defaultdict(list);decisions=[]
for v in selected:
 before=a['baseline-'+v['problem']+'-'+v['language']];after=a[v['id']];assert len(before)==len(after)==8
 medbefore=statistics.median(before.values());medafter=statistics.median(after.values());wins=sum(after[k]<before[k] for k in before);ratio=medafter/medbefore
 d={'id':v['id'],'problem':v['problem'],'language':v['language'],'source_sha256':v['sha256'],'before_median_ms':medbefore/1e6,'candidate_median_ms':medafter/1e6,'ratio':ratio,'paired_wins':wins,'samples':8,'eligible':ratio<.95 and wins>=6,'adopted':False}
 decisions.append(d)
 if d['eligible']:groups[(v['problem'],v['language'])].append((d,v))
ext={'c':'c','cpp':'cpp','python':'py','rust':'rs','go':'go','java':'java','idiomatic':'x'}
for (problem,lang),options in groups.items():
 d,v=min(options,key=lambda x:x[0]['candidate_median_ms']);d['adopted']=True;b=bs[problem];target=repo/'examples/shootout/benchmarks'/problem/('main.'+ext[lang]);src=Path(v['source']);assert hashlib.sha256(src.read_bytes()).hexdigest()==v['sha256'];shutil.copyfile(src,target)
 if lang=='idiomatic':continue
 archive=Path(v['archive_path']);assert src.read_bytes()==archive.read_bytes();b['references'][target.name]={'path':str(archive.relative_to('/tmp/x2c-official-benchmarksgame-sources-20261030')),'sha256':v['sha256']}
 if lang in ('c','cpp'):
  flags=[x for x in v.get('flags',[]) if not x.startswith('-I'+str(repo))];b[lang+'_flags']=flags;b[lang+'_link_flags']=v.get('link_flags',[])
 if lang=='python': b['python_start_method']='fork'
manifest.write_text(json.dumps(m,indent=2)+'\n');(root/'decisions.json').write_text(json.dumps({'criterion':'candidate median at least five percent lower; at least six of eight paired rounds faster; best eligible variant per language/problem; correctness/spec compatibility required','decisions':decisions},indent=2)+'\n')
for d in decisions:
 print('ADOPT' if d['adopted'] else 'keep prior',d['id'],f"{d['before_median_ms']:.3f} -> {d['candidate_median_ms']:.3f} ms",d['paired_wins'])
