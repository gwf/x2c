import sys,json
from pathlib import Path
sys.path.insert(0,'/Users/gary/.codex/worktrees/f2bc/x2c/examples/shootout/tools');import shootout as s
b=next(b for b in s.load_manifest()['benchmarks'] if b['name']=='knucleotide');binary=Path('/tmp/x2c-reference-profile/knucleotide-parallel')
for c in b['checks']:
 base=s.ROOT/'benchmarks/knucleotide';out=s.run_captured(binary,c['args'],90,base/c['stdin']);s.compare_output('knucleotide','parallel-probe',c,(base/c['expected']).read_bytes(),out)
print('probe fixtures pass')
