# C and C++ official reference audit

Read-only source audit against worktree baseline c77b6020c. No candidate builds,
execution, correctness checks, or measurements were performed by this auditor.
The accompanying JSON contains 25 candidate configurations. Entries are ordered
first/second within each problem/language; existing adopted C OpenMP configurations
are included explicitly. Flags supplement the normal harness toolchain and package
flags, rather than replacing them. In particular, retain native_flags for PCRE2,
GMP discovery paths, -lm, and each benchmark's existing pinned headers.

## Provenance

Archive root: /tmp/x2c-official-benchmarksgame-sources-20261030
Upstream tree: /tmp/x2c-official-benchmarksgame-20261030
Pinned upstream revision: 40296663ed350d5fe4a6ab5e367bab61cb77c219
Archive: public/download/benchmarksgame-sourcecode.zip
Archive SHA256: aabcf6726cdc14f0f45b99e5daba48584f94bbb48883fd3711a1d040474d1cb4
Use the archive source bytes unchanged. Compile failures reject a candidate under
the configured toolchain; do not patch adopted reference source to make it work.

## Priority findings

1. Current C k-nucleotide, reverse-complement, and regex-redux already contain
   OpenMP, but benchmarks.json supplies none of its compile/link flags. Unless
   supplied externally, current runs therefore ignore those pragmas. Test existing
   sources with OpenMP before attributing all differences to source selection.
2. Probe portable parallel fannkuch, spectral-norm, and mandelbrot candidates.
   mandelbrot.gcc-5.gcc has GNU vector_size(32) arithmetic, not x86 intrinsics.
3. Probe binarytrees.gpp-5.gpp: standard PMR pools plus std::thread. The source
   omits an explicit vector header; libc++ transitive-header acceptance is unknown.
4. FASTA has important archived/current-spec conflicts. Do not adopt the fastest
   archived C entries without applying the pinned specification below.

## Native compiler settings

Apple Clang OpenMP compile candidates:
-Xpreprocessor -fopenmp -I/opt/homebrew/opt/libomp/include
Link candidates:
-L/opt/homebrew/opt/libomp/lib -lomp -Wl,-rpath,/opt/homebrew/opt/libomp/lib
The installed header and library paths are present; actual builds remain untested.
Use -std=c++17 and -pthread for standard-thread candidates. Preserve common
optimization/float settings across the comparison. Source-comment x86 options
such as -mno-fma and x86 -march settings are not portable instructions for this Mac.

## Candidates and retained choices

| Problem | C | C++ |
|---|---|---|
| binarytrees | Retain gcc-5 pthreads. gcc-2/gcc-3 need APR and OpenMP. | Probe gpp-5 PMR plus threads. |
| fannkuchredux | Probe gcc-5 OpenMP, then gcc-2 pthreads. | Probe gpp-5 OpenMP, then unnumbered gpp std::async. |
| fasta | Probe gcc-2 ordinary linear lookup; retain current if no gain. | Probe gpp-7, then gpp-5; standard threads and unscaled cumulative search. |
| knucleotide | Existing gcc with OpenMP enabled. | Keep N/A under native libc++: all three sources use GNU pb_ds. |
| mandelbrot | Probe gcc-5 GNU vectors/OpenMP, then scalar gcc-9 OpenMP. | Probe gpp-0 portable std::array/threads, then gpp-9 OpenMP. |
| nbody | Optional scalar gcc-6, then gcc-2; expected benefit modest. | Optional gpp-9 compile-time unrolling, then gpp-5. |
| pidigits | Optional gcc-2 with GMP; historical difference tiny. | Retain gpp-4; gpp-5 optional comparator, not known stronger. |
| regexredux | Existing gcc-5 PCRE2 with OpenMP enabled. | Retain gpp-6 PCRE2/std::async. |
| revcomp | Probe pthread gcc-9; also enable current gcc-6 OpenMP. | Probe standard-thread gpp-6, then scalar gpp-3. |
| spectralnorm | Probe portable scalar gcc-3 OpenMP. | Retain current: other sources require x86 or Linux affinity APIs. |

## Conformance constraints

Pinned descriptions under public/description own these constraints:

- fasta.html lines33,44-45 forbids optimized cumulative-probability lookup/scaling,
  requires linear or binary search, and requires ordinary LCG generation without
  caching its sequence. gcc-3 builds a full random-output symbol lookup; gcc-5 and
  gcc-6 explicitly scale probabilities by IM; gcc-7 converts them to scaled integer
  thresholds. Exclude those C choices. gcc-4 changes LCG arithmetic and is not a
  clear compatible choice. gcc-2 uses ordinary unscaled cumulative search.
  C++ gpp-7/gpp-5 normalize random values before find_if; no obvious scaling-of-
  cumulative-probabilities conflict was found. Their block buffers and full byte
  equality still need root validation. Buffering bounded freshly generated work is
  distinct from precomputing/reusing a PRNG cycle, but record the actual approach.
- binarytrees.html lines42-50 explicitly permits library memory pools, forbids
  custom arenas/pools/free lists, and requires full allocations for leaves.
  Standard PMR is a library facility. Both child pointers are allocated/stored for
  every leaf in gpp-5. Do not reject library pools merely because they are pools.
- pidigits.html requires the sequential step-by-step algorithm and both extraction
  calculations. No parallel pidigits candidate is proposed.
- Fannkuch must preserve all n! permutations and checksum parity. C gcc-2 hardcodes
  MAX_PROBLEM_SIZE12 and MAX_CPU_LIMIT4. Its inline helper linkage might need the
  correct compiler semantics; do not patch raw bytes.
- Reverse-complement must preserve IUPAC complements, headers, wrapping and byte
  order. Mandelbrot requires exact PBM bytes; current configured sizes are multiples
  of eight, but candidates may have broader dimension constraints.

## Platform and dependency exclusions

- nbody.gcc-5 and nbody.gpp-4 contain __builtin_ia32_haddpd/sqrtpd and are x86-bound,
  despite their apparently portable math/stdio includes and GNU vector types.
- nbody AVX variants, fannkuch SIMD variants, spectralnorm x86 variants and
  reverse-complement AVX variants cannot be adopted unchanged on native ARM64.
- spectralnorm.gpp-7 uses GNU vectors but also sched_getaffinity/CPU macros, which
  block unchanged macOS builds. Likewise inspect Linux CPU-affinity calls in other
  alternatives before assuming sched.h means portable POSIX.
- binarytrees C APR variants need apr_pools.h and libapr; checked Homebrew APR paths
  are absent. C++ Boost pool variants need more than the currently pinned regex
  noncopyable header. Checked Homebrew Boost installation paths are absent.
- binarytrees.gpp-7 uses std::execution::par, Boost counting_iterator, and PMR;
  parallel backend availability/effect under libc++ is uncertain. gpp-5 is simpler.
- All C++ k-nucleotide variants use GNU ext/pb_ds; changing the map or installing a
  new global compiler is not a source-preserving native-toolchain adoption.
- Regex PCRE1/RE2/Boost.Regex alternatives add dependencies and have no established
  advantage over current PCRE2 choices. Preserve current PCRE2 package integration.

## Historical screening evidence, not Mac predictions

Values below come from pinned upstream public/data/data.csv. They describe another
host, canonical workloads and its compiler settings. They are not local gains and
must not appear as new Mac measurements.

| Problem/language | Candidate elapsed seconds | Current elapsed seconds | N |
|---|---:|---:|---:|
| binarytrees C++ | gpp5 1.169 | gpp2 22.771 |21|
| fannkuch C | gcc5 7.276 | gcc1 39.650 |12|
| fannkuch C++ | gpp5 7.858 | gpp3 37.894 |12|
| mandelbrot C | gcc5 1.637 | gcc8 25.171 |16000|
| mandelbrot C++ | gpp0 2.360 | gpp3 27.381 |16000|
| spectralnorm C | gcc3 1.432 | gcc8 5.406 |5500|
| revcomp C | gcc9 0.490 | gcc6 0.966 |100000001|
| fasta C | gcc2 2.768 | gcc1 3.711 |25000000|
| fasta C++ | gpp7 0.883 | gpp1 1.929 |25000000|
| nbody C | gcc6 4.981 | gcc1 5.230 |50000000|
| nbody C++ | gpp9 5.148 | gpp3 5.328 |50000000|
| pidigits C | gcc2 0.737 | gcc1 0.747 |10000|
| pidigits C++ | gpp5 0.732 | gpp4 0.718 |10000|

No upstream data row was found for reverse-complement gpp-6 or gpp-3. Their ranking
is a source hypothesis only. Thread startup can reverse rankings at the smaller
local workload. Root must build/check all candidates, measure comparable workloads,
and adopt only demonstrated compatible improvements.
