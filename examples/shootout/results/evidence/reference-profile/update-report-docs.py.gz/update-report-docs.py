import json,datetime as dt,statistics
from pathlib import Path
from zoneinfo import ZoneInfo
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout/results';scratch=Path(__file__).resolve().parent;r=json.loads((root/'current.json').read_text());run=r['run_id'];p=root/'runs'/run;web=json.loads((p/'website.json').read_text());decisions=json.loads((scratch/'decisions.json').read_text());date=dt.datetime.strptime(run,'%Y%m%dT%H%M%SZ').replace(tzinfo=dt.timezone.utc);when=date.strftime('%Y-%m-%d %H:%M UTC');local=date.astimezone(ZoneInfo('America/Los_Angeles')).strftime('%Y-%m-%d %H:%M %Z');measured=r['machine']['repository']['revision'];publication=web['publication_revision'];old='20261031T170749Z';e=root/'evidence/reference-profile'
readme=f'''# Reference audit and ordinary parallel k-nucleotide

Run `{run}`, observed {local} / {when}, measures clean source
`{measured}`. The report checkpoint is `{publication}`. Subsequent
archive/documentation commits preserve these bytes without changing measured code.

This is the configured **local** profile on Apple M4 Max, not canonical-size
timing or published Benchmarks Game results. All 75 admitted programs pass
both official fixtures and local output checks. Fifty-six fresh-process samples
per program give 4,200 observations. Complete rotating Latin orders balance
all coverage groups (8,7,4 programs). Eight columns share eight problems;
k-nucleotide and binary-trees remain in complete per-problem tables.

The Python binary-trees entry was removed because its constant leaf tuple
misses required allocations. The fresh-leaf archived alternative disables GC
and is excluded under the pinned default-GC-when-possible guidance. The former
is reproduced; the latter is a documented interpretation, not an allocation
finding. All earlier nine-problem reports and figures remain unchanged.

## Quiet evidence and process model

Timing follows six consecutive ten-second observations with at least 90 percent
aggregate CPU idle, after builds and fixtures. The exact observations are in
`current.json` and `raw/reference-profile-quiet-window.jsonl.gz`. This establishes
the pre-run window; it does not establish zero background activity throughout.
Every timed sample starts a fresh process. Java includes fresh-JVM startup
and JIT compilation. A separate warmup process does not warm measured JVMs.

## Source findings and selected changes

The source audit considered all ten problems across six reference languages
and centrally built 70 candidate configurations. Sources were never patched.
28 stronger compatible reference choices or source-specific build settings
were adopted after correctness checks and quiet confirmation. Existing C
k-nucleotide and regex-redux OpenMP pragmas are now enabled. Other wins include
parallel C/C++ fannkuch, standard-library pooled/threaded C++ binary-trees,
Go parallel entries, Rust scalar/Rayon/direct-GMP entries, and official Python
multiprocessing/GMP/PCRE2 entries. Exact paths and hashes are in `benchmarks.json`.

The focused experiment rotates before programs and candidates for eight local
rounds after a separate quiet window. Adoption requires a median at least 5 percent
lower and at least 6/8 paired wins; the fastest eligible variant per cell wins.
Small or inconsistent differences retain the previous source. These focused
samples are separate from this full calibration.

For idiomatic k-nucleotide, sampled stacks identify String slice/intern-pool
lookup and Map operations as the main hot paths. Seven ordinary Threads now
build the seven required full growing Maps. Worker-local collections do not
escape; canonical String outputs survive callback exit and print after ordered
joins. The quiet probe measured 163.604 ms serial versus 83.901 ms parallel,
with 8/8 paired wins. Sixteen DNA oracle/edge inputs and the larger N=1,000,000
profiling input match the retained oracle. No compiler/runtime source changed.
No typed container, Substr, private pool, raw storage or custom allocator was added.

## Recovery and website integration

- `current.json`, `current.md`, `baseline.json.gz`, `benchmarks.json`: exact run.
- `raw/`: original 4,200 observations, build/check/machine/summary receipts,
  calibration log, quiet observations and orchestration script.
- `charts/`: three standard forms plus focused `reference-audit-probes`, each
  PNG/SVG/PDF; CSVs, renderers and provenance; `website.json` is the curated export.
- `../../evidence/reference-profile/`: all candidate source bytes, failed builds,
  fixture/local outputs, initial and quiet samples, decisions, sample stacks,
  profiling input and receipt, serial/threaded sources, sanity reports and scripts.
- `../../SHA256SUMS`: archive verification. Earlier immutable runs stay unchanged.

Recover each `.gz` with `gzip -dc`. Evidence paths mirror the scratch directory.
To rerender focused probes from a clone, decompress `screen.json.gz`,
`confirm-selected.json.gz`, `confirm-raw.jsonl.gz`, and `decisions.json.gz` into one temporary directory,
then pass that directory to `charts/render-probes.py --output OUT`.
The renderer reads these saved files; it never executes candidate paths.
See [recovery](../../README.md) and [website notes](../../../../../site/BENCHMARKS.md).
Native binaries are reproducible from pinned source and recorded commands;
recorded hashes identify the measured executables, which are not stored in Git.

The optional unchanged-C sanity check passes all 10 native-driver programs.
The parser accepts 7; GNU vector indexing (Mandelbrot), a khash declaration
(k-nucleotide), and an empty parameter list (reverse-complement) remain
unsupported in those unchanged sources. Logs are retained; no C-through-x2c
column is added. The sanity tool now passes compiler-only flags with `-Xcc`.

Canonical-size timing remains unrun.
'''
(p/'README.md').write_text(readme)
(p/'charts/README.md').write_text(f'''# Figures for {run}

All eight series use the same eight shared problems. Per-problem CSV includes
all 75 admitted outcomes; no missing cell is treated as zero. Summary scatter
uses geometric means of per-problem minima; star centres use arithmetic means;
box plots show variation across problems, not timing confidence intervals.
LOC and compressed source bytes are separate metrics. Fresh-JVM startup/JIT
is included. All three forms preserve the established comparison style.

`reference-audit-probes` shows the separate eight-round quiet local experiment,
including candidates retained or rejected after confirmation. Its CSV gives
absolute before/candidate medians, CPU time, ratios and sample counts. Source
and command evidence lives under `../../../evidence/reference-profile/`.
The full calibration has 56 samples/program, not8. Canonical timing is unrun.

Render using the isolated dependencies in `../../../requirements-charts.txt`:

```sh
python render.py ../current.json /tmp/shootout-figures
python render-probes.py /tmp/recovered-reference-probes --output /tmp/shootout-figures
```

See [run provenance](../README.md) and `provenance.json`.
''')
f=root/'README.md';s=f.read_text();a=s.index('The current public candidate');z=s.index('## Saved runs',a);s=s[:a]+f'''The current public candidate is [run {run}](runs/{run}/README.md),
measured from clean source `{measured}` and retained in report checkpoint
`{publication}`. Observation: {local} / {when}. Run identifiers use UTC.

It covers 75 admitted programs, eight columns and 56 fresh-process samples each
(4,200 observations). Official fixtures and local output checks pass. Summary
charts use eight shared problems. Per-problem tables retain all available
k-nucleotide/binary-trees cells. Earlier nine-problem cohorts remain historical.

'''+s[z:];s=s.replace('Latest: parallel fannkuch adopted; loop-bound adopted','Parallel fannkuch adopted; loop-bound adopted');s=s.replace('\n[runs/index.json]',f'| [{run}](runs/{run}/README.md) | 8 | 8 | Latest: reference audit and parallel k-nucleotide |\n\n[runs/index.json]');s=s.replace('gzip -dc runs/'+old,'gzip -dc runs/'+run).replace('git worktree add --detach /tmp/x2c-shootout-source 4b881e60fd9c4492cea9947a57d072d18e04b5ef','git worktree add --detach /tmp/x2c-shootout-source '+publication);s=s.replace('results/runs/'+old+'/charts/render.py examples/shootout/results/runs/'+old+'/current.json','results/runs/'+run+'/charts/render.py examples/shootout/results/runs/'+run+'/current.json');s=s.replace('To render the latest loop-bound/fannkuch','To render the earlier loop-bound/fannkuch');s+='''
## Reference audit evidence

`evidence/reference-profile/` mirrors all 70 attempted candidate configurations,
with exact source bytes, commands, diagnostics, outputs, quiet confirmation,
selection decisions, statistical k-nucleotide stacks/input and unchanged-C
sanity observations. It includes rejected attempts. Decompress the four probe
JSON/JSONL files into a temporary directory to rerender the focused chart.
No executable path stored in a receipt needs to exist for rendering.
''';f.write_text(s)
f=repo/'site/BENCHMARKS.md';s=f.read_text().replace(old,run).replace('nine shared','eight shared').replace('same nine problems','same eight problems').replace('sixteen samples','56 samples').replace('2026-10-31 10:07 PDT / 2026-10-31 17:07 UTC',local+' / '+when);s=s.replace('Rust/C++/Go/Java k-nucleotide cells are N/A, with','Rust/C++/Go/Java k-nucleotide and Python binary-trees cells are N/A, with');a=s.index('The latest run adds');s=s[:a]+f'''The latest run preserves `reference-audit-probes` in PNG/SVG/PDF/CSV with
renderer and provenance. It shows the separate eight-round quiet confirmation;
the full run uses56 samples/program and 4,200 observations. State the changed
eight-problem cohort, official-reference substitutions/build settings and
ordinary seven-Thread k-nucleotide. Do not attribute faster C reference times
to an x2c regression. Keep Python GMP/PCRE2 dependencies visible in source notes.
The former Python binary-trees allocation failure and GC-guidance interpretation
must accompany that N/A cell. Earlier experiments remain labeled by their runs.
''';f.write_text(s)
f=root/'evidence/README.md';s=f.read_text()+f'''\n## Reference audit and k-nucleotide\n\n`reference-profile/` preserves70 source/configuration attempts, all audits,\nfailed builds/output checks, quiet before/candidate samples and decisions,\nstatistical profiling and input,16 DNA oracle checks, original Python tree\nallocation evidence, and both initial/corrected compiler-flag sanity reports.\nThe full calibration is [run {run}](../runs/{run}/README.md).\n''';f.write_text(s)
f=root/'threading.md';s=f.read_text().replace('uses native threads. The project also publishes','uses Rayon workers. The project also publishes').replace('divides permutations among native threads.','divides permutations among Rayon workers.');a=s.index('Source identities');s=s[:a]+'''- K-nucleotide: the [adopted C contribution](../benchmarks/knucleotide/main.c)
  uses OpenMP sections, now enabled in its build. The idiomatic x2c entry uses
  seven ordinary Threads, one full growing Map per required width. Results
  print in the specified order after joins. Worker-local collections do not
  escape; canonical String outputs retain their shared-pool lifetime.

'''+s[a:];s+='''
## Reference audit update

The selected references include source-specific OpenMP, Rayon, ordinary threads,
Python multiprocessing, standard-library pools, GMP and PCRE2. Exact choices
and flags are in the manifest and each immutable run. All remain subject to
required algorithm/work checks. No matching-core regime or extra column was
introduced. Python tree exclusion changes the common cohort to eight problems.
''';f.write_text(s)
# Rank concrete absolute local outcomes and ratios using this run only.
rows=[]
for name,v in r['benchmarks'].items():
 x=v['idiomatic']['statistics']['median_elapsed_ns']/1e6;c=v['references']['c']['statistics']['median_elapsed_ns']/1e6;t=v['tuned']['statistics']['median_elapsed_ns']/1e6;best_name,best_ms=min([(k,v['statistics']['median_elapsed_ns']/1e6) for k,v in v['references'].items()]+[('tuned',t)],key=lambda item:item[1]);rows.append((x/best_ms,name,x,c,t,best_name,best_ms))
s=f'''# Remaining local performance gaps\n\nRun `{run}`, clean measured source `{measured}`, local profile,56samples\nper program. These are measured programs, not general language overhead.\nCanonical-size timing remains unrun. All eight shared problems use the same\ncohort; k-nucleotide and binary-trees stay in per-problem rows.\n\n| Problem | Idiomatic ms | C ms | Tuned ms | Fastest selected ms | Idiomatic / fastest |\n| --- | ---: | ---: | ---: | --- | ---: |\n'''
for ratio,name,x,c,t,best_name,best_ms in sorted(rows,reverse=True):s+=f'| {name} | {x:.3f} | {c:.3f} | {t:.3f} | {best_name}: {best_ms:.3f} | {ratio:.2f} |\n'
s+='''
The reference audit changes many baselines. A larger x2c/C ratio can result
from a faster adopted C program even when x2c is unchanged. Compare absolute
milliseconds and source identities before attributing changes. Earlier aggregate
summaries have nine shared problems; the current summaries have eight.

K-nucleotide profiling finds String slicing/intern-pool lookup and Map work.
Seven ordinary Threads cut the controlled local median from 163.604 ms to 83.901 ms
(all 8 paired rounds faster). Every width still builds a full growing Map.
Counter objects, compound Map assignment and earlier attempted shortcuts remain
rejected in preserved evidence. Typed Substr maps remain a tuned-only option.
Further shared-pool runtime changes need a separate design decision, because
allocation, lifetime and synchronization affect more than this benchmark.

Ordinary Thread batches for regex-redux pattern counts and independent
reverse-complement records may merit later probes. Official C submissions
provide parallel precedent. Library pools explain part of the fast tree
reference results, but adopting a specialized allocator is outside the
idiomatic definition. These findings do not authorize a runtime redesign. That is a candidate, not a
measured win from this task. Reference audit, k-nucleotide profiling/threading,
validation, quiet full rerun and charts are this batch's completed scope.
Source-specific raw C, typed storage or custom allocation is not an idiomatic fix.

See [run evidence](runs/'''+run+'''/README.md),
[reference coverage](reference-coverage.md) and [threading](threading.md).
''';(root/'remaining-gaps.md').write_text(s)
print('updated recovery/website/gaps',run)

f=root/'reference-coverage.md';s=f.read_text();manifest=json.loads((repo/'examples/shootout/benchmarks.json').read_text())
for language,filename in [('Go','main.go'),('Java','main.java')]:
 start=s.index('| Problem | '+language+' archive source |')
 end=s.index('\n\n',start)
 table='| Problem | '+language+' archive source |\n| --- | --- |\n'
 for b in manifest['benchmarks']:
  if filename in b['references']:table+='| '+b['name']+' | `'+b['references'][filename]['path']+'` |\n'
 s=s[:start]+table.rstrip()+s[end:]
f.write_text(s)
