"""Preserve one successful reference-audit calibration without rerunning it."""
import json,gzip,hashlib,shutil,subprocess,csv,sys
from pathlib import Path
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout/results';scratch=Path(__file__).resolve().parent;build=repo/'examples/build/shootout';r=json.loads((root/'current.json').read_text());run=r['run_id'];p=root/'runs'/run;e=root/'evidence/reference-profile'
assert r['samples']==56 and len(r['summary_benchmarks'])==8 and len(r['implementations'])==8 and not r['machine']['repository']['dirty']
assert len((build/'calibration-raw.jsonl').read_text().splitlines())==4200
assert len(json.loads((build/'latest/check.json').read_text())['checks'])==75
assert json.loads((build/'latest/receipt.json').read_text())['run_id']==run
publication=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert subprocess.check_output(['git','show',publication+':examples/shootout/results/current.json'],cwd=repo)==(root/'current.json').read_bytes()
p.mkdir(exist_ok=False);e.mkdir(exist_ok=False)
archive=Path('/tmp/x2c-official-benchmarksgame-20261030/public/download/benchmarksgame-sourcecode.zip')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='aabcf6726cdc14f0f45b99e5daba48584f94bbb48883fd3711a1d040474d1cb4'
shutil.copyfile(archive,e/'benchmarksgame-sourcecode.zip')
def dump(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
def zipped(path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(gzip.compress(data,mtime=0))
for f in ['current.json','current.md']:shutil.copyfile(root/f,p/f)
zipped(p/'baseline.json.gz',(repo/'examples/shootout/baseline.json').read_bytes());shutil.copyfile(repo/'examples/shootout/benchmarks.json',p/'benchmarks.json')
for f in [build/'calibration-raw.jsonl',*(build/'latest'/n for n in ['build.json','check.json','receipt.json','summary.json','summary.md']),repo/'debug/reference-profile-calibration.log',repo/'debug/reference-profile-quiet-window.jsonl',repo/'debug/reference-profile-measurement-processes.jsonl',scratch/'quiet-run.py']:
 zipped(p/'raw'/(f.name+'.gz'),f.read_bytes())
# Preserve scratch sources, diagnostics, outputs, receipts, sample stacks and scripts;
# executables and generated objects remain recoverable from commands/source hashes.
for f in sorted(scratch.rglob('*')):
 if not f.is_file() or 'target' in f.parts or f.name=='program' or f.name=='knucleotide-parallel' or f.suffix in ('.class','.o','.pyc') or 'knuc-generated' in f.parts or any(x in f.parts for x in ['native-build','generated']):continue
 if f.name in ('native-program','translated-program'):continue
 # Native sanity builds have many dependency/cache files; retain reports, commands,
 # exact copied sources and all stdout/stderr/comparison evidence.
 if 'c-through-x2c' in str(f) and f.suffix not in ('.json','.md','.x','.stdout','.stderr','.txt'):continue
 zipped(e/(str(f.relative_to(scratch))+'.gz'),f.read_bytes())
for f in sorted((repo/'debug').glob('reference-*.log')):zipped(e/'logs'/(f.name+'.gz'),f.read_bytes())
for attempt in sorted((repo/'debug').glob('reference-profile-interfered-*')):
 for f in sorted(attempt.rglob('*')):
  if f.is_file():zipped(e/'interfered-attempts'/attempt.name/(str(f.relative_to(attempt))+'.gz'),f.read_bytes())
# Strong source provenance, including unchanged archive bytes for all55 refs.
src=Path('/tmp/x2c-official-benchmarksgame-sources-20261030');manifest=json.loads((p/'benchmarks.json').read_text());refs=[]
for b in manifest['benchmarks']:
 for filename,entry in b['references'].items():
  local=repo/'examples/shootout/benchmarks'/b['name']/filename;assert local.read_bytes()==(src/entry['path']).read_bytes();assert hashlib.sha256(local.read_bytes()).hexdigest()==entry['sha256'];refs.append({'problem':b['name'],'filename':filename,**entry})
dump(e/'adopted-reference-provenance.json',{'archive':manifest['specification'],'reference_count':len(refs),'sources':refs})
charts=p/'charts';charts.mkdir();renderer=(root/'runs/20261031T170749Z/charts/render.py').read_text();renderer=renderer.replace('nine shared','eight shared').replace('threads in three workloads','threads in four workloads').replace('idiomatic fannkuch parallel at N>=9','idiomatic fannkuch parallel at N>=9; idiomatic k-nucleotide counts widths in seven Threads')
(charts/'render.py').write_text(renderer)
probe=(scratch/'render-probes.py').read_text().replace('full76-program,16-sample calibration','full-suite calibration').replace('full76-program16-sample calibration','full-suite calibration');(charts/'render-probes.py').write_text(probe)
python='/Users/gary/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
subprocess.run([python,str(charts/'render.py'),str(p/'current.json'),str(charts)],check=True)
subprocess.run([python,str(charts/'render-probes.py'),str(scratch),'--output',str(charts)],check=True)
web={'schema':1,'run_id':run,'measured_revision':r['machine']['repository']['revision'],'measured_tree_dirty':False,'publication_revision':publication,'report_revision':publication,'profile':r['profile'],'samples':56,'process_warmups':r['warmups'],'implementations':r['implementations'],'summary_benchmarks':r['summary_benchmarks'],'java_process_model':'fresh JVM per sample; startup and JIT included; no in-process warmup','historical_source_metric_issue':False,'execution_modes':'Mixed serial/parallel official entries; idiomatic x2c parallel for binary-trees, spectral-norm, fannkuch-redux and k-nucleotide','measurements':list(csv.DictReader((charts/'measurements.csv').open()))};dump(p/'website.json',web)
idx=json.loads((root/'runs/index.json').read_text());idx['current_run']=run;idx['runs'].append({'run_id':run,'path':run,'publication_revision':publication,'report_revision':publication,'measured_revision':web['measured_revision'],'implementations':r['implementations'],'summary_problem_count':8,'sample_recovery':'original full calibration JSONL and receipts compressed without changing bytes','historical_source_metric_issue':False});dump(root/'runs/index.json',idx)
(scratch/'archived-run.txt').write_text(run+'\n')
print('archived',run,'references',len(refs))
