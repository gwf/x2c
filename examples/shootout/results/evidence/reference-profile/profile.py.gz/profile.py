from pathlib import Path
import hashlib,json,subprocess,time
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=Path(__file__).resolve().parent
p=root/'input1000000.fasta'
with p.open('wb') as f:subprocess.run([repo/'examples/build/shootout/fasta/c/program','1000000'],stdout=f,check=True)
meta={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'input_n':1000000,'input_bytes':p.stat().st_size,'input_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'profiles':[],'limit':'Statistical sampled stacks identify hot paths, not controlled elapsed-time improvements.'}
for mode in ('idiomatic','tuned'):
 binary=repo/'examples/build/shootout/knucleotide'/mode/'program';path=root/(mode+'-sample.txt')
 with p.open('rb') as data, (root/(mode+'.out')).open('wb') as out:
  proc=subprocess.Popen([binary],stdin=data,stdout=out)
  sample=subprocess.run(['/usr/bin/sample',str(proc.pid),'2','1','-file',str(path),'-mayDie'],capture_output=True,text=True)
  exitcode=proc.wait();assert exitcode==0
 meta['profiles'].append({'mode':mode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sample_exit_code':sample.returncode,'sampler_stdout':sample.stdout,'sampler_stderr':sample.stderr,'output_sha256':hashlib.sha256((root/(mode+'.out')).read_bytes()).hexdigest()})
assert meta['profiles'][0]['output_sha256']==meta['profiles'][1]['output_sha256']
(root/'profile-receipt.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta,indent=2))
