# Unchanged C through x2c

- Run: `20261031T174611.533798Z`
- x2c: `/Users/gary/.codex/worktrees/f2bc/x2c/builds/0/x2c`
- Compiler SHA-256: `c69e9ae7af1e31d243847678a8056599632a9c3be507de4f77167b863f47ece6`
- Profile comparison: `local`

The native-driver path builds the original `.c` with `x2c build`.
The parser path translates a byte-identical `.x` copy with `--cpp`,
then compiles the emitted C. Both paths check the official fixtures.
Successful parser builds also compare profile output with the
fixture-verified native-driver program. No source is rewritten.

| Problem | Native driver | x2c parser | Parser result |
| --- | --- | --- | --- |
| nbody | pass | pass | official fixtures and profile output match |
| spectralnorm | fail | pass | official fixtures and profile output match |
| fannkuchredux | fail | pass | official fixtures and profile output match |
| mandelbrot | fail | fail | /private/tmp/x2c-reference-profile/c-through-x2c/20261031T174611.533798Z/mandelbrot/reference.x:21:16: parse: type ( Vec ) does not support getindex |
| fasta | pass | pass | official fixtures and profile output match |
| knucleotide | fail | fail | /private/tmp/x2c-reference-profile/c-through-x2c/20261031T174611.533798Z/knucleotide/reference.x:23:49: parse: expected identifier in destructuring declaration |
| revcomp | pass | fail | /private/tmp/x2c-reference-profile/c-through-x2c/20261031T174611.533798Z/revcomp/reference.x:68:10: parse: empty parameter list; use (void) |
| binarytrees | pass | pass | official fixtures and profile output match |
| regexredux | fail | pass | official fixtures and profile output match |
| pidigits | pass | pass | official fixtures and profile output match |

Commands, source hashes, stdout, stderr, and comparison details
are retained beside `report.json`. This optional check is separate
from timing results and publication gates.
