# Rust and Python official reference audit

Read-only source audit against repository c77b6020c and pinned archive
/tmp/x2c-official-benchmarksgame-sources-20261030. No source edits, candidate execution,
builds, measurements, tests, or network operations were performed.

The adjacent rust-python-candidates.json records at most two probe candidates per
language/problem. Order is intended to prioritize useful probes, not predict measured
ARM performance. Root owns centralized builds, output checks, and measurements.
Adoption must preserve the exact archived bytes. Process startup remains timed.

## Baselines and candidates

| Problem | Rust | Python |
| --- | --- | --- |
| nbody | Current base portable. Probe #6, then #4: std-only scalar lane/operator structures. #6 header mentions SIMD developers but source uses scalar tuple structs. | Current base already caches pairs. Probe #2, with flattened precomputed pair tuples and math.sqrt. #8's Body attributes offer no obvious advantage. |
| spectralnorm | Current #3 manual threading. Probe #4, then #5: existing Rayon, portable paired output rows and scalar lanes. #4 requires even N, satisfied by configured sizes. | Current #6 serial. Probe #4, then #7: four-process Pool, full matrix and transpose products. #4 uses integer denominator and generator sums. Startup and vector serialization may dominate smaller N. |
| fannkuchredux | Current #2 uses four manual threads. Probe #4 and #5: existing Rayon block scheduling. | Current #8 serial. Probe #4: bytearray permutations, factorial unranking, multiprocessing and a task-size cutoff. Probe #6 as second serial alternative. Check even task-size assertions and host CPU count partitioning. |
| mandelbrot | Current #4 already portable Rayon and aligned storage. Probe #6: scalar pairs and eight-pixel blocks, existing Rayon. | Current #8 serial. Probe #5 for configured widths divisible by eight; fork needed because size assigned under main guard. No sound second high-value candidate found. |
| fasta | Current #4 obeys naive normalized LCG and cumulative linear search. Probe #6, narrow stdout-lock variant with same required algorithm. | Current base uses normalized LCG and bisect. Probe #3, then #2: bytearray/stdout.buffer; #2 adds repeated-ALU output buffering. Validate trailing-newline edges. |
| knucleotide | Keep N/A. Prior fixture evidence excludes all eight variants for tie ordering; no new evidence overturns it. | Current #3 full hash-table count work. Probe #4 and #9: full table for each requested length and descending (count, sequence) tie order. Fork required for inherited global sequence. |
| revcomp | Current #2 Rayon. Probe #3: recursive read/process overlap through rayon::join, no new dependency. Check empty/header-only records and EOF before adoption. | Current base text translate/reverse. Probe #4 (bytes translate/delete newline/reverse) and #3 (reusable byte buffers). #4 contains original CRLF bytes; preserve them. |
| binarytrees | Current base typed-arena and threads. Probe #2: existing typed-arena/Rayon with same Tree allocation for leaves/interior nodes. | Current #2 and base/#4/#5 return a constant None,None leaf tuple, so no fresh leaf tuple allocation. #3 creates fresh lists but disables GC. No clean unchanged candidate under pinned spec; omitted from JSON pending adjudication. |
| regexredux | Current base regex/std threads. Probe #6: existing regex/Rayon and direct-buffer replacements. | Current base already parallelizes std-re work. Probe #2: ctypes PCRE2 JIT/multiprocessing, provided find_library(pcre2-8) finds the intended existing dylib. No global install or source patch to manufacture compatibility. |
| pidigits | Current #4 Rug/GMP sound baseline. Secondary #3, then #2 use raw GMP FFI and existing system GMP without new Cargo deps; ABI and old mem::uninitialized need build checks. | Probe #3: ctypes existing GMP and both extract(3)/extract(4), stepwise single-threaded. find_library(gmp) must resolve correct native dylib. |

## Pinned specification checks

### FASTA

examples/shootout/specs/fasta.html forbids optimizing cumulative lookup with scaling
or naive LCG arithmetic. It requires cumulative probabilities, linear/binary search,
a random calculation for every selected nucleotide, and no cached random sequence.

- Rust #6 computes seed = (seed * 3877 + 29573) % 139968, divides by IM as f64,
  builds cumulative floating probabilities, and scans them for every character.
- Rust #9 is excluded: normalize(p) returns (p * IM as f32) as u32.
- Python #3/#2 compute normalized seed/im each selection and call bisect.
- Python #5 is excluded: cumulative_probabilities(alphabet, im) scales probabilities.
- Python #8 is not a performance candidate: explicitly character-at-a-time output
  and naive linear subtraction. This corrects an early provisional suggestion.
- No precomputed 139968-output table should be accepted merely because archived.

### Binary-trees

Pinned spec permits default GC, per-node allocation, or a library memory pool.
It forbids custom pools and requires leaves/interior nodes to have the same memory
allocation, fully allocating trees before any nodes are collected.

- Rust #2 calls arena.alloc for every Tree, including leaves, using typed-arena.
- Rust #5 also creates every Tree via library bumpalo; it is a possible later
  candidate but requires a new pinned dependency and is omitted from JSON.
- Python current #2: "if not depth: return None, None". Base/#4/#5 similarly return
  constant tuple literals. CPython constant tuples are shared; confirm with a
  tiny disassembly/allocation check centrally before changing coverage.
- Python #3 creates node = [None,None] before its depth test, satisfying fresh
  same-representation leaves, but calls gc.disable(). Default-GC requirement
  needs adjudication; do not treat it as already accepted.

### Spectral-norm

Pinned spec requires the same algorithm and four separate functions/procedures/
methods like its Java example. Check matrix evaluator, A multiplication, transpose
multiplication, and their composition, not only final numeric equality.

- Python #4/#7 explicitly separate eval_A, A_sum, At_sum, multiply_AtAv.
- Rust #4 has a, mult (evaluator callback), mult_at_av, and outer spectralnorm;
  A and transpose share mult through a(j,i) callback. It retains both algorithm
  roles without caching the matrix, but literal function-count interpretation
  should be applied consistently with the current Rust reference.
- No proposal replaces matrix arithmetic with an unrelated algorithm.

## Exclusions and dependency costs

- Rust nbody #5/#7/#9 use x86 intrinsics; spectralnorm #6 and fannkuch #6 do too.
- Rust spectralnorm #7 and Mandelbrot #2/#5/#7 require generic-array/numeric-array
  and possibly num_traits, beyond current Cargo.toml.
- Rust binarytrees #3/#4 require toolshed; #5 requires bumpalo.
- Rust regexredux #7 is a potentially valuable PCRE2-JIT reference, but needs new
  pinned pcre2_sys/libc direct deps and verified native PCRE2 linking. Excluded
  from no-new-dependency JSON.
- Python pidigits #5 requires gmpy2. Excluded from JSON; do not globally install it.
- Python mandelbrot #7 unconditionally masks the last byte with
  0xff << (8 - n%8), zeroing it when width is divisible by eight. It may happen
  to match some empty boundary pixels, but is not a sound general replacement.
- Rust k-nucleotide prior exclusions remain intact: base/#2 wrong count-only
  tie ordering; #3/#4/#5/#6/#7/#9 emit G,T,C,A for equal frequency, with #4/#5
  also failing absent requested fragments. No repeated execution was performed.

## Harness and measurement constraints

Current Rust dependencies already include Rayon, typed-arena, regex, Rug, and
system-GMP integration. Most listed Rust candidates fit them unchanged.
Raw GMP #2/#3 link directly to libgmp, so root must propagate the existing isolated
native linker paths rather than silently select another installation.

The existing Python manifest launcher supports choosing fork. Use it for global
data inheritance and main-guard globals; do not rewrite official programs.
All fresh-process startup remains included. Parallel candidates can regress at
small workloads, so archived status and historical x86 timings establish no gain.

Keep the same eight columns and common cohort. Resolve explicit source/spec
conflicts before treating numeric output equality as conformance.
