import json,gzip,hashlib,collections,csv,re,subprocess,sys
from pathlib import Path
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout/results';idx=json.loads((root/'runs/index.json').read_text());run=root/'runs'/idx['current_run'];r=json.loads((run/'current.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (root/'current.json').read_bytes()==(run/'current.json').read_bytes();assert r['samples']==56 and len(r['implementations'])==8 and len(r['summary_benchmarks'])==8 and not r['machine']['repository']['dirty'];assert set(r['benchmark_order'])-set(r['summary_benchmarks'])=={'knucleotide','binarytrees'}
q=r['machine']['quiet_window']['samples'];assert len(q)==6 and all(x['idle_percent']>=90 for x in q)
raw=[json.loads(x) for x in gzip.decompress((run/'raw/calibration-raw.jsonl.gz').read_bytes()).splitlines()];counts=collections.Counter((x['benchmark'],x['implementation']) for x in raw);assert len(raw)==4200 and len(counts)==75 and set(counts.values())=={56};assert all(x['exit_code']==x['signal']==0 and x['run_id']==r['run_id'] for x in raw)
checks=json.loads(gzip.decompress((run/'raw/check.json.gz').read_bytes()));assert len(checks['checks'])==75
for n,b in r['benchmarks'].items():
 programs={k:b[k] for k in ('idiomatic','tuned')};programs.update(b['references'])
 for key,p in programs.items():
  path=repo/'examples/shootout'/p['source']['path'];assert sha(path)==p['source']['sha256'];data=subprocess.check_output(['git','show',r['machine']['repository']['revision']+':'+str(path.relative_to(repo))],cwd=repo);assert hashlib.sha256(data).hexdigest()==sha(path)
assert set(r['benchmarks']['knucleotide']['unavailable'])=={'rust','cpp','go','java'};assert set(r['benchmarks']['binarytrees']['unavailable'])=={'python'}
assert json.loads((run/'charts/provenance.json').read_text())['report_sha256']==sha(run/'current.json');rows=list(csv.DictReader((run/'charts/measurements.csv').open()));assert len(rows)==75;assert len(list(csv.DictReader((run/'charts/summaries.csv').open())))==8
for row in rows:
 b=r['benchmarks'][row['problem']];p=b[row['implementation']] if row['implementation'] in ('idiomatic','tuned') else b['references'][row['implementation']];assert abs(float(row['seconds'])-p['statistics']['median_elapsed_ns']/1e9)<1e-12
old=subprocess.check_output(['git','show','c77b6020c:examples/shootout/results/SHA256SUMS'],cwd=repo,text=True);immutable=0
for line in old.splitlines():
 digest,name=line.split('  ',1)
 if name.startswith('runs/') and name!='runs/index.json':assert sha(root/name)==digest;immutable+=1
for p in [root/'README.md',root/'threading.md',root/'remaining-gaps.md',run/'README.md',run/'charts/README.md',repo/'site/BENCHMARKS.md']:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if not target.startswith(('https:','http:','#')):assert (p.parent/target.split('#')[0]).exists(),(p,target)
# Verify every preserved gzip and JSON payload; reference source bytes are checked
# separately by manifest load and adopted-reference-provenance.json.
parsed=0
for base in [run,root/'evidence/reference-profile']:
 for p in base.rglob('*'):
  if not p.is_file():continue
  if p.suffix=='.gz':
   data=gzip.decompress(p.read_bytes())
   if p.name.endswith('.json.gz'):json.loads(data);parsed+=1
   if p.name.endswith('.jsonl.gz'):
    for line in data.splitlines():json.loads(line)
    parsed+=1
  elif p.suffix=='.json':json.loads(p.read_text());parsed+=1
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert sha(root/name)==digest,name
print('verified75programs x56samples =4200observations;8columns/8sharedproblems;75fixtures; unchanged historicalfiles',immutable,'JSONpayloads',parsed)
