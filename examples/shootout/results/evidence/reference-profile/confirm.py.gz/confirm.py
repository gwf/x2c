import json,sys,statistics,collections,datetime as dt,re,subprocess,hashlib
from pathlib import Path
root=Path('/tmp/x2c-reference-profile');sys.path.insert(0,'/Users/gary/.codex/worktrees/f2bc/x2c/examples/shootout/tools');import shootout as s
r=json.loads((root/'screen.json').read_text());m=s.load_manifest();bs={b['name']:b for b in m['benchmarks']}
a=collections.defaultdict(list)
for line in (root/'screen-raw.jsonl').read_text().splitlines():
 v=json.loads(line);a[v['id']].append(v['elapsed_ns'])
groups=collections.defaultdict(list)
for v in r:
 if v.get('correct'):groups[(v['problem'],v['language'])].append(v)
selected=[]
for (problem,lang),options in groups.items():
 baseline=statistics.median(a['baseline-'+problem+'-'+lang]) if a['baseline-'+problem+'-'+lang] else float('inf')
 # Include corrected FMA candidates and both near-equal winners for meaningful confirmation.
 ranked=sorted(options,key=lambda v:statistics.median(a[v['id']]) if a[v['id']] else 0)
 best=statistics.median(a[ranked[0]['id']]) if a[ranked[0]['id']] else 0
 for v in ranked:
  med=statistics.median(a[v['id']]) if a[v['id']] else 0
  if med<baseline*.98 and (med<=best*1.08 or med==0):selected.append(v)
selected.append({'id':'knucleotide-parallel','problem':'knucleotide','language':'idiomatic','binary':str(root/'knucleotide-parallel'),'source':str(root/'knucleotide-parallel.x'),'sha256':s.sha256(root/'knucleotide-parallel.x'),'correct':True})
(root/'confirm-selected.json').write_text(json.dumps(selected,indent=2)+'\n')
consecutive=[]
with (root/'confirm-quiet.jsonl').open('a') as log:
 while len(consecutive)<6:
  p=subprocess.run(['top','-l','2','-s','10','-n','0'],capture_output=True,text=True,check=True);idle=float(re.findall(r'([\d.]+)% idle',p.stdout)[-1]);sample={'at':dt.datetime.now(dt.timezone.utc).isoformat(),'idle_percent':idle};log.write(json.dumps(sample)+'\n');log.flush()
  if idle>=90:consecutive.append(sample)
  else:consecutive=[]
  print('quiet',idle,len(consecutive),flush=True)
(root/'confirm-receipt.json').write_text(json.dumps({'quiet_samples':consecutive,'rounds':8,'selection':'screened improvement plus FMA corrections; rotating baselines and candidates; local configured inputs','script_sha256':s.sha256(Path(__file__))},indent=2)+'\n')
for b in m['benchmarks']:
 options=[v for v in selected if v['problem']==b['name']]
 if not options:continue
 options=[{'id':'baseline-'+b['name']+'-'+lang,'problem':b['name'],'language':lang,'binary':str(s.binary_path(b['name'],lang))} for lang in sorted({v['language'] for v in options})]+options
 inp=s.BUILD/'inputs'/f'fasta-{b["stdin_fasta"]["local"]}.txt' if b.get('stdin_fasta') else None
 for turn in range(8):
  for v in options[turn%len(options):]+options[:turn%len(options)]:
   sample=s.measure_once(s.BUILD/'tools/measure',Path(v['binary']),m['profiles']['local'][b['name']],120,inp)
   with (root/'confirm-raw.jsonl').open('a') as f:f.write(json.dumps({'id':v['id'],'turn':turn,'at':dt.datetime.now(dt.timezone.utc).isoformat(),**sample})+'\n')
 print('confirmed',b['name'],flush=True)
