import json,subprocess
from pathlib import Path
root=Path('/tmp/x2c-reference-profile');r=json.loads((root/'screen.json').read_text())
for i in [9,10]:
 v=r[i];argv=v['compile_command'];argv.insert(1,'-ffp-contract=off');v['flags'].append('-ffp-contract=off');v['notes']+=' Disable FP contraction, matching source -mno-fma guidance and portable scalar fixture.'
 p=subprocess.run(argv,capture_output=True);Path(v['directory'],'build-no-fma.log').write_bytes(p.stdout+p.stderr)
 if p.returncode:continue
 want=Path('examples/shootout/benchmarks/mandelbrot/expected/200.out').read_bytes();p=subprocess.run([v['binary'],'200'],capture_output=True);Path(v['directory'],'fixture-no-fma.out').write_bytes(p.stdout)
 v['no_fma_fixture_pass']=p.returncode==0 and p.stdout==want;print(v['id'],v['no_fma_fixture_pass'])
(root/'screen.json').write_text(json.dumps(r,indent=2)+'\n')
