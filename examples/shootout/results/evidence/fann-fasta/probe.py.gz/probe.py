from pathlib import Path
import subprocess,json,shutil,statistics,os,hashlib
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=Path(__file__).resolve().parent
baseline=(repo/'examples/shootout/benchmarks/fasta/main.x').read_text()
variant=baseline.replace('int main(int argc, char **argv) {','class Choice { char letter; double cumulative; } *;\n\nint main(int argc, char **argv) {',1)
start=variant.index('static void _random(')
variant=variant[:start]+'''static void _random(String letters, Array probabilities, int count) {
  Array choices = _choices(letters, probabilities);
  Buffer line = auto Buffer.new(0);
  for (int start = 0; start < count; start += 60) {
    line.clear();
    int end = start + 60 < count ? start + 60 : count;
    for (int i = start; i < end; i++) {
      seed = (seed * 3877 + 29573) % 139968;
      double random = (double) seed / 139968;
      int index = 0;
      Choice choice = choices[index];
      while (random >= choice.cumulative) choice = choices[++index];
      line.write_char(choice.letter);
    }
    puts(line.str());
  }
}

static Array _choices(String letters, Array probabilities) {
  Array choices = [];
  double cumulative = 0;
  for (int i = 0; i < probabilities.len(); i++) {
    cumulative += probabilities[i].double();
    choices.push(Choice.new(letters[i], cumulative));
  }
  return choices;
}

static void Choice.init(Choice choice, char letter, double cumulative) {
  choice.letter = letter;
  choice.cumulative = cumulative;
}
'''
shutil.copyfile(repo/'builds/0/libx2c.a',root/'libx2c.a')
commands=[]
for kind,text in [('baseline',baseline),('records',variant)]:
 src=root/(kind+'.x');src.write_text(text);gen=root/kind;gen.mkdir(exist_ok=True)
 argv=[str(repo/'builds/0/x2c'),'translate','--out-dir',str(gen),str(src)];subprocess.run(argv,check=True,capture_output=True);commands.append(argv)
 argv=['/usr/bin/cc','-O2','-DNDEBUG','-iquote',str(repo/'include/x2c'),str(gen/(kind+'.c')),'-L',str(root),'-lx2c','-lm','-o',str(gen/'program')];subprocess.run(argv,check=True,capture_output=True);commands.append(argv)
# Independent contributed C output oracle.
c=root/'c';subprocess.run(['/usr/bin/cc','-O2','-DNDEBUG',str(repo/'examples/shootout/benchmarks/fasta/main.c'),'-o',str(c)],check=True)
checks=[]
for n in (1,2,19,20,21,59,60,61,1000,100000,500000):
 out=[subprocess.check_output([str(root/k/'program'),str(n)]) for k in ('baseline','records')]
 want=subprocess.check_output([str(c),str(n)]);assert out[0]==out[1]==want,n
 checks.append({'n':n,'sha256':hashlib.sha256(want).hexdigest(),'all_equal':True})
measure=root/'measure';subprocess.run(['/usr/bin/cc','-O2',str(repo/'examples/shootout/tools/measure.c'),'-o',str(measure)],check=True)
raw=[];summaries=[];env=dict(os.environ,LC_ALL='C',TZ='UTC')
for n in (100000,500000):
 for k in ('baseline','records'):subprocess.run([str(root/k/'program'),str(n)],check=True,stdout=subprocess.DEVNULL,env=env)
 for i in range(12):
  for k in (('baseline','records') if i%2==0 else ('records','baseline')):
   r=json.loads(subprocess.check_output([str(measure),str(root/k/'program'),str(n)],env=env));r.update(n=n,sample=i+1,implementation=k);raw.append(r)
 vals={k:statistics.median(r['elapsed_ns']/1e6 for r in raw if r['n']==n and r['implementation']==k) for k in ('baseline','records')}
 vals.update(n=n,wins=sum(next(r['elapsed_ns'] for r in raw if r['n']==n and r['sample']==i and r['implementation']=='records')<next(r['elapsed_ns'] for r in raw if r['n']==n and r['sample']==i and r['implementation']=='baseline') for i in range(1,13)));summaries.append(vals)
(root/'results.json').write_text(json.dumps({'schema':1,'checks':checks,'raw':raw,'summaries_ms':summaries,'commands':commands,'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'limit':'Bounded alternating-pair active-desktop probe; not full canonical or quiet calibration.'},indent=2)+'\n')
print(json.dumps(summaries))
