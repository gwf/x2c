from pathlib import Path
import json,subprocess,shutil,statistics,hashlib,os,time
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=Path('/tmp/x2c-fannkuch-bulk-probe');root.mkdir(exist_ok=True)
source=subprocess.check_output(['git','show','HEAD:examples/shootout/benchmarks/fannkuchredux/main.x'],cwd=repo).decode();needle='    for (int i = 0; i < n; i++) working[i] = permutation[i];';assert source.count(needle)==1
shutil.copyfile(repo/'builds/0/libx2c.a',root/'libx2c.a')
receipt=json.loads((repo/'examples/build/shootout/latest/build.json').read_text())['benchmarks']['fannkuchredux']['idiomatic']
commands=[]
for kind,text in [('baseline',source),('bulk',source.replace(needle,'    working.setslice(0, n, permutation);',1))]:
 src=root/(kind+'.x');src.write_text(text);out=root/kind;out.mkdir(exist_ok=True)
 argv=[str(repo/'builds/0/x2c'),'translate','--out-dir',str(out),str(src)];subprocess.run(argv,check=True,capture_output=True);commands.append(argv)
 argv=list(receipt['compile_command']);argv[argv.index(str(repo/'examples/build/shootout/fannkuchredux/idiomatic/generated/main.c'))]=str(out/(kind+'.c'));argv[argv.index(str(repo/'builds/0'))]=str(root);argv[-1]=str(out/'program');subprocess.run(argv,check=True,capture_output=True);commands.append(argv)
for n in (7,8,9):
 outputs=[subprocess.check_output([str(root/k/'program'),str(n)]) for k in ('baseline','bulk')]
 assert outputs[0]==outputs[1]==subprocess.check_output([str(repo/'examples/build/shootout/fannkuchredux/c/program'),str(n)])
env=dict(os.environ,LC_ALL='C',TZ='UTC');measure=repo/'examples/build/shootout/tools/measure';raw=[]
for kind in ('baseline','bulk'):subprocess.run([str(root/kind/'program'),'9'],stdout=subprocess.DEVNULL,check=True,env=env)
for i in range(12):
 for kind in (('baseline','bulk') if i%2==0 else ('bulk','baseline')):
  r=json.loads(subprocess.check_output([str(measure),str(root/kind/'program'),'9'],env=env));r.update(sample=i+1,implementation=kind);raw.append(r)
summary={k:statistics.median([r['elapsed_ns']/1e6 for r in raw if r['implementation']==k]) for k in ('baseline','bulk')}
summary['bulk_wins']=sum(next(r['elapsed_ns'] for r in raw if r['sample']==i and r['implementation']=='bulk') < next(r['elapsed_ns'] for r in raw if r['sample']==i and r['implementation']=='baseline') for i in range(1,13))
(root/'results.json').write_text(json.dumps({'summary_ms':summary,'raw':raw,'commands':commands,'runtime_sha256':hashlib.sha256((root/'libx2c.a').read_bytes()).hexdigest(),'limit':'Bounded active-desktop probe; not a fresh quiet full calibration. Source and Git unchanged.'},indent=2)+'\n')
print(json.dumps(summary))
