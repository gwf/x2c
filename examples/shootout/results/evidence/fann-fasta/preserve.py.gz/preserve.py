"""Archive this one-off calibration using the existing saved-run format."""
from pathlib import Path
import csv,gzip,hashlib,json,shutil,subprocess,sys
from datetime import datetime
from zoneinfo import ZoneInfo
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout/results';scratch=Path(__file__).resolve().parent
publication=subprocess.check_output(['git','rev-parse',sys.argv[1]],cwd=repo).decode().strip()
r=json.loads((root/'current.json').read_text());run=r['run_id'];oldrun='20261031T134323Z'
assert run!=oldrun and r['samples']==16 and len(r['implementations'])==8 and len(r['summary_benchmarks'])==9
assert not r['machine']['repository']['dirty'] and r['machine']['quiet_window']
assert subprocess.check_output(['git','show',publication+':examples/shootout/results/current.json'],cwd=repo)==(root/'current.json').read_bytes()
build=repo/'examples/build/shootout';receipt=json.loads((build/'latest/receipt.json').read_text());assert receipt['run_id']==run
raw=(build/'calibration-raw.jsonl').read_bytes();assert len(raw.splitlines())==1216
for name,e in r['benchmarks'].items():
 programs={k:e[k] for k in ('idiomatic','tuned')};programs.update(e['references'])
 for key,p in programs.items():
  source=repo/'examples/shootout'/p['source']['path'];assert hashlib.sha256(source.read_bytes()).hexdigest()==p['source']['sha256']
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def zipped(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,mtime=0))
p=root/'runs'/run;p.mkdir(exist_ok=False)
for name in ('current.json','current.md'):(p/name).write_bytes((root/name).read_bytes())
zipped(p/'baseline.json.gz',(repo/'examples/shootout/baseline.json').read_bytes());shutil.copyfile(repo/'examples/shootout/benchmarks.json',p/'benchmarks.json')
charts=p/'charts';charts.mkdir();renderer=(root/'runs'/oldrun/'charts/render.py').read_text()
renderer=renderer.replace('def heading(fig, title, subtitle):','def heading(fig, title, subtitle):\n    subtitle += "\\nMixed serial/parallel contributions; both x2c entries are serial."')
renderer=renderer.replace('"java_process_model": "Fresh JVM per sample; startup and JIT compilation included",','"java_process_model": "Fresh JVM per sample; startup and JIT compilation included",\n        "execution_modes": "Mixed serial/parallel official contributions; both x2c entries serial",')
(charts/'render.py').write_text(renderer)
subprocess.run(['/Users/gary/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3',str(charts/'render.py'),str(p/'current.json'),str(charts)],check=True)
for f in [build/'calibration-raw.jsonl',*(build/'latest'/name for name in ('build.json','check.json','receipt.json','summary.json','summary.md')),repo/'debug/fann-fasta-quiet-window.jsonl',repo/'debug/fann-fasta-calibration.log',scratch/'quiet-run.py']:
 zipped(p/'raw'/(f.name+'.gz'),f.read_bytes())
o=json.loads((root/'runs'/oldrun/'current.json').read_text());comp=[]
for name in r['benchmark_order']:
 for variant in ('idiomatic','tuned'):
  before=o['benchmarks'][name];after=r['benchmarks'][name]
  comp.append({'problem':name,'implementation':variant,'before_ms':before[variant]['statistics']['median_elapsed_ns']/1e6,'after_ms':after[variant]['statistics']['median_elapsed_ns']/1e6,'before_over_C':before['factors']['time_'+variant+'_over_c'],'after_over_C':after['factors']['time_'+variant+'_over_c']})
with (charts/'comparison.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=comp[0]);w.writeheader();w.writerows(comp)
web={'schema':1,'run_id':run,'publication_revision':publication,'measured_revision':r['machine']['repository']['revision'],'measured_tree_dirty':False,'profile':r['profile'],'cpu_model':r['machine'].get('cpu_model'),'samples':16,'process_warmups':r['warmups'],'implementations':r['implementations'],'summary_benchmarks':r['summary_benchmarks'],'java_process_model':'fresh JVM per sample; startup and JIT included','execution_modes':'mixed serial/parallel official contributions; both x2c entries serial','historical_source_metric_issue':False,'measurements':list(csv.DictReader((charts/'measurements.csv').open()))};dump(p/'website.json',web)
text=f'''# Run {run}

Published report revision: `{publication}`.
Measured source revision: `{r['machine']['repository']['revision']}`.

This local-profile run measures ordinary Array bulk copying in fannkuch-redux
and ordinary Choice records in FASTA. All 76 official fixture and local-output
checks pass. Sixteen fresh-process samples per program yield 1,216 observations.
The summary cohort is the same nine problems across all eight columns.

`current.json` is the exact chart input; its hash matches chart provenance.
`baseline.json.gz`, `benchmarks.json`, and `raw/` retain the original baseline,
inputs, source hashes, full samples, build/check receipts, and quiet observations.
Timing began after six consecutive ten-second CPU samples were at least 90
percent idle. This records the pre-run window, not zero background activity
throughout measurement. Native binaries and external caches are not archived.
Recover exact sources from the publication revision and follow the parent
[recovery guide](../../README.md).

`charts/` contains PNG/SVG/PDF, CSVs, renderer, comparison, and provenance.
`website.json` is the curated public export; machine-path receipts are audit
records rather than website assets. Java includes JVM startup and JIT in every
sample. Canonical-size timing remains unrun.

## Changed idiomatic entries: separate-run comparison

Compare with run `{oldrun}`. Values are median elapsed milliseconds; these
full runs are not an alternating causal experiment. C reference drift is shown.

| Problem | Before ms | After ms | C before ms | C after ms | Before/C | After/C |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for name in ('fannkuchredux','fasta'):
 a=o['benchmarks'][name];b=r['benchmarks'][name]
 text+=f"| {name} | {a['idiomatic']['statistics']['median_elapsed_ns']/1e6:.3f} | {b['idiomatic']['statistics']['median_elapsed_ns']/1e6:.3f} | {a['references']['c']['statistics']['median_elapsed_ns']/1e6:.3f} | {b['references']['c']['statistics']['median_elapsed_ns']/1e6:.3f} | {a['factors']['time_idiomatic_over_c']:.2f} | {b['factors']['time_idiomatic_over_c']:.2f} |\n"
text+='''
Fannkuch uses `working.setslice(0, n, permutation)` to copy into the existing,
separate working Array. FASTA builds an ordinary Array of Choice objects,
precomputes cumulative probabilities once, and reads letter/probability fields
during sampling. Alphabet order, cumulative addition order, random-number
steps, seed continuity, and output wrapping are preserved. Neither change uses
typed containers, SubStrings, raw storage, a custom allocator, or parallelism.

The separate active-desktop alternating probes won all twelve pairs for each
workload/size. FASTA matches the old source and contributed C at eleven sizes;
fannkuch matches both at three sizes. These probes are preliminary evidence,
separate from this full quiet calibration. The original sources, scripts,
results, and source diff are in `../../evidence/fann-fasta/`.

The adopted C binary-trees entry uses pthread workers. All x2c entries remain
serial. This is a comparison of selected programs with mixed execution modes;
see the [threading explanation](../../threading.md).
'''
(p/'README.md').write_text(text);(charts/'README.md').write_text(text.replace('[recovery guide](../../README.md)','[recovery guide](../../../README.md)').replace('`../../evidence/fann-fasta/`','`../../../evidence/fann-fasta/`').replace('(../../threading.md)','(../../../threading.md)'))
e=root/'evidence/fann-fasta';e.mkdir(exist_ok=False)
for f in [scratch/'probe.py',scratch/'results.json',scratch/'baseline.x',scratch/'records.x',scratch/'quiet-run.py',scratch/'preserve.py',repo/'debug/fann-fasta-check.log',repo/'debug/fann-fasta-probe.log',repo/'debug/fann-fasta-bulk-probe.log',repo/'debug/fann-fasta-tests.log',repo/'debug/fann-fasta-snapshot-tests.log']:
 zipped(e/(f.name+'.gz'),f.read_bytes())
for name in ('baseline.x','bulk.x','results.json'):zipped(e/('fann-'+name+'.gz'),(Path('/tmp/x2c-fannkuch-bulk-probe')/name).read_bytes())
zipped(e/'fann-probe.py.gz',(scratch/'fann-probe.py').read_bytes())
diff=subprocess.check_output(['git','diff','3edfed569',r['machine']['repository']['revision'],'--','examples/shootout/benchmarks/fannkuchredux/main.x','examples/shootout/benchmarks/fasta/main.x'],cwd=repo);zipped(e/'changes.diff.gz',diff)
for f in (repo/'debug/fann-fasta-interfered-attempt').iterdir():
 zipped(e/'interfered-attempt'/(f.name+'.gz'),f.read_bytes())
idx=json.loads((root/'runs/index.json').read_text());idx['current_run']=run;idx['runs'].append({'run_id':run,'path':run,'publication_revision':publication,'measured_revision':web['measured_revision'],'implementations':r['implementations'],'summary_problem_count':9,'sample_recovery':'original full calibration JSONL and receipts, compressed without changing bytes','historical_source_metric_issue':False});dump(root/'runs/index.json',idx)
f=root/'README.md';s=f.read_text();start=s.index('The current public candidate');end=s.index('## Saved runs')
when=datetime.fromisoformat(r['machine']['captured_at_utc'].replace('Z','+00:00'));local=when.astimezone(ZoneInfo('America/Los_Angeles'))
s=s[:start]+f'''The current public candidate is [run {run}](runs/{run}/README.md),
measured from clean source revision `{web['measured_revision']}` and first
published with results in `{publication}`. Run identifiers use UTC.
Observation time: {local.strftime('%Y-%m-%d %H:%M %Z')} / {when.strftime('%Y-%m-%d %H:%M UTC')}.

It covers 76 programs, eight columns, and sixteen fresh-process samples per
program (1,216 observations). All official fixtures and local-profile output
checks passed. Summary charts use the nine problems shared by all columns.
The four available k-nucleotide programs remain in per-problem tables.

'''+s[end:]
s=s.replace('Latest: ordinary Node and Buffer rewrites','Ordinary Node and Buffer rewrites')
s=s.replace('\n[runs/index.json]',f'| [{run}](runs/{run}/README.md) | 8 | 9 | Latest: fannkuch bulk copy and FASTA Choice records |\n\n[runs/index.json]')
# Update only recovery commands; retain immutable historical table rows.
parts=s.split('```');s='```'.join(part.replace(oldrun,run).replace('427ee5b3c4176f4bc2dec90fae149bcc68279ea3',publication) if i%2 else part for i,part in enumerate(parts))
s=s.replace('C binary-trees uses parallel\nworkers.','C binary-trees uses parallel\nworkers; [threading rules and recommendations](threading.md) explain the scope.')
f.write_text(s)
f=repo/'site/BENCHMARKS.md';s=f.read_text().replace(oldrun,run).replace('2026-10-31 06:43 PDT / 2026-10-31 13:43 UTC',local.strftime('%Y-%m-%d %H:%M %Z')+' / '+when.strftime('%Y-%m-%d %H:%M UTC'))
s=s.replace('C binary-trees uses parallel workers.', 'C binary-trees uses parallel workers; both x2c columns are serial. Keep the\n  mixed execution-mode annotation on figures and link the\n  [threading explanation](../examples/shootout/results/threading.md).')
f.write_text(s)
rows=[]
for name,v in r['benchmarks'].items():
 a=v['idiomatic']['statistics']['median_elapsed_ns']/1e6;c=v['references']['c']['statistics']['median_elapsed_ns']/1e6;t=v['tuned']['statistics']['median_elapsed_ns']/1e6;rows.append((a-c,name,a,c,t,a/c))
s=f'''# Remaining idiomatic x2c performance gaps

Current run `{run}`, local profile, measured source
`{web['measured_revision']}` on Apple M4 Max. Values are sixteen-sample median
elapsed milliseconds. These selected-program differences do not isolate
language, allocation, or threading overhead. Rows rank absolute excess over C.

| Workload | Idiomatic ms | C ms | Tuned ms | Idiomatic/C | Excess over C ms |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
for gap,name,a,c,t,ratio in sorted(rows,reverse=True):s+=f'| {name} | {a:.3f} | {c:.3f} | {t:.3f} | {ratio:.2f} | {gap:.3f} |\n'
s+=f'''
## Completed source changes

Fannkuch now copies into its existing working Array with `setslice`. FASTA
precomputes an Array of ordinary Choice objects, then reads their fields during
sampling. The cumulative probabilities and random-number steps are unchanged.
The earlier ordinary Node, reverse-complement Buffer, n-body pair, FASTA Buffer,
and regex JIT changes remain applied. No typed containers, SubStrings, raw
storage, custom allocators, or compiler/runtime changes were introduced.

[This run's comparison](runs/{run}/README.md) records before/after medians
alongside C drift. Full runs are separate observations, not alternating pairs.
The saved [probe evidence](evidence/README.md) records the paired experiments.

## Remaining candidates and limits

- **K-nucleotide:** short String keys, Map reads/writes, and numeric conversions
  need attribution. The obvious-looking `counts[key] += 1` substitution already
  regressed 20-21 percent and lost all twelve pairs at both tested sizes. Keep
  the existing counting loop. Generic dispatch is a hypothesis, not profiled
  attribution; the failed source substitution does not reject all Map work.
- **Spectral-norm and fannkuch-redux:** generic Array access and Var numeric
  conversion remain plausible costs after the fannkuch copy improvement.
  Typed containers are excluded from the idiomatic column. Profile ordinary
  operations before proposing runtime or compiler specialization.
- **Binary-trees:** C uses pthread workers, while both x2c entries remain serial.
  The ordinary Node representation gap to tuned x2c is addressed. The remaining
  C ratio is not pure allocation or language overhead. Parallelism is a separate
  possible change, subject to each official specification; see [threading](threading.md).
- **FASTA and reverse-complement:** allocation, generic operations, and input/output
  handling remain profiling candidates. The validated records and Buffer work
  does not demonstrate another compliant source fix.

Original hypotheses, older results, and the rejected Map experiment remain in
the immutable archives. Java includes startup/JIT. Canonical-size timing is unrun.
''';(root/'remaining-gaps.md').write_text(s)
f=root/'evidence/README.md';f.write_text(f.read_text()+f'''\n## Fannkuch bulk copy and FASTA Choice records\n\n`fann-fasta/` retains old/new sources, the source diff, probe scripts and raw\nresults, focused fixture/quick checks, and the quiet-window runner. FASTA matches\nold/C outputs at eleven sizes; fannkuch matches at three. Paired probes use\nactive-desktop timing, not an established quiet window. The full quiet\ncalibration is [run {run}](../runs/{run}/README.md). The interrupted first
attempt retains 504 partial samples and its quiet log under `interfered-attempt/`;
unrelated compiler workers appeared during measurement, so those samples were
excluded from the final report.\n''')
paths=sorted([q for parent in (root/'runs',root/'evidence') for q in parent.rglob('*') if q.is_file()]+[root/'requirements-charts.txt'])
(root/'SHA256SUMS').write_text(''.join(hashlib.sha256(q.read_bytes()).hexdigest()+'  '+str(q.relative_to(root))+'\n' for q in paths))
print('Preserved run',run,'checksummed files',len(paths))
