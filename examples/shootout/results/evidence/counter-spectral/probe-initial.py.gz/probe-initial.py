from pathlib import Path
import collections,hashlib,json,os,shutil,statistics,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copyfile(repo/'builds/0/libx2c.a',root/'libx2c.a');commands=[]
def call(args,**kw):
 args=[str(a) for a in args];commands.append(args);return subprocess.run(args,check=True,**kw)
for name in ('knucleotide-before','knucleotide-counter','spectralnorm-before','spectralnorm-parallel'):
 out=root/name;out.mkdir(exist_ok=True)
 call([repo/'builds/0/x2c','translate','--out-dir',out,root/(name+'.x')],capture_output=True)
 call(['/usr/bin/cc','-O2','-DNDEBUG','-I/opt/homebrew/include','-iquote',repo/'include/x2c',out/(name+'.c'),'-L',root,'-lx2c','-lm','-L/opt/homebrew/lib','-o',out/'program'],capture_output=True)
for name in ('fasta','spectralnorm'):
 call(['/usr/bin/cc','-O2',repo/f'examples/shootout/benchmarks/{name}/main.c','-lm','-o',root/(name+'-c')],capture_output=True)
call(['/usr/bin/cc','-O2',repo/'examples/shootout/tools/measure.c','-o',root/'measure'])
checks=[]
for n in (1,2,3,5,6,7,99,100,101,500,1000):
 want=subprocess.check_output([root/'spectralnorm-c',str(n)])
 for name in ('spectralnorm-before','spectralnorm-parallel'):
  for repeat in range(3):assert subprocess.check_output([root/name/'program',str(n)])==want,(name,n)
 checks.append({'problem':'spectralnorm','n':n,'repeats_per_source':3,'sha256':hashlib.sha256(want).hexdigest()})
print('spectral output checks passed',flush=True)
def oracle(data):
 seq=[];found=False
 for line in data.decode().splitlines():
  if not found:
   if line.startswith('>THREE'):found=True
  elif line.startswith('>'):break
  else:seq.append(line.strip())
 seq=''.join(seq).upper();lines=[]
 for width in (1,2):
  counts=collections.Counter(seq[i:i+width] for i in range(len(seq)-width+1))
  for key,count in sorted(counts.items(),key=lambda kv:(-kv[1],kv[0])):lines.append(f'{key} {100.0*count/(len(seq)-width+1):.3f}')
  lines.append('')
 for key in ('GGT','GGTA','GGTATT','GGTATTTTAATT','GGTATTTTAATTTATAGT'):
  count=sum(seq[i:i+len(key)]==key for i in range(len(seq)-len(key)+1));lines.append(f'{count}\t{key}')
 return ('\n'.join(lines)+'\n').encode()
inputs=root/'inputs';inputs.mkdir(exist_ok=True)
cases={str(n):subprocess.check_output([root/'fasta-c',str(n)]) for n in (1,2,20,1000,20000,100000)}
for i,seq in enumerate(('', 'A','AC','ACGT','GGTATTTTAATTTATAGT','acgTggtATT','AAAAAAA','TTTTGGGGCCCCAAAA','GGTGGTGGTA')):cases['edge-'+str(i)]=('>THREE test\n'+seq+('\n' if seq else '')+'>FOUR ignored\nGGTATT\n').encode()
cases['official']=(repo/'examples/shootout/benchmarks/knucleotide/input.txt').read_bytes()
for name,data in cases.items():
 want=oracle(data);(inputs/(name+'.fasta')).write_bytes(data);(inputs/(name+'.out')).write_bytes(want)
 for variant in ('knucleotide-before','knucleotide-counter'):assert subprocess.check_output([root/variant/'program'],input=data)==want,(name,variant)
 checks.append({'problem':'knucleotide','input':name,'sha256':hashlib.sha256(want).hexdigest()})
print('k-nucleotide output checks passed',flush=True)
raw=[];summary=[];env=dict(os.environ,LC_ALL='C',TZ='UTC')
for problem,sizes,before,after in [('knucleotide',(20000,100000),'knucleotide-before','knucleotide-counter'),('spectralnorm',(100,500,1000),'spectralnorm-before','spectralnorm-parallel')]:
 for n in sizes:
  args=[] if problem=='knucleotide' else [str(n)]
  data=cases[str(n)] if problem=='knucleotide' else None
  for kind in (before,after):subprocess.run([root/kind/'program',*args],input=data,stdout=subprocess.DEVNULL,check=True,env=env)
  for sample in range(12):
   for kind in ((before,after) if sample%2==0 else (after,before)):
    p=subprocess.run([root/'measure',root/kind/'program',*args],input=data,capture_output=True,check=True,env=env)
    v=json.loads(p.stdout);assert v['exit_code']==0 and v['signal']==0;v.update(problem=problem,n=n,sample=sample+1,implementation=kind);raw.append(v)
  vals={kind:statistics.median(v['elapsed_ns'] for v in raw if v['problem']==problem and v['n']==n and v['implementation']==kind)/1e6 for kind in (before,after)}
  vals.update(problem=problem,n=n,wins=sum(next(v['elapsed_ns'] for v in raw if v['problem']==problem and v['n']==n and v['implementation']==after and v['sample']==s)<next(v['elapsed_ns'] for v in raw if v['problem']==problem and v['n']==n and v['implementation']==before and v['sample']==s) for s in range(1,13)))
  summary.append(vals);print(json.dumps(vals),flush=True)
r={'schema':1,'checks':checks,'raw':raw,'summary_ms':summary,'commands':commands,'compiler_sha256':sha(repo/'builds/0/x2c'),'runtime_sha256':sha(root/'libx2c.a'),'source_sha256':{p.name:sha(p) for p in root.glob('*.x')},'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'limit':'Alternating-pair active-desktop probe; a quiet validation follows for adopted candidates.'}
(root/'results.json').write_text(json.dumps(r,indent=2)+'\n')
