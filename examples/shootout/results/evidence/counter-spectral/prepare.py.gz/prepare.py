from pathlib import Path
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=Path(__file__).resolve().parent
s=(repo/'examples/shootout/benchmarks/knucleotide/main.x').read_text();(root/'knucleotide-before.x').write_text(s)
s=s.replace('int main(void) {','class Counter { int value; } *;\n\nint main(void) {',1)
s=s.replace('counts[b].int() - counts[a].int()','_frequency(counts, b) - _frequency(counts, a)').replace('100.0 * counts[key].int()', '100.0 * _frequency(counts, key)').replace('counts.getdefault(key, 0), key','_frequency(counts, key), key')
s=s.replace('    counts[key] = counts.getdefault(key, 0).int() + 1;','''    Var stored;
    if (counts.try_get(key, stored)) {
      Counter counter = stored;
      counter.value++;
    }
    else counts[key] = Counter.new(1);''')
s+='''
static void Counter.init(Counter counter, int value) {
  counter.value = value;
}

static int _frequency(Map counts, String key) {
  Var stored;
  if (!counts.try_get(key, stored)) return 0;
  Counter counter = stored;
  return counter.value;
}
''';(root/'knucleotide-counter.x').write_text(s)
s=(repo/'examples/shootout/benchmarks/spectralnorm/main.x').read_text();(root/'spectralnorm-before.x').write_text(s)
s=s.replace('int main(int argc, char **argv) {','''class Rows {
  Array input, output;
  int first, last, transpose;
  Thread worker;
} *;

int main(int argc, char **argv) {''',1)
s=s.replace('  _a_times(input, scratch);\n  _at_times(scratch, output);','  _multiply(input, scratch, 0);\n  _multiply(scratch, output, 1);')
a=s.index('static void _a_times(');s=s[:a]+'''static void _multiply(Array input, Array output, int transpose) {
  int n = input.len(), workers = n < 6 ? n : 6;
  auto {
    Array batches = [];
    for (int worker = 0; worker < workers; worker++)
      batches.push(Rows.new(input, output,
        n * worker / workers, n * (worker + 1) / workers, transpose));
    foreach (Rows rows in batches) {
      rows.worker.join();
      rows.worker.free();
    }
  }
}

static void Rows.init(Rows rows, Array input, Array output,
  int first, int last, int transpose) {
  rows.input = input;
  rows.output = output;
  rows.first = first;
  rows.last = last;
  rows.transpose = transpose;
  rows.worker = Thread.start(_calculate_rows, rows);
}

static Var _calculate_rows(Var input) {
  Rows rows = input;
  int n = rows.input.len();
  for (int i = rows.first; i < rows.last; i++) {
    double sum = 0.0;
    for (int j = 0; j < n; j++)
      sum += (rows.transpose ? _entry(j, i) : _entry(i, j)) *
        rows.input[j].double();
    rows.output[i] = sum;
  }
  return void;
}

static double _entry(int i, int j) =>
  1.0 / ((i + j) * (i + j + 1) / 2 + i + 1);
''';(root/'spectralnorm-parallel.x').write_text(s)
