"""Preserve one completed calibration and its adopted/rejected source probes."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import csv,gzip,hashlib,json,shutil,subprocess,sys
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout/results';scratch=Path(__file__).resolve().parent
oldrun='20261031T145604Z';publication=subprocess.check_output(['git','rev-parse',sys.argv[1]],cwd=repo,text=True).strip()
r=json.loads((root/'current.json').read_text());run=r['run_id'];assert run!=oldrun
assert r['samples']==16 and len(r['implementations'])==8 and len(r['summary_benchmarks'])==9 and not r['machine']['repository']['dirty']
assert subprocess.check_output(['git','show',publication+':examples/shootout/results/current.json'],cwd=repo)==(root/'current.json').read_bytes()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def zipped(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(b,mtime=0))
build=repo/'examples/build/shootout';raw=(build/'calibration-raw.jsonl').read_bytes();assert len(raw.splitlines())==1216
assert json.loads((build/'latest/receipt.json').read_text())['run_id']==run
for name,e in r['benchmarks'].items():
 programs={k:e[k] for k in ('idiomatic','tuned')};programs.update(e['references'])
 for k,v in programs.items():assert sha(repo/'examples/shootout'/v['source']['path'])==v['source']['sha256']
p=root/'runs'/run;p.mkdir(exist_ok=False)
for name in ('current.json','current.md'):(p/name).write_bytes((root/name).read_bytes())
zipped(p/'baseline.json.gz',(repo/'examples/shootout/baseline.json').read_bytes());shutil.copyfile(repo/'examples/shootout/benchmarks.json',p/'benchmarks.json')
for f in [build/'calibration-raw.jsonl',*(build/'latest'/n for n in ('build.json','check.json','receipt.json','summary.json','summary.md')),repo/'debug/counter-spectral-calibration.log',repo/'debug/counter-spectral-quiet-window.jsonl',scratch/'quiet-run.py']:
 zipped(p/'raw'/(f.name+'.gz'),f.read_bytes())
charts=p/'charts';charts.mkdir();renderer=(root/'runs'/oldrun/'charts/render.py').read_text()
renderer=renderer.replace('Mixed serial/parallel programs; x2c binary-trees uses parallel depth batches.','Mixed serial/parallel programs; idiomatic x2c uses threads for trees and spectral-norm.')
renderer=renderer.replace('Mixed serial/parallel official contributions; both x2c binary-trees entries parallel','Mixed serial/parallel contributions; both x2c binary-trees entries parallel; idiomatic spectral-norm parallel at N>=256')
(charts/'render.py').write_text(renderer)
python='/Users/gary/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
subprocess.run([python,str(charts/'render.py'),str(p/'current.json'),str(charts)],check=True)
e=root/'evidence/counter-spectral';e.mkdir(exist_ok=False)
for name in ('prepare.py','probe-initial.py','probe.py','results-initial.json','results-cutoff.json','quiet-probe.py','results-quiet.json','knucleotide-before.x','knucleotide-counter.x','spectralnorm-before.x','spectralnorm-parallel-initial.x','spectralnorm-parallel.x','quiet-run.py','preserve.py','render-probes.py'):
 zipped(e/(name+'.gz'),(scratch/name).read_bytes())
for f in (scratch/'inputs').iterdir():zipped(e/'inputs'/(f.name+'.gz'),f.read_bytes())
for name in ('counter-spectral-probe.log','counter-spectral-cutoff-probe.log','counter-spectral-quiet-probe.log','counter-spectral-probe-quiet-window.jsonl','counter-spectral-check.log'):
 zipped(e/(name+'.gz'),(repo/'debug'/name).read_bytes())
for paused in (repo/'debug').glob('counter-spectral-paused-window*'):
 for f in paused.iterdir():
  zipped(e/paused.name/(f.name+'.gz'),f.read_bytes())
zipped(e/'changes.diff.gz',subprocess.check_output(['git','diff','424a35a9e',r['machine']['repository']['revision'],'--','examples/shootout/benchmarks/spectralnorm/main.x','examples/shootout/benchmarks/knucleotide/main.x'],cwd=repo))
shutil.copyfile(scratch/'render-probes.py',charts/'render-probes.py');subprocess.run([python,str(charts/'render-probes.py'),str(e/'results-quiet.json.gz'),str(charts)],check=True)
old=json.loads((root/'runs'/oldrun/'current.json').read_text());comparison=[]
for name in r['benchmark_order']:
 for variant in ('idiomatic','tuned'):
  a=old['benchmarks'][name];b=r['benchmarks'][name];comparison.append({'problem':name,'implementation':variant,'before_ms':a[variant]['statistics']['median_elapsed_ns']/1e6,'after_ms':b[variant]['statistics']['median_elapsed_ns']/1e6,'before_over_C':a['factors']['time_'+variant+'_over_c'],'after_over_C':b['factors']['time_'+variant+'_over_c']})
with (charts/'comparison.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=comparison[0]);w.writeheader();w.writerows(comparison)
probe=json.loads((scratch/'results-quiet.json').read_text())
text=f'''# Run {run}

Published report revision: `{publication}`.
Measured source revision: `{r['machine']['repository']['revision']}`.

This local-profile run measures ordinary row-batch threading in idiomatic
spectral-norm. Counter objects remain a rejected source experiment; the
k-nucleotide entry retains its previous numeric Map values. All 76 official
fixture and local-output checks pass. Sixteen fresh-process samples per program
yield 1,216 observations. The common chart cohort remains nine problems across
all eight columns. Java includes fresh-JVM startup and JIT compilation.
Canonical-size timing remains unrun.

Timing began after six consecutive ten-second observations at least 90 percent
CPU idle. This establishes the pre-run window, not zero background activity
throughout timing. Exact samples, build/check receipts, source hashes, manifest,
baseline, and quiet evidence are retained in `raw/`, `benchmarks.json`, and
`baseline.json.gz`. Native executables and external toolchains are not archived.
The parent [recovery guide](../../README.md) describes rebuilding sources and
rendering saved results without the original checkout or temporary directories.

## Separate full-run comparison

Comparison with `{oldrun}` uses median elapsed milliseconds. These are separate
full runs, not an alternating causal experiment; C reference drift is shown.

| Workload | Previous idiomatic ms | New idiomatic ms | C before ms | C after ms | Before/C | After/C |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for name in ('spectralnorm','knucleotide'):
 a=old['benchmarks'][name];b=r['benchmarks'][name]
 text+=f"| {name} | {a['idiomatic']['statistics']['median_elapsed_ns']/1e6:.3f} | {b['idiomatic']['statistics']['median_elapsed_ns']/1e6:.3f} | {a['references']['c']['statistics']['median_elapsed_ns']/1e6:.3f} | {b['references']['c']['statistics']['median_elapsed_ns']/1e6:.3f} | {a['factors']['time_idiomatic_over_c']:.2f} | {b['factors']['time_idiomatic_over_c']:.2f} |\n"
text+='''
The spectral entry uses ordinary Array vectors and Rows objects. Six ordinary
Threads calculate disjoint output row blocks at N>=256. The caller joins every
worker before the next matrix product. Each row retains its original summation
order. Below N=256, the same row calculation runs serially to avoid thread
startup overhead. Tuned spectral-norm retains its existing serial typed Arrays.
There is no custom allocator, raw collection storage, or runtime/compiler edit.
Earlier serial sources and complete runs remain immutable in the prior archive.

## Quiet paired source experiments

Each size uses sixteen alternating fresh-process pairs with one warmup per
program. The probe sources, compiler/runtime/binary hashes, all 224 samples,
input/oracle outputs, build recipes, and quiet observations are retained in
`../../evidence/counter-spectral/`. Active-desktop observations remain separate.

| Experiment | Input N | Before elapsed ms | Candidate elapsed ms | Before CPU ms | Candidate CPU ms | Candidate wins / 16 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for v in probe['summaries']:
 before,after=('knucleotide-before','knucleotide-counter') if v['problem']=='knucleotide' else ('spectralnorm-before','spectralnorm-parallel')
 a=v[before];b=v[after];text+=f"| {v['problem']} | {v['n']} | {a['median_elapsed_ms']:.3f} | {b['median_elapsed_ms']:.3f} | {a['median_cpu_ms']:.3f} | {b['median_cpu_ms']:.3f} | {v['wins']} |\n"
text+='''
The Counter implementation preserves growing hash tables and output ordering.
Its additional object per distinct key did not establish a repeatable overall
benefit, so it was not adopted. This rejects this implementation, not all
possible Map improvements. The earlier rejected `counts[key] += 1` experiment
also remains preserved.

`charts/` retains all three eight-column chart forms and a focused source-probe
comparison in PNG/SVG/PDF, with CSV, renderers and provenance. `website.json` is
the portable public export; path-bearing raw receipts remain audit materials.
The previous binary-trees serial/parallel comparison is retained in run
`20261031T145604Z`; it is not relabeled as a new measurement here.
'''
(p/'README.md').write_text(text);(charts/'README.md').write_text(text.replace('(../../README.md)','(../../../README.md)').replace('`../../evidence/counter-spectral/`','`../../../evidence/counter-spectral/`'))
web={'schema':1,'run_id':run,'publication_revision':publication,'measured_revision':r['machine']['repository']['revision'],'measured_tree_dirty':False,'profile':r['profile'],'cpu_model':r['machine'].get('cpu_model'),'samples':16,'process_warmups':r['warmups'],'implementations':r['implementations'],'summary_benchmarks':r['summary_benchmarks'],'java_process_model':'fresh JVM per sample; startup and JIT included','execution_modes':'mixed serial/parallel contributions; both x2c binary-trees entries parallel; idiomatic spectral-norm parallel at N>=256','historical_source_metric_issue':False,'measurements':list(csv.DictReader((charts/'measurements.csv').open()))};dump(p/'website.json',web)
idx=json.loads((root/'runs/index.json').read_text());idx['current_run']=run;idx['runs'].append({'run_id':run,'path':run,'publication_revision':publication,'measured_revision':web['measured_revision'],'implementations':r['implementations'],'summary_problem_count':9,'sample_recovery':'original full calibration JSONL and receipts, compressed without changing bytes','historical_source_metric_issue':False});dump(root/'runs/index.json',idx)
f=root/'README.md';s=f.read_text();a=s.index('The current public candidate');b=s.index('## Saved runs');when=datetime.fromisoformat(r['machine']['captured_at_utc'].replace('Z','+00:00'));local=when.astimezone(ZoneInfo('America/Los_Angeles'))
s=s[:a]+f'''The current public candidate is [run {run}](runs/{run}/README.md),
measured from clean source revision `{web['measured_revision']}` and first
published with results in `{publication}`. Run identifiers use UTC.
Observation time: {local.strftime('%Y-%m-%d %H:%M %Z')} / {when.strftime('%Y-%m-%d %H:%M UTC')}.

It covers 76 programs, eight columns, and sixteen fresh-process samples per
program (1,216 observations). All official fixtures and local-profile output
checks passed. Summary charts use the nine problems shared by all columns.
The four available k-nucleotide programs remain in per-problem tables.

'''+s[b:]
s=s.replace('Latest: fannkuch, FASTA, and parallel trees','Fannkuch, FASTA, and parallel trees').replace('\n[runs/index.json]',f'| [{run}](runs/{run}/README.md) | 8 | 9 | Latest: parallel spectral-norm; Counter probe rejected |\n\n[runs/index.json]')
s=s.replace('gzip -dc runs/'+oldrun,'gzip -dc runs/'+run).replace('git worktree add --detach /tmp/x2c-shootout-source 9d070d9a0cf2c13dbebf339f4c708fcbd7354439','git worktree add --detach /tmp/x2c-shootout-source '+publication)
s=s.replace('runs/'+oldrun+'/charts/render.py examples/shootout/results/runs/'+oldrun+'/current.json','runs/'+run+'/charts/render.py examples/shootout/results/runs/'+run+'/current.json')
s=s.replace('The latest run adds a\nsame-compiler comparison of serial and six-worker elapsed and total CPU time.', 'Run `20261031T145604Z` retains its same-compiler serial/six-worker elapsed and\ntotal CPU comparison.')
s=s.replace('The renderer creates its output directory.',f'''To render the latest source-probe chart:

```sh
/tmp/x2c-shootout-charts/bin/python examples/shootout/results/runs/{run}/charts/render-probes.py examples/shootout/results/evidence/counter-spectral/results-quiet.json.gz /tmp/x2c-shootout-figures
```

The renderer creates its output directory.''');f.write_text(s)
f=repo/'site/BENCHMARKS.md';s=f.read_text().replace(oldrun,run).replace('2026-10-31 07:56 PDT / 2026-10-31 14:56 UTC',local.strftime('%Y-%m-%d %H:%M %Z')+' / '+when.strftime('%Y-%m-%d %H:%M UTC'))
s=s.replace('The latest charts also include `binarytrees-serial-parallel` in PNG/SVG/PDF and\nCSV, with a separate renderer/provenance file. Use this focused elapsed/CPU\ncomparison to explain the change. Retain the earlier serial chart sets.',f'''The latest run adds `counter-spectral-probes` in PNG/SVG/PDF and CSV, with a
separate renderer and provenance. Counter objects are a rejected experiment,
not an additional column. Idiomatic spectral-norm uses six worker row batches
at N>=256 and a serial path below that size. Tuned spectral-norm remains serial.
The earlier binary-trees focused comparison remains in run `{oldrun}`.
Retain those serial/parallel source and chart sets.''');f.write_text(s)
f=root/'threading.md';s=f.read_text().replace('The\nlatest run adds sixteen alternating same-compiler serial/parallel pairs at','Run `20261031T145604Z` adds sixteen alternating same-compiler serial/parallel pairs at').replace('the same ordinary threading code here. Other workloads retain their previous\nexecution strategies.','the same ordinary threading code here. Idiomatic spectral-norm also uses\nthreads as described below; other workloads retain their execution strategies.');f.write_text(s)
with (root/'threading.md').open('a') as f:f.write('''
## Ordinary parallel spectral-norm

The idiomatic entry uses six ordinary Threads for disjoint output row blocks
at N>=256. Ordinary Arrays hold all vectors; their lengths remain fixed during
worker execution. Workers read one input vector and write distinct existing
output elements. Each row retains the original j-order and double accumulation.
The coordinator joins every worker before the next matrix product reads the
output. Per-product Rows objects remain alive through join. Small inputs use
the same calculation serially. Tuned spectral-norm remains its serial typed-Array
implementation. This is a change in execution mode, not a single-core speedup.
''')
rows=[]
for name,v in r['benchmarks'].items():
 a=v['idiomatic']['statistics']['median_elapsed_ns']/1e6;c=v['references']['c']['statistics']['median_elapsed_ns']/1e6;t=v['tuned']['statistics']['median_elapsed_ns']/1e6;rows.append((a-c,name,a,c,t,a/c))
s=f'''# Remaining idiomatic x2c performance gaps

Current run `{run}`, local profile, measured source
`{web['measured_revision']}` on Apple M4 Max. Values are sixteen-sample median
elapsed milliseconds. These selected-program differences do not isolate
language, allocation, or threading overhead. Rows rank absolute excess over C.

| Workload | Idiomatic ms | C ms | Tuned ms | Idiomatic/C | Excess over C ms |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
for gap,name,a,c,t,ratio in sorted(rows,reverse=True):s+=f'| {name} | {a:.3f} | {c:.3f} | {t:.3f} | {ratio:.2f} | {gap:.3f} |\n'
s+=f'''
## Adopted and rejected experiments

Idiomatic spectral-norm now uses six ordinary row workers at N>=256 and a
serial path for smaller inputs. Its Array representation and each row's
summation order remain unchanged. The previous serial source and full charts
remain in [run {oldrun}](runs/{oldrun}/README.md). Tuned spectral-norm stays serial.

The ordinary Counter-object Map implementation did not demonstrate a repeatable
overall gain across the tested k-nucleotide inputs. Keep numeric Map values.
The source, successful correctness checks, active-desktop results, and quiet
paired samples remain preserved in [this run](runs/{run}/README.md). This rejects
that implementation rather than all possible Counter or Map improvements.
The earlier `counts[key] += 1` substitution also regressed and remains rejected.

K-nucleotide allocation, short String keys, hashing, and value conversions still
need profiling. N-body and fannkuch retain collection-access and conversion
cost candidates without another demonstrated idiomatic source fix. Parallel
spectral-norm changes elapsed time and CPU consumption; it does not establish a
single-core improvement. No typed containers, SubStrings, raw storage, custom
allocators, or compiler/runtime edits were introduced by this source change.

Earlier Node, reverse-complement Buffer, n-body pair, fannkuch bulk copy, FASTA
Choice records/Buffer, regex JIT, and parallel tree changes remain applied.
All earlier immutable reports and rejected probes remain recoverable. Java
includes startup/JIT. Canonical-size timing remains unrun.
''';(root/'remaining-gaps.md').write_text(s)
with (root/'evidence/README.md').open('a') as f:f.write(f'''\n## Counter objects and parallel spectral-norm\n\n`counter-spectral/` retains both baseline/candidate sources, independent\nk-nucleotide input/output oracles, C spectral parity checks, initial and\ncutoff probes, quiet paired samples, build/source/binary hashes, and scripts.\nThe Counter experiment was not adopted; the spectral row-batch implementation\nwas adopted. Full calibration is [run {run}](../runs/{run}/README.md).\n''')
paths=sorted([q for parent in (root/'runs',root/'evidence') for q in parent.rglob('*') if q.is_file()]+[root/'requirements-charts.txt'])
(root/'SHA256SUMS').write_text(''.join(sha(q)+'  '+str(q.relative_to(root))+'\n' for q in paths));print('Preserved',run,'files',len(paths))
