"""Preserve a completed calibration and both bounded source experiments."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import csv,gzip,hashlib,json,shutil,subprocess,sys
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout/results';scratch=Path(__file__).resolve().parent
oldrun='20261031T161720Z';publication=subprocess.check_output(['git','rev-parse',sys.argv[1]],cwd=repo,text=True).strip()
r=json.loads((root/'current.json').read_text());run=r['run_id'];decision=json.loads((scratch/'decisions.json').read_text())
assert run!=oldrun and r['samples']==16 and len(r['implementations'])==8 and len(r['summary_benchmarks'])==9 and not r['machine']['repository']['dirty']
assert subprocess.check_output(['git','show',publication+':examples/shootout/results/current.json'],cwd=repo)==(root/'current.json').read_bytes()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def zipped(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(b,mtime=0))
build=repo/'examples/build/shootout';assert len((build/'calibration-raw.jsonl').read_bytes().splitlines())==1216
assert json.loads((build/'latest/receipt.json').read_text())['run_id']==run
for name,e in r['benchmarks'].items():
 programs={k:e[k] for k in ('idiomatic','tuned')};programs.update(e['references'])
 for k,v in programs.items():assert sha(repo/'examples/shootout'/v['source']['path'])==v['source']['sha256']
p=root/'runs'/run;p.mkdir(exist_ok=False)
for name in ('current.json','current.md'):(p/name).write_bytes((root/name).read_bytes())
zipped(p/'baseline.json.gz',(repo/'examples/shootout/baseline.json').read_bytes());shutil.copyfile(repo/'examples/shootout/benchmarks.json',p/'benchmarks.json')
for f in [build/'calibration-raw.jsonl',*(build/'latest'/n for n in ('build.json','check.json','receipt.json','summary.json','summary.md')),repo/'debug/bound-fann-calibration.log',repo/'debug/bound-fann-quiet-window.jsonl',scratch/'quiet-run.py']:
 zipped(p/'raw'/(f.name+'.gz'),f.read_bytes())
charts=p/'charts';charts.mkdir();renderer=(root/'runs'/oldrun/'charts/render.py').read_text()
if decision['adopt_parallel_fann']:
 renderer=renderer.replace('Mixed serial/parallel programs; idiomatic x2c uses threads for trees and spectral-norm.','Mixed serial/parallel programs; idiomatic x2c uses ordinary threads in three workloads.')
 renderer=renderer.replace('idiomatic spectral-norm parallel at N>=256','idiomatic spectral-norm parallel at N>=256; idiomatic fannkuch parallel at N>=9')
(charts/'render.py').write_text(renderer)
python='/Users/gary/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
subprocess.run([python,str(charts/'render.py'),str(p/'current.json'),str(charts)],check=True)
e=root/'evidence/bound-fann';e.mkdir(exist_ok=False)
for f in sorted(scratch.iterdir()):
 if f.is_file() and f.suffix in ('.py','.x','.json'):zipped(e/(f.name+'.gz'),f.read_bytes())
# The input/oracle corpus is already versioned in counter-spectral/inputs.
for name in ('bound-fann-probe.log','bound-fann-quiet-probe.log','bound-fann-probe-quiet-window.jsonl','bound-fann-check.log'):
 zipped(e/(name+'.gz'),(repo/'debug'/name).read_bytes())
zipped(e/'changes.diff.gz',subprocess.check_output(['git','diff','ffd915bd0',r['machine']['repository']['revision'],'--','examples/shootout/benchmarks/fannkuchredux/main.x','examples/shootout/benchmarks/knucleotide/main.x'],cwd=repo))
shutil.copyfile(scratch/'render-probes.py',charts/'render-probes.py');subprocess.run([python,str(charts/'render-probes.py'),str(e/'results-quiet.json.gz'),str(charts)],check=True)
old=json.loads((root/'runs'/oldrun/'current.json').read_text());comparison=[]
for name in r['benchmark_order']:
 for variant in ('idiomatic','tuned'):
  a=old['benchmarks'][name];b=r['benchmarks'][name];comparison.append({'problem':name,'implementation':variant,'before_ms':a[variant]['statistics']['median_elapsed_ns']/1e6,'after_ms':b[variant]['statistics']['median_elapsed_ns']/1e6,'before_over_C':a['factors']['time_'+variant+'_over_c'],'after_over_C':b['factors']['time_'+variant+'_over_c']})
with (charts/'comparison.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=comparison[0]);w.writeheader();w.writerows(comparison)
probe=json.loads((scratch/'results-quiet.json').read_text());bound='adopted' if decision['adopt_loop_bound'] else 'rejected';fann='adopted' if decision['adopt_parallel_fann'] else 'rejected'
text=f'''# Run {run}

Published report revision: `{publication}`.
Measured source revision: `{r['machine']['repository']['revision']}`.

This run follows the cached k-nucleotide loop-bound and ordinary parallel
fannkuch-redux experiments. Loop-bound candidate: **{bound}**.
Parallel fannkuch candidate: **{fann}**. The decision record and all source
variants remain in the evidence directory, including rejected candidates.

All 76 official fixture and local-output checks pass. Sixteen fresh-process
samples per program yield 1,216 observations. The common chart cohort remains
nine problems across all eight columns. Java includes fresh-JVM startup and
JIT compilation. Canonical-size timing remains unrun.

Timing began after six consecutive ten-second observations at least 90 percent
CPU idle. This establishes the pre-run window, not zero background activity
throughout timing. Exact samples, build/check receipts, source hashes, manifest,
baseline, and quiet evidence remain in `raw/`, `benchmarks.json`, and
`baseline.json.gz`. Native executables and external toolchains are not archived.
The parent [recovery guide](../../README.md) describes rebuilding sources and
rendering saved results without the original checkout or temporary directories.

## Separate full-run comparison

Comparison with `{oldrun}` uses median elapsed milliseconds. These are separate
full runs, not an alternating causal experiment; C reference drift is shown.

| Workload | Previous idiomatic ms | New idiomatic ms | C before ms | C after ms | Before/C | After/C |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for name in ('fannkuchredux','knucleotide'):
 a=old['benchmarks'][name];b=r['benchmarks'][name]
 text+=f"| {name} | {a['idiomatic']['statistics']['median_elapsed_ns']/1e6:.3f} | {b['idiomatic']['statistics']['median_elapsed_ns']/1e6:.3f} | {a['references']['c']['statistics']['median_elapsed_ns']/1e6:.3f} | {b['references']['c']['statistics']['median_elapsed_ns']/1e6:.3f} | {a['factors']['time_idiomatic_over_c']:.2f} | {b['factors']['time_idiomatic_over_c']:.2f} |\n"
text+='''
## Quiet paired source experiments

Each size uses sixteen alternating fresh-process pairs with one warmup per
program. All 160 probe observations, original and candidate sources,
compiler/runtime/binary hashes, build recipes, and quiet observations are in
`../../evidence/bound-fann/`. The DNA input/oracle corpus is retained in
`../../evidence/counter-spectral/inputs/`. The portable probe script reads that
versioned corpus. Active-desktop observations are retained separately.

| Experiment | Input N | Before elapsed ms | Candidate elapsed ms | Before CPU ms | Candidate CPU ms | Candidate wins / 16 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for v in probe['summaries']:
 before,after=('knucleotide-before','knucleotide-bound') if v['problem']=='knucleotide' else ('fannkuchredux-before','fannkuchredux-parallel')
 a=v[before];b=v[after];text+=f"| {v['problem']} | {v['n']} | {a['median_elapsed_ms']:.3f} | {b['median_elapsed_ms']:.3f} | {a['median_cpu_ms']:.3f} | {b['median_cpu_ms']:.3f} | {v['wins']} |\n"
text+='''
The loop-bound candidate caches `sequence.len() - width` without changing the
Map values or growing hash tables. The fannkuch candidate gives each ordinary
Thread private Arrays and a contiguous global permutation range. Factorial
rotation digits initialize both the permutation and countdown state. Checksum
sign uses global rank parity. The caller joins workers before reading each
Chunk's scalar checksum/maximum. N<9 uses the same calculation serially.
Ranges use 64-bit long arithmetic, including N=12 partition products.

Fannkuch matches the baseline and contributed C at N=2 through N=10, with three
runs of each source per size. All 5,912 ranks and their next-step continuations
for N=2 through N=7 match an independent recursive permutation generator.
The unchanged tuned entry remains serial and uses its existing typed Arrays.
No custom allocator, raw collection storage, or compiler/runtime edit is part
of these benchmark changes. Earlier complete sources, reports, and charts
remain immutable in prior runs. This is a program-strategy comparison, not a
single-core language ranking.

`charts/` retains all three eight-column chart forms plus the focused probe
comparison in PNG/SVG/PDF, with CSV, renderers, and provenance. `website.json`
is the portable public export; path-bearing raw receipts remain audit materials.
'''
(p/'README.md').write_text(text);(charts/'README.md').write_text(text.replace('(../../README.md)','(../../../README.md)').replace('`../../evidence/','`../../../evidence/'))
mode='mixed serial/parallel programs; both x2c tree entries parallel; idiomatic spectral-norm parallel at N>=256'
if decision['adopt_parallel_fann']:mode+='; idiomatic fannkuch parallel at N>=9'
web={'schema':1,'run_id':run,'publication_revision':publication,'measured_revision':r['machine']['repository']['revision'],'measured_tree_dirty':False,'profile':r['profile'],'cpu_model':r['machine'].get('cpu_model'),'samples':16,'process_warmups':r['warmups'],'implementations':r['implementations'],'summary_benchmarks':r['summary_benchmarks'],'java_process_model':'fresh JVM per sample; startup and JIT included','execution_modes':mode,'historical_source_metric_issue':False,'measurements':list(csv.DictReader((charts/'measurements.csv').open()))};dump(p/'website.json',web)
idx=json.loads((root/'runs/index.json').read_text());idx['current_run']=run;idx['runs'].append({'run_id':run,'path':run,'publication_revision':publication,'measured_revision':web['measured_revision'],'implementations':r['implementations'],'summary_problem_count':9,'sample_recovery':'original full calibration JSONL and receipts, compressed without changing bytes','historical_source_metric_issue':False});dump(root/'runs/index.json',idx)
f=root/'README.md';s=f.read_text();a=s.index('The current public candidate');b=s.index('## Saved runs');when=datetime.fromisoformat(r['machine']['captured_at_utc'].replace('Z','+00:00'));local=when.astimezone(ZoneInfo('America/Los_Angeles'))
s=s[:a]+f'''The current public candidate is [run {run}](runs/{run}/README.md),
measured from clean source revision `{web['measured_revision']}` and first
published with results in `{publication}`. Run identifiers use UTC.
Observation time: {local.strftime('%Y-%m-%d %H:%M %Z')} / {when.strftime('%Y-%m-%d %H:%M UTC')}.

It covers 76 programs, eight columns, and sixteen fresh-process samples per
program (1,216 observations). All official fixtures and local-profile output
checks passed. Summary charts use the nine problems shared by all columns.
The four available k-nucleotide programs remain in per-problem tables.

'''+s[b:]
s=s.replace('Latest: parallel spectral-norm; Counter probe rejected','Parallel spectral-norm; Counter probe rejected').replace('\n[runs/index.json]',f'| [{run}](runs/{run}/README.md) | 8 | 9 | Latest: parallel fannkuch {fann}; loop-bound {bound} |\n\n[runs/index.json]')
s=s.replace('gzip -dc runs/'+oldrun,'gzip -dc runs/'+run).replace('git worktree add --detach /tmp/x2c-shootout-source d30286d20c4cd89c65d5d68f1bff8efe639e53df','git worktree add --detach /tmp/x2c-shootout-source '+publication)
s=s.replace('runs/'+oldrun+'/charts/render.py examples/shootout/results/runs/'+oldrun+'/current.json','runs/'+run+'/charts/render.py examples/shootout/results/runs/'+run+'/current.json').replace('To render the latest source-probe chart:','To render the earlier Counter/spectral source-probe chart:')
s=s.replace('The renderer creates its output directory.',f'''To render the latest loop-bound/fannkuch source-probe chart:

```sh
/tmp/x2c-shootout-charts/bin/python examples/shootout/results/runs/{run}/charts/render-probes.py examples/shootout/results/evidence/bound-fann/results-quiet.json.gz /tmp/x2c-shootout-figures
```

The renderer creates its output directory.''');f.write_text(s)
f=repo/'site/BENCHMARKS.md';s=f.read_text().replace(oldrun,run).replace('2026-10-31 09:17 PDT / 2026-10-31 16:17 UTC',local.strftime('%Y-%m-%d %H:%M %Z')+' / '+when.strftime('%Y-%m-%d %H:%M UTC'))
a=s.index('The latest run adds `counter-spectral-probes`');s=s[:a]+f'''The latest run adds `bound-fann-probes` in PNG/SVG/PDF and CSV, with its
renderer and provenance. Loop-bound candidate: {bound}; parallel fannkuch:
{fann}. State the serial cutoff N<9 and unchanged tuned fannkuch strategy.
The earlier Counter/spectral experiment remains in run `{oldrun}`;
the tree serial/parallel experiment remains in run `20261031T145604Z`.
Keep those historical comparisons labeled with their actual runs.
''';f.write_text(s)
if decision['adopt_parallel_fann']:
 with (root/'threading.md').open('a') as f:f.write('''
## Ordinary parallel fannkuch-redux

The idiomatic entry uses six ordinary Threads at N>=9. Each Chunk record holds
its size, global first/last permutation ranks, scalar checksum/maximum, and
Thread handle. Each worker owns its permutation, working, and countdown Arrays.
The starting state is derived from factorial rotation digits. Global rank
parity determines checksum signs; chunk sums and maxima combine after joining.
The ranges partition [0,n!) and use 64-bit arithmetic for partition products.
N<9 runs the same calculation serially. Tuned fannkuch retains its serial
implementation. Parallel execution is described by the pinned official spec.
''')
rows=[]
for name,v in r['benchmarks'].items():
 a=v['idiomatic']['statistics']['median_elapsed_ns']/1e6;c=v['references']['c']['statistics']['median_elapsed_ns']/1e6;t=v['tuned']['statistics']['median_elapsed_ns']/1e6;rows.append((a-c,name,a,c,t,a/c))
s=f'''# Remaining idiomatic x2c performance gaps

Current run `{run}`, local profile, measured source
`{web['measured_revision']}` on Apple M4 Max. Values are sixteen-sample median
elapsed milliseconds. Selected-program differences do not isolate language,
allocation, or threading overhead. Rows rank absolute excess over C; negative
excess means the selected x2c program ran faster than the selected C program.

| Workload | Idiomatic ms | C ms | Tuned ms | Idiomatic/C | Excess over C ms |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
for gap,name,a,c,t,ratio in sorted(rows,reverse=True):s+=f'| {name} | {a:.3f} | {c:.3f} | {t:.3f} | {ratio:.2f} | {gap:.3f} |\n'
s+=f'''
## Latest experiments

Parallel fannkuch: **{fann}**. Cached k-nucleotide loop bound: **{bound}**.
[Run {run}](runs/{run}/README.md) preserves the exact decisions, paired elapsed
and CPU measurements, full-run C drift, candidate sources, and correctness
checks. The earlier serial fannkuch source and all prior charts remain intact.
No typed containers, raw collection storage, custom allocators, or runtime or
compiler changes were introduced by these benchmark changes.

Counter objects and `counts[key] += 1` remain rejected k-nucleotide experiments.
Their failure does not rule out all Map or representation improvements.
K-nucleotide slicing, canonical String storage, hashing, and value conversions
still need profiling. N-body has no further demonstrated idiomatic source fix.
A regex count-only API is a possible adapter improvement, not an implemented
benchmark change. Parallel strategies affect elapsed time and CPU consumption;
these comparisons do not establish single-core language performance.

Earlier Node, Buffer, pair precomputation, bulk copy, Choice records, regex JIT,
and parallel tree/spectral changes remain applied. Java includes startup/JIT.
Canonical-size timing remains unrun.
''';(root/'remaining-gaps.md').write_text(s)
with (root/'evidence/README.md').open('a') as f:f.write(f'''\n## Cached loop bounds and parallel fannkuch\n\n`bound-fann/` retains baseline/candidate sources, the original and portable\nprobe scripts, 5,912 permutation-rank/continuation checks, C output parity,\ninitial and quiet paired samples, build/source/binary hashes, decisions, and\nquiet observations. The unchanged DNA oracle corpus is in\n`counter-spectral/inputs/`. Full calibration is [run {run}](../runs/{run}/README.md).\n''')
paths=sorted([q for parent in (root/'runs',root/'evidence') for q in parent.rglob('*') if q.is_file()]+[root/'requirements-charts.txt'])
(root/'SHA256SUMS').write_text(''.join(sha(q)+'  '+str(q.relative_to(root))+'\n' for q in paths));print('Preserved',run,'files',len(paths))
