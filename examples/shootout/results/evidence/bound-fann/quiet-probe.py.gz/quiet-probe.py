"""Confirm both source experiments in a recorded quiet window."""
from pathlib import Path
import datetime,hashlib,json,os,re,statistics,subprocess,time
root=Path(__file__).resolve().parent;repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');obs=repo/'debug/bound-fann-probe-quiet-window.jsonl'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Bind measured binaries and sources to the completed correctness/build probe.
probed=json.loads((root/'results-initial.json').read_text())
assert probed['compiler_sha256']==sha(repo/'builds/0/x2c') and probed['runtime_sha256']==sha(repo/'builds/0/libx2c.a')
for name in ('knucleotide-before.x','knucleotide-bound.x','fannkuchredux-before.x','fannkuchredux-parallel.x'):assert sha(root/name)==probed['source_sha256'][name]
consecutive=[]
with obs.open('w') as log:
 while len(consecutive)<6:
  p=subprocess.run(['top','-l','2','-s','10','-n','0'],capture_output=True,text=True,check=True)
  idle=float(re.findall(r'([\d.]+)% idle',p.stdout)[-1]);v={'captured_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'idle_percent':idle};log.write(json.dumps(v)+'\n');log.flush()
  if idle>=90:consecutive.append(v)
  else:consecutive=[]
  print(f'quiet probe window: {idle:.2f}% idle; {len(consecutive)}/6',flush=True)
raw=[];summaries=[];env=dict(os.environ,LC_ALL='C',TZ='UTC')
for problem,sizes,before,after in [('knucleotide',(20000,100000),'knucleotide-before','knucleotide-bound'),('fannkuchredux',(7,9,10),'fannkuchredux-before','fannkuchredux-parallel')]:
 for n in sizes:
  args=[] if problem=='knucleotide' else [str(n)];data=(root/'inputs'/(str(n)+'.fasta')).read_bytes() if problem=='knucleotide' else None
  for name in (before,after):subprocess.run([root/name/'program',*args],input=data,stdout=subprocess.DEVNULL,check=True,env=env)
  for sample in range(16):
   for name in ((before,after) if sample%2==0 else (after,before)):
    v=json.loads(subprocess.check_output([root/'measure',root/name/'program',*args],input=data,env=env));assert v['exit_code']==0 and v['signal']==0;v.update(problem=problem,n=n,sample=sample+1,implementation=name);raw.append(v)
  vals={name:{'median_elapsed_ms':statistics.median(v['elapsed_ns'] for v in raw if v['problem']==problem and v['n']==n and v['implementation']==name)/1e6,'median_cpu_ms':statistics.median(v['user_ns']+v['system_ns'] for v in raw if v['problem']==problem and v['n']==n and v['implementation']==name)/1e6} for name in (before,after)}
  vals.update(problem=problem,n=n,wins=sum(next(v['elapsed_ns'] for v in raw if v['problem']==problem and v['n']==n and v['implementation']==after and v['sample']==s)<next(v['elapsed_ns'] for v in raw if v['problem']==problem and v['n']==n and v['implementation']==before and v['sample']==s) for s in range(1,17)))
  summaries.append(vals);print(json.dumps(vals),flush=True)
r={'schema':1,'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'samples':16,'warmups':1,'quiet_window':consecutive,'raw':raw,'summaries':summaries,'compiler_sha256':sha(repo/'builds/0/x2c'),'runtime_sha256':sha(root/'libx2c.a'),'source_sha256':{n:sha(root/n) for n in ('knucleotide-before.x','knucleotide-bound.x','fannkuchredux-before.x','fannkuchredux-parallel.x')},'program_sha256':{n:sha(root/n/'program') for n in ('knucleotide-before','knucleotide-bound','fannkuchredux-before','fannkuchredux-parallel')},'limit':'Pre-run quiet window; zero background activity throughout measurement is not established. Not canonical-size timing.'}
(root/'results-quiet.json').write_text(json.dumps(r,indent=2)+'\n')
