from pathlib import Path
import hashlib,json,math,os,shutil,statistics,subprocess
root=Path(__file__).resolve().parent;repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copyfile(repo/'builds/0/libx2c.a',root/'libx2c.a');commands=[]
def call(args,**kw):
 args=[str(a) for a in args];commands.append(args);return subprocess.run(args,check=True,**kw)
def build(name):
 out=root/name;out.mkdir(exist_ok=True)
 call([repo/'builds/0/x2c','translate','--out-dir',out,root/(name+'.x')],capture_output=True)
 call(['/usr/bin/cc','-O2','-DNDEBUG','-I/opt/homebrew/include','-iquote',repo/'include/x2c',out/(name+'.c'),'-L',root,'-lx2c','-lm','-L/opt/homebrew/lib','-o',out/'program'],capture_output=True)
for name in ('knucleotide-before','knucleotide-bound','fannkuchredux-before','fannkuchredux-parallel'):build(name)
call(['/usr/bin/cc','-O2',repo/'examples/shootout/benchmarks/fannkuchredux/main.c','-o',root/'fann-c'])
call(['/usr/bin/cc','-O2',repo/'examples/shootout/tools/measure.c','-o',root/'measure'])
checks=[]
# Reuse the independent DNA oracle corpus preserved by the previous experiment.
inputs=root/'inputs';inputs.mkdir(exist_ok=True)
for p in (Path('/tmp/x2c-counter-spectral')/'inputs').iterdir():shutil.copyfile(p,inputs/p.name)
for p in sorted(inputs.glob('*.fasta')):
 want=p.with_suffix('.out').read_bytes()
 for variant in ('knucleotide-before','knucleotide-bound'):assert subprocess.check_output([root/variant/'program'],input=p.read_bytes())==want,(p.name,variant)
 checks.append({'problem':'knucleotide','input':p.name,'sha256':hashlib.sha256(want).hexdigest()})
for n in range(2,11):
 want=subprocess.check_output([root/'fann-c',str(n)])
 for variant in ('fannkuchredux-before','fannkuchredux-parallel'):
  for repeat in range(3):assert subprocess.check_output([root/variant/'program',str(n)])==want,(n,variant)
 checks.append({'problem':'fannkuchredux','n':n,'repeats_per_variant':3,'sha256':hashlib.sha256(want).hexdigest()})
# Compare every seek result and its next-step continuation with a recursive
# serial permutation generator from the official prefix-rotation description.
s=(root/'fannkuchredux-parallel.x').read_text();needle='int main(int argc, char **argv)';assert s.count(needle)==1;s=s.replace(needle,'static int benchmark_main(int argc, char **argv)',1)
s+='''
int main(int argc, char **argv) {
  int n = atoi(argv[1]);
  long total = 1;
  for (int i = 2; i <= n; i++) total *= i;
  for (long rank = 0; rank < total; rank++) auto {
    Array permutation = [], counts = [];
    for (int i = 0; i < n; i++) {
      permutation.push(i);
      counts.push(i + 1);
    }
    _seek(permutation, counts, n, rank);
    for (int i = 0; i < n; i++) printf("%d", permutation[i]);
    printf(" ");
    int next = _advance(permutation, counts, n);
    printf("%d ", next);
    for (int i = 0; i < n; i++) printf("%d", permutation[i]);
    puts("");
  }
  return 0;
}
''';(root/'seek-check.x').write_text(s);build('seek-check')
def permutations(items,n):
 if n==1:yield ''.join(map(str,items));return
 for step in range(n):
  yield from permutations(items,n-1)
  items[:n]=items[1:n]+items[:1]
for n in range(2,8):
 order=list(permutations(list(range(n)),n));out=subprocess.check_output([root/'seek-check/program',str(n)],text=True).splitlines();assert len(out)==len(order)==math.factorial(n)
 for rank,line in enumerate(out):
  perm,hasnext,nxt=line.split();assert perm==order[rank],(n,rank)
  assert int(hasnext)==(rank+1<len(order))
  if rank+1<len(order):assert nxt==order[rank+1],(n,rank,'next')
 checks.append({'problem':'fannkuch-seek','n':n,'all_ranks_and_continuations':len(order)})
print('all correctness checks passed',flush=True)
raw=[];summaries=[];env=dict(os.environ,LC_ALL='C',TZ='UTC')
for problem,sizes,before,after in [('knucleotide',(20000,100000),'knucleotide-before','knucleotide-bound'),('fannkuchredux',(7,9,10),'fannkuchredux-before','fannkuchredux-parallel')]:
 for n in sizes:
  data=(inputs/(str(n)+'.fasta')).read_bytes() if problem=='knucleotide' else None;args=[] if problem=='knucleotide' else [str(n)]
  for name in (before,after):subprocess.run([root/name/'program',*args],input=data,stdout=subprocess.DEVNULL,check=True,env=env)
  for sample in range(12):
   for name in ((before,after) if sample%2==0 else (after,before)):
    v=json.loads(subprocess.check_output([root/'measure',root/name/'program',*args],input=data,env=env));assert v['exit_code']==0 and v['signal']==0;v.update(problem=problem,n=n,sample=sample+1,implementation=name);raw.append(v)
  vals={name:statistics.median(v['elapsed_ns'] for v in raw if v['problem']==problem and v['n']==n and v['implementation']==name)/1e6 for name in (before,after)}
  vals.update(problem=problem,n=n,wins=sum(next(v['elapsed_ns'] for v in raw if v['problem']==problem and v['n']==n and v['implementation']==after and v['sample']==sample)<next(v['elapsed_ns'] for v in raw if v['problem']==problem and v['n']==n and v['implementation']==before and v['sample']==sample) for sample in range(1,13)));summaries.append(vals);print(json.dumps(vals),flush=True)
r={'schema':1,'checks':checks,'raw':raw,'summaries':summaries,'compiler_sha256':sha(repo/'builds/0/x2c'),'runtime_sha256':sha(root/'libx2c.a'),'source_sha256':{p.name:sha(p) for p in root.glob('*.x')},'program_sha256':{name:sha(root/name/'program') for name in ('knucleotide-before','knucleotide-bound','fannkuchredux-before','fannkuchredux-parallel')},'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'commands':commands,'limit':'Alternating active-desktop probe; quiet confirmation follows for adoption.'}
(root/'results-initial.json').write_text(json.dumps(r,indent=2)+'\n')
