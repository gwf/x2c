from pathlib import Path
import collections,csv,gzip,hashlib,json,re,subprocess,sys
repo=Path('/Users/gary/.codex/worktrees/f2bc/x2c');root=repo/'examples/shootout/results';idx=json.loads((root/'runs/index.json').read_text());run=root/'runs'/idx['current_run'];sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((run/'current.json').read_text());assert (root/'current.json').read_bytes()==(run/'current.json').read_bytes()
assert r['samples']==16 and len(r['implementations'])==8 and len(r['summary_benchmarks'])==9 and not r['machine']['repository']['dirty']
q=r['machine']['quiet_window']['samples'];assert len(q)==6 and all(v['idle_percent']>=90 for v in q)
raw=[json.loads(l) for l in gzip.decompress((run/'raw/calibration-raw.jsonl.gz').read_bytes()).splitlines()];assert len(raw)==1216
counts=collections.Counter((v['benchmark'],v['implementation']) for v in raw);assert len(counts)==76 and set(counts.values())=={16}
assert all(v['exit_code']==0 and v['signal']==0 and v['run_id']==r['run_id'] for v in raw)
checks=json.loads(gzip.decompress((run/'raw/check.json.gz').read_bytes()));assert len(checks['checks'])==76
for name,e in r['benchmarks'].items():
 programs={k:e[k] for k in ('idiomatic','tuned')};programs.update(e['references'])
 for k,v in programs.items():
  p=repo/'examples/shootout'/v['source']['path'];assert sha(p.read_bytes())==v['source']['sha256']
  assert sha(subprocess.check_output(['git','show',r['machine']['repository']['revision']+':'+str(p.relative_to(repo))],cwd=repo))==v['source']['sha256']
assert set(r['benchmarks']['knucleotide']['unavailable'])=={'rust','cpp','go','java'}
assert json.loads((run/'charts/provenance.json').read_text())['report_sha256']==sha((run/'current.json').read_bytes())
sys.path.insert(0,str(repo/'examples/shootout/tools'));import shootout
assert shootout.value_sha256(json.loads(gzip.decompress((run/'baseline.json.gz').read_bytes())))==r['baseline_sha256']
rows=list(csv.DictReader((run/'charts/measurements.csv').open()));assert len(rows)==76
for row in rows:
 e=r['benchmarks'][row['problem']];p=e[row['implementation']] if row['implementation'] in ('idiomatic','tuned') else e['references'][row['implementation']]
 if 'time_ms' in row:assert abs(float(row['time_ms'])-p['statistics']['median_elapsed_ns']/1e6)<1e-8
probe=json.loads(gzip.decompress((root/'evidence/bound-fann/results-quiet.json.gz').read_bytes()));assert len(probe['raw'])==160 and len(probe['quiet_window'])==6 and all(v['idle_percent']>=90 for v in probe['quiet_window'])
assert sha((repo/'examples/shootout/benchmarks/knucleotide/main.x').read_bytes())==probe['source_sha256']['knucleotide-bound.x']
assert sha((repo/'examples/shootout/benchmarks/fannkuchredux/main.x').read_bytes())==probe['source_sha256']['fannkuchredux-parallel.x']
assert all(v['exit_code']==0 and v['signal']==0 for v in probe['raw'])
assert set(collections.Counter((v['problem'],v['n'],v['implementation']) for v in probe['raw']).values())=={16}
old=subprocess.check_output(['git','show','ffd915bd0:examples/shootout/results/SHA256SUMS'],cwd=repo,text=True);unchanged=0
for line in old.splitlines():
 digest,path=line.split('  ',1)
 if path.startswith('runs/') and path!='runs/index.json':assert sha((root/path).read_bytes())==digest;unchanged+=1
parsed=0
for p in [*run.rglob('*'),*(root/'evidence/bound-fann').rglob('*')]:
 if not p.is_file():continue
 if p.suffix=='.gz':
  data=gzip.decompress(p.read_bytes())
  if p.name.endswith('.json.gz'):json.loads(data);parsed+=1
  if p.name.endswith('.jsonl.gz'):
   for line in data.splitlines():json.loads(line)
   parsed+=1
 elif p.suffix=='.json':json.loads(p.read_text());parsed+=1
for p in [root/'README.md',root/'threading.md',root/'remaining-gaps.md',run/'README.md',run/'charts/README.md',repo/'site/BENCHMARKS.md']:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if not target.startswith(('https:','http:','#')):assert (p.parent/target.split('#')[0]).exists(),(p,target)
paths=sorted([q for parent in (root/'runs',root/'evidence') for q in parent.rglob('*') if q.is_file()]+[root/'requirements-charts.txt'])
(root/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+str(p.relative_to(root))+'\n' for p in paths))
print(json.dumps({'official_checks':76,'programs':76,'samples_per_program':16,'full_observations':1216,'columns':8,'common_problems':9,'quiet_probe_observations':160,'prior_immutable_run_files_unchanged':unchanged,'parsed_json_files':parsed,'checksummed_files_before_recording_verification':len(paths)},indent=2))
