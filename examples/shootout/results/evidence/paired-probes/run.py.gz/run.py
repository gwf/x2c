from pathlib import Path
import subprocess,json,os,statistics,hashlib,time
r=Path(__file__).resolve().parents[1];p=r/'probes';src=r/'examples/shootout/benchmarks'
env=dict(os.environ,LC_ALL='C',TZ='UTC',MallocNanoZone='0')
meta=json.loads((r/'examples/shootout/benchmarks.json').read_text())
checks=[];rows=[];summaries=[]
def build_busy():
 text=subprocess.check_output(['ps','-Ao','command'],text=True)
 return any('/Users/gary/.codex/worktrees/f2bc/x2c/' in line and any(x in line for x in ['/builds/', 'gate-state.py', 'precommit', 'performance-snapshot.py']) for line in text.splitlines())
def await_quiet():
 while build_busy():
  print('waiting for implementation checkout validation',flush=True)
  time.sleep(10)
def output(n,v,args,data=None):
 return subprocess.check_output([str(p/n/v/'program'),*args],input=data,env=env,timeout=60)
for b in meta['benchmarks']:
 n=b['name']
 if n not in ['nbody','fasta','regexredux','knucleotide']:continue
 for c in b['checks']:
  data=(src/n/c['stdin']).read_bytes() if c.get('stdin') else None
  expected=(src/n/c['expected']).read_bytes()
  for v in ['baseline','variant']:
   out=output(n,v,c['args'],data)
   if c.get('comparison',{}).get('kind')=='numeric_lines':
    a=list(map(float,out.split()));z=list(map(float,expected.split()));assert len(a)==len(z) and all(abs(x-y)<=1e-8 for x,y in zip(a,z)),(n,v,out,expected)
   else:assert out==expected,(n,v,'official output mismatch')
   checks.append({'benchmark':n,'variant':v,'check':c['expected'],'passed':True})
print('all eight official fixture checks passed',flush=True)
inputs={}
for size in [100000,500000]:
 f=p/f'fasta-{size}.input'
 with f.open('wb') as o:subprocess.run([str(p/'fasta-reference'),str(size)],stdout=o,check=True,env=env)
 inputs[size]=f
for n in ['nbody','fasta','regexredux','knucleotide']:
 for scale in ['local','larger']:
  await_quiet()
  args=([str(1000000 if scale=='local' else 5000000)] if n=='nbody' else [str(100000 if scale=='local' else 500000)] if n=='fasta' else [])
  f=inputs[100000 if scale=='local' else 500000] if n in ['regexredux','knucleotide'] else None
  data=f.read_bytes() if f else None
  a=output(n,'baseline',args,data);b=output(n,'variant',args,data);assert a==b,(n,scale,'variant mismatch')
  if n=='fasta':
   reference=subprocess.check_output([str(p/'fasta-reference'),*args],env=env);assert a==reference,(n,scale,'C mismatch')
  checks.append({'benchmark':n,'scale':scale,'baseline_variant_equal':True,'output_sha256':hashlib.sha256(a).hexdigest(),'stdin_sha256':hashlib.sha256(data).hexdigest() if data else None})
  def measure(v):
   with (f.open('rb') if f else open(os.devnull,'rb')) as inp:
    z=subprocess.check_output([str(p/'measure'),str(p/n/v/'program'),*args],stdin=inp,env=env,timeout=60)
   q=json.loads(z);assert q['exit_code']==0 and not q['signal'];return q
  for v in ['baseline','variant']:measure(v)
  samples={'baseline':[],'variant':[]}
  for i in range(12):
   for position,v in enumerate(['baseline','variant'] if i%2==0 else ['variant','baseline']):
    z={'benchmark':n,'scale':scale,'args':args,'sample':i+1,'position':position,'variant':v,**measure(v)}
    samples[v].append(z['elapsed_ns']/1e6);rows.append(z)
    with (p/'raw.jsonl').open('a') as o:o.write(json.dumps(z)+'\n')
  bs=statistics.median(samples['baseline']);vs=statistics.median(samples['variant'])
  summary={'benchmark':n,'scale':scale,'args':args,'stdin_fasta_n':(100000 if scale=='local' else 500000) if f else None,'baseline_ms':bs,'variant_ms':vs,'saved_ms':bs-vs,'reduction_percent':100*(bs-vs)/bs,'speedup':bs/vs,'paired_wins':sum(x>y for x,y in zip(samples['baseline'],samples['variant'])),'samples':12}
  for v in samples:
   med=statistics.median(samples[v]);summary[v+'_mad_ms']=statistics.median(abs(x-med) for x in samples[v])
  summaries.append(summary)
  (p/'results.json').write_text(json.dumps({'checks':checks,'summaries':summaries,'environment':{k:env[k] for k in ['LC_ALL','TZ','MallocNanoZone']}},indent=2)+'\n')
  print(json.dumps(summary),flush=True)
print('complete',flush=True)
