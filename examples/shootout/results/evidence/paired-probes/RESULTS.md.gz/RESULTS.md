# Isolated x2c performance probes

Three changes improve elapsed time. Additive Map updates regress and should not replace the existing counting loop. No changes were landed.

## Measured results

Each row uses twelve fresh-process samples per version after one warmup. Samples alternate baseline/variant order. Values are medians; reduction compares those medians. Positive reduction means faster. Both scales retain the official workload algorithms.

| Probe | Input | Baseline ms | Variant ms | Saved ms | Elapsed reduction | Variant wins |
|---|---|---:|---:|---:|---:|---:|
| n-body pair precomputation | 1000000 | 99.545 | 69.935 | +29.610 | +29.75% | 12/12 |
| n-body pair precomputation | 5000000 | 468.760 | 329.600 | +139.159 | +29.69% | 12/12 |
| FASTA Buffer reuse | 100000 | 37.535 | 31.571 | +5.964 | +15.89% | 12/12 |
| FASTA Buffer reuse | 500000 | 176.874 | 147.616 | +29.257 | +16.54% | 12/12 |
| regex JIT only | FASTA n=100000 | 215.669 | 56.487 | +159.182 | +73.81% | 12/12 |
| regex JIT only | FASTA n=500000 | 1064.335 | 258.308 | +806.027 | +75.73% | 12/12 |
| k-nucleotide additive Map update | FASTA n=100000 | 178.407 | 214.105 | -35.698 | -20.01% | 0/12 |
| k-nucleotide additive Map update | FASTA n=500000 | 824.380 | 998.393 | -174.013 | -21.11% | 0/12 |

The larger inputs are five times the local arguments or FASTA generator size. They are bounded follow-up workloads, not canonical-profile runs.

## Changes and conclusions

- **N-body:** construct the ten fixed Body interaction pairs once, then iterate those pairs. Ordinary Array and heap classes remain. The attraction math and pair order are unchanged. This is exactly the existing tuned source strategy, verified by its small source diff. The final run establishes approximately 30% lower elapsed time at both sizes.
- **FASTA:** move each output-line Buffer outside its loop and clear it between lines. Probability lookup, random generation, String conversion, and output calls are unchanged. Reuse lowers elapsed time by approximately 16% at both sizes. It does not remove the remaining per-line canonical String work.
- **Regex:** call the existing jit_compile method after compiling the strip, nine count, and five substitution patterns. find_all and all match collection remain unchanged. JIT alone lowers elapsed time by approximately 74–76%, supporting JIT as the primary initial source optimization. This experiment does not measure an allocation-free count API.
- **K-nucleotide:** replace getdefault/int-add/setindex with counts[key] += 1. Generated C calls Map_updateindex. The variant is approximately 20–21% slower and loses every pair. Map_updateindex uses a single get-or-insert but also performs generic numeric classification and Var.update. These extra paths are a plausible explanation, not profiled attribution. Keep the existing loop; this result rejects the proposed source substitution, not all possible Map optimizations.

## Correctness and isolation

- Baseline sources match the SHA256 values in the report shipped at af87abd76977b6cb7024dd449cb5e57494061b23.
- All eight official fixture checks passed: baseline and variant for each of the four programs. N-body uses the official absolute tolerance of 1e-8; other fixture output comparisons are byte-for-byte.
- At both measured sizes, each variant output matched its baseline byte-for-byte. FASTA also matched the unchanged contributed C generator at both sizes.
- 192 fresh-process measurements completed: four workloads, two scales, two versions, twelve samples. Execution stdout went to /dev/null after the output checks; stdin and stdout operations remain inside elapsed time. Official C FASTA input generation is excluded from measurement.
- The Go/Java calibration completed before any probe build or run. The first probe attempt was stopped when publication checks began. That interrupted attempt is retained separately and excluded from this report. The final run began after the implementation chat completed publication validation.
- Sources, generated C, executables, copied toolchain, PCRE2 static libraries, inputs, diffs, scripts, logs, and results are under this /tmp directory. No tracked file was edited. No commit, gate, push, or publication was performed by these probes.

## Toolchain and measurement limits

The compiler and runtime were copied from the Go/Java implementation checkout after calibration. Their hashes match that completed calibration. Baselines and variants use the same frozen copies. Compiler hash: `9558fc95dcc1eccbe56e0415437a782e2cfeee0309afefc0ff53b24741e30d9e`. Runtime archive hash: `c625f40def1bc4501a4d426f9d5986799d7a095aa9d4e636be254281cb26a7b8`.

Apple M4 Max; Apple clang 17; -O2 -DNDEBUG; LC_ALL=C; TZ=UTC; MallocNanoZone=0. The compiler hash also matches the earlier af87abd7 report. The runtime archive hash differs from that earlier report, so gains here use contemporaneous baseline/variant measurements rather than subtracting historical timings.

This was an active desktop, not a dedicated idle machine. A separate map benchmark and ordinary desktop work were observed during the final run; desktop-load.json records one snapshot. Alternating order and consistent results across all pairs and both sizes support the direction and approximate magnitude. They do not establish dedicated-machine precision or canonical-size performance.

## Evidence files

- [Raw measurements](raw.jsonl), [checks and statistics](results.json), [toolchain and artifact hashes](toolchain.json), [build commands](commands.json), [run log](run.log), [desktop load snapshot](desktop-load.json).
- Source copies and change.diff are in each workload directory. Generated C and binaries are in its baseline/ and variant/ subdirectories.
- Interrupted measurements are named interrupted-raw.jsonl, interrupted-results.json, and interrupted-run.log. They are not included in any final statistic.

Recommendation: pursue the n-body pair strategy, FASTA Buffer reuse, and explicit regex JIT if implementation is later authorized. Do not adopt the additive Map source substitution. These probes authorize no repository change.
