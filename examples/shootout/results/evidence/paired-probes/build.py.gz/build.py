from pathlib import Path
import subprocess,json,shlex,hashlib,os
root=Path(__file__).resolve().parents[1];p=root/'probes'
env=dict(os.environ,LC_ALL='C',TZ='UTC',MallocNanoZone='0')
commands=[]
def run(cmd):
 commands.append(cmd)
 result=subprocess.run(cmd,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 with (p/'build.log').open('a') as f:f.write(shlex.join(cmd)+'\n'+result.stdout+'\n')
 if result.returncode:raise RuntimeError(result.stdout)
for n in ['nbody','fasta','regexredux','knucleotide']:
 for v in ['baseline','variant']:
  d=p/n/v;d.mkdir(exist_ok=True)
  s=p/n/(v+'.x')
  run([str(root/'builds/0/x2c'),'translate','--package-dir',str(root/'packages'),'--out-dir',str(d),str(s)])
  cmd=['/usr/bin/cc','-O2','-DNDEBUG','-iquote',str(root/'include/x2c')]
  if n=='regexredux':cmd+=['-iquote',str(root/'packages/pcre2/builds'),'-iquote',str(root/'packages/pcre2/src'),'-I',str(root/'packages/pcre2/deps/include')]
  cmd+=['-I/opt/homebrew/include',str(d/(v+'.c'))]
  if n=='regexredux':cmd+=[str(root/'packages/pcre2/builds/libpcre2.a')]
  cmd += ['-L',str(root/'builds/0'),'-lx2c','-lm','-L/opt/homebrew/lib']
  if n=='regexredux':cmd+=shlex.split((root/'packages/pcre2/builds/pcre2.native.rsp').read_text())
  cmd+=['-o',str(d/'program')];run(cmd)
  print('built',n,v,flush=True)
run(['/usr/bin/cc','-O2','-DNDEBUG',str(root/'examples/shootout/tools/measure.c'),'-o',str(p/'measure')])
run(['/usr/bin/cc','-O2','-DNDEBUG',str(root/'examples/shootout/benchmarks/fasta/main.c'),'-o',str(p/'fasta-reference')])
(p/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print('build complete',flush=True)
