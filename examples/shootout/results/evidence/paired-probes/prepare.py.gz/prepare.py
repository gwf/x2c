from pathlib import Path
import shutil,hashlib,json,subprocess
root=Path(__file__).resolve().parents[1]
source=Path('/Users/gary/.codex/worktrees/f2bc/x2c')
receipt={}
for rel in ['include/x2c','etc','builds/0/lib','builds/0/libexec','packages/pcre2/builds','packages/pcre2/deps/include']:
 p=source/rel;o=root/rel
 if o.exists():shutil.rmtree(o)
 shutil.copytree(p,o)
for rel in ['builds/0/x2c','builds/0/libx2c.a']:
 o=root/rel;o.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/rel,o)
 receipt[rel]=hashlib.sha256(o.read_bytes()).hexdigest()
receipt['copied_from']=str(source)
receipt['source_revision']=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
(root/'probes/toolchain.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
