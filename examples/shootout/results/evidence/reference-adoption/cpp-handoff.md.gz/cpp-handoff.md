# C++ reference adoption handoff

Nine unchanged contributed sources are ready. k-nucleotide is unavailable on
this configured toolchain; all three ZIP variants require GNU PBDS. A bounded
probe with the exact GNU public header also fails on bits/c++config.h, so the
header alone is insufficient. No global installs, standard-library changes,
source rewrites, compiler changes, or package changes were made.

All nine official fixtures passed. Meaningful extra/local comparisons passed:
- nbody: N=1, 10000, 1000000, official tolerance 1e-8.
- spectralnorm: N=7, 500. N=1 numeric value agrees but its source's general
  setprecision formatting prints 1 instead of 1.000000000.
- fannkuchredux: N=3,8,9.
- mandelbrot: N=1,7,8,9,64,200,512 (binary PBM exact).
- fasta: N=1,61,10000,100000.
- revcomp and regexredux: official C FASTA input N=1,61,10000,100000.
- binarytrees: N=6,8,14.
- pidigits: N=10,100,1000,10000.

All outputs were compared with the already adopted C references. Tests did not
collect performance timing. Native builds used configured Apple clang++ 17,
-O2 -DNDEBUG -std=c++17. GMP supplies C++ pidigits (-lgmpxx -lgmp).
Regex #6 links the same existing pinned PCRE2 dependency as C/x2c and uses a
36-line unmodified Boost noncopyable header, exact Boost 1.46 tag SHA and BSL
license included. Parent must add third-party whitespace attributes and notice
for adopted C++ and the header; preserve upstream bytes.

Metadata: .context/cpp-adoption/metadata.json. It includes source archive names,
SHA-256 values, portable cpp_flags/cpp_link_flags with {repo}/{source_dir}
placeholders, dependency metadata, all check outcomes, and exact failed
k-nucleotide commands/errors. No shared manifest/harness/docs were edited.

Parents should show C++ k-nucleotide as N/A. Aggregate comparisons should use
the explicitly common set rather than silently average different problems.
