"""One-off quiet-window orchestration; use the existing measurement owner."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

repo = Path('/Users/gary/.codex/worktrees/f2bc/x2c')
sys.path.insert(0, str(repo / 'examples/shootout/tools'))
import shootout

measure = shootout.calibration_measurements
evidence = repo / 'debug/shootout-node-buffer-quiet-window.jsonl'


def after_quiet_window(*args, **kwargs):
    consecutive = []
    with evidence.open('w') as log:
        while len(consecutive) < 6:
            result = subprocess.run(
                ['top', '-l', '2', '-s', '10', '-n', '0'],
                capture_output=True, text=True, check=True,
            )
            idle = float(re.findall(r'([\d.]+)% idle', result.stdout)[-1])
            sample = {'captured_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                      'idle_percent': idle}
            log.write(json.dumps(sample) + '\n')
            log.flush()
            if idle >= 90:
                consecutive.append(sample)
            else:
                consecutive.clear()
            print(f'quiet window: {idle:.2f}% idle; {len(consecutive)}/6 consecutive 10-second samples', flush=True)
    print('quiet window established; starting existing calibration measurements', flush=True)
    calibration = measure(*args, **kwargs)
    calibration['machine']['quiet_window'] = {
        'criterion': 'at least 90 percent CPU idle in six consecutive 10-second samples after builds and fixture checks',
        'samples': consecutive,
        'evidence': str(evidence.relative_to(repo)),
        'orchestration_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    return calibration


shootout.calibration_measurements = after_quiet_window
raise SystemExit(shootout.main())
