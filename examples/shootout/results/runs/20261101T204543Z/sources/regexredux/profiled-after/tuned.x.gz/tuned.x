/* The Computer Language Benchmarks Game: regex-redux.
   Independent pattern counts use Threads, each with its own JIT-compiled
   Regexp and borrowed match-data block rather than capture Lists. */

import "pcre2" with Regexp;
#include "typed-array.x"
#include <stdio.h>

class Count { String pattern; ArrayChar sequence; ulong matches; Thread worker; } *;

#include <time.h>
static double _profile(void) {
  struct timespec now;
  clock_gettime(CLOCK_MONOTONIC, &now);
  return now.tv_sec * 1000.0 + now.tv_nsec / 1e6;
}

int main(void) {
  double begin = _profile(), stamp = begin;
  String input = Stdin.string();
  fprintf(stderr, "P read %.6f\n", _profile() - stamp);
  stamp = _profile();
  ArrayChar sequence = ArrayChar.new();
  _replace(">.*\\n|\\n", input, input.len(), NULL, sequence);
  fprintf(stderr, "P strip %.6f\n", _profile() - stamp);
  stamp = _profile();
  Array counts = [];
  int parallel = sequence.len() >= 65536;
  foreach (String pattern in %(
    "agggtaaa|tttaccct"
    "[cgt]gggtaaa|tttaccc[acg]"
    "a[act]ggtaaa|tttacc[agt]t"
    "ag[act]gtaaa|tttac[agt]ct"
    "agg[act]taaa|ttta[agt]cct"
    "aggg[acg]aaa|ttt[cgt]ccct"
    "agggt[cgt]aa|tt[acg]accct"
    "agggta[cgt]a|t[acg]taccct"
    "agggtaa[cgt]|[acg]ttaccct"))
    counts.push(Count.new(pattern, sequence, parallel));
  fprintf(stderr, "P launch %.6f\n", _profile() - stamp);
  stamp = _profile();
  size_t replaced = _substitute(sequence);
  fprintf(stderr, "P chain %.6f\n", _profile() - stamp);
  stamp = _profile();
  foreach (Count count in counts) {
    if (count.worker) {
      count.worker.join();
      count.worker.free();
    }
    printf("%s %lu\n", count.pattern, count.matches);
  }
  printf("\n%lu\n%lu\n%lu\n",
    (ulong) input.len(), (ulong) sequence.len(), (ulong) replaced);
  fprintf(stderr, "P join_print %.6f\nP total %.6f\n", _profile() - stamp, _profile() - begin);
  return 0;
}

static void Count.init(Count count, String pattern, ArrayChar sequence, int parallel) {
  count.pattern = pattern;
  count.sequence = sequence;
  if (parallel) count.worker = Thread.start(_count, count);
  else _count(count);
}

static Var _count(Var input) {
  double stamp = _profile();
  Count count = input;
  Regexp regexp = auto Regexp.compile(count.pattern, 0);
  regexp.jit_compile(PCRE2_JIT_COMPLETE);
  fprintf(stderr, "P count_compile %.6f\n", _profile() - stamp);
  stamp = _profile();
  pcre2_match_data *data = regexp.native_match_data();
  PCRE2_SIZE *bounds = pcre2_get_ovector_pointer(data);
  pcre2_code *code = regexp.native();
  pcre2_match_context *context = regexp.native_match_context();
  ulong matches = 0, offset = 0;
  const char *bytes = count.sequence.bytes ? count.sequence.bytes : "";
  size_t length = count.sequence.len();
  while (pcre2_jit_match(code, (PCRE2_SPTR) bytes,
      length, offset, 0, data, context) >= 0) {
    matches++;
    offset = bounds[1];
  }
  fprintf(stderr, "P count_match %.6f\n", _profile() - stamp);
  count.matches = matches;
  return void;
}

static size_t _substitute(ArrayChar sequence) {
  ArrayChar first = auto ArrayChar.new(), second = auto ArrayChar.new();
  ArrayChar current = sequence, next = first;
  foreach (List substitution in %(
    ("tHa[Nt]" "<4>")
    ("aND|caN|Ha[DS]|WaS" "<3>")
    ("a[NSt]|BY" "<2>")
    ("<[^>]*>" "|")
    ("\\|[^|][^|]*\\|" "-"))) {
    String (pattern, replacement) = substitution;
    _replace(pattern, current.bytes, current.len(), replacement, next);
    current = next;
    next = next == first ? second : first;
  }
  return current.len();
}

/* All six prescribed patterns consume at least one byte; replacements are
   literal text. Scratch buffers alternate instead of interning each pass. */
static void _replace(
  String pattern, const char *source, size_t length, String replacement,
  ArrayChar output) {
  double stamp = _profile();
  Regexp regexp = auto Regexp.compile(pattern, 0);
  regexp.jit_compile(PCRE2_JIT_COMPLETE);
  fprintf(stderr, "P replacement_compile %.6f\n", _profile() - stamp);
  stamp = _profile();
  pcre2_match_data *data = regexp.native_match_data();
  PCRE2_SIZE *bounds = pcre2_get_ovector_pointer(data);
  pcre2_code *code = regexp.native();
  pcre2_match_context *context = regexp.native_match_context();
  const char *bytes = source ? source : "";
  size_t offset = 0, size = replacement.len();
  output.clear();
  while (pcre2_jit_match(code, (PCRE2_SPTR) bytes, length,
      offset, 0, data, context) >= 0) {
    ((Block) output).append(bytes + offset, bounds[0] - offset);
    ((Block) output).append(replacement, size);
    offset = bounds[1];
  }
  ((Block) output).append(bytes + offset, length - offset);
  fprintf(stderr, "P replacement_scan %.6f\n", _profile() - stamp);
}
